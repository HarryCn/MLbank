
<!-- top.php -->
<?php include_once('top.php');   ?>
<!-- top.php -->
<!-- head.php -->

    

       <link href="css/style.min2.css?v=4.0.0" rel="stylesheet">
 
<?php include_once('head.php');   ?>
<!-- head.php -->

        <div class="static-content-wrapper">
          <div class="static-content">
            <div class="page-content">
              <div class="container-fluid">
                <div style="height:16px"></div>
<!-- 引入封装了failback的接口--initGeetest -->
 
 
 <div class="row  border-bottom white-bg dashboard-header">
<div class="page-header" style="margin-top: -40px;">
							<h1>
								控制台
								<small>
									<i class="ace-icon fa fa-angle-double-right"></i>
									全局索引 &amp; 余额卡密列表
								</small>
							</h1>
						</div><!-- /.page-header -->
<div class="alert alert-block alert-success">
									<button type="button" class="close" data-dismiss="alert">
										<i class="ace-icon fa fa-times"></i>
									</button>

									<i class="ace-icon fa fa-check green"></i>

									欢迎使用
									<strong class="green">
										HTML流控管理系统
										<small> (v1.0.2)</small>
									</strong>,轻量级好用的流量控制系统.<br><br>
									<?php
									
														
									
									
									
									
if($_GET["addkm"]==1){
function getkm($len = 18)
{
	$str = "1234567890";
	$strlen = strlen($str);
	$randstr = "";
	for ($i = 0; $i < $len; $i++) {
		$randstr .= $str[mt_rand(0, $strlen - 1)];
	}
	return $randstr;
}
		
$num=intval($_POST['num']);
$lx=strval($_POST['ProductListId']);

 if($lx==0){
	  $lxjz="5元充值卡";
 }
  else if($lx==1){
	  
	  $lxjz="10元充值卡";
  }else if($lx==2){
	  
	  $lxjz="20元充值卡";
  }else if($lx==3){
	  
	  $lxjz="30元充值卡";
  }else if($lx==4){
	  
	  $lxjz="50元充值卡";
  }else if($lx==5){
	  
	  $lxjz="100元充值卡";
  }

for ($i = 0; $i < $num; $i++) {
	$km=getkm(18);
	
	$dial = mysql_query("insert into paynum(numleixing,num,i) values('$lx','$km',0)"); 
	if($dial) {
		echo "<b>$km</b><br />";
	}
}

}
$pagesize=8; 
$rs=mysql_query("SELECT count(*) FROM paynum",$con); 
$myrow = mysql_fetch_array($rs);
$numrows=$myrow["COUNT(*)"];
$page=$_GET["page"];
$total=mysql_num_rows(mysql_query("SELECT * FROM paynum",$con)); 
$pagenum=ceil($total/$pagesize);


		?>
								</div>
           <div class="row">
<div id="more">
		
		
		
		
                       </div>
 
<div>
<form action="kmlist.php?addkm=1" method="post" role="form" class="form-inline">
<select class="form-control" name="ProductListId">
<option value="0" selected>5元充值卡</option>
<option value="1">10元充值卡</option><option value="2">20元充值卡</option><option value="3">30元充值卡</option><option value="4">50元充值卡</option><option value="5">100元充值卡</option></select>

    <input type="text" class="form-control" name="num" placeholder="卡密数量" data-validate="required,number,min[1]">
 
  

  <button type="submit" class="btn btn-secondary btn-single">生成</button>  <a onclick="btmore()" class="btn btn-info" style="margin-top: 11px;">更多功能</a>

                        </div>
                      <script type="text/javascript">
	function btmore(){
		
	document.getElementById("more").innerHTML="<form action='searchkm.php?type=money' method='get' role='form' class='form-inline'><div class='form-group' style='margin-top: -10px;'><input type='hidden' class='form-control' name='type' value='money'><input type='text' class='form-control' name='kmnum' placeholder='输入卡密'></div><button type='submit' class='btn btn-primary'>搜索</button>&nbsp; </form><a href='kmexct.php' class='btn btn-success' onclick='if(!confirm('你确实导出所有卡密吗？')){return false;}'>一键导出所有卡密</a>         <a href='kmde.php?km=used' class='btn btn-danger' onclick='if(!confirm('你确实清空已用卡密吗？')){return false;}'>一键清空已用卡密</a>        <a href='kmde.php?km=ye' class='btn btn-info' onclick='if(!confirm('你确实清空所有卡密吗？')){return false;}'>一键清空所有卡密</a><a href='#' class='btn btn-blue'>平台共有<?php if($rs){echo $total;}else{echo '0';} ?>张卡密</a><br>";
	
	 }
	 
	
	
	</script>
					
</form>
<br>
  <div class="tab-content">
                  <div class="tab-pane active" id="others">
                      <div class="table-responsive" style="overflow-y:scroll;">
                               <table class="table table-striped">    
                    <thead>
                    <tr>
                      
                        <th>卡密ID</th>
                     <th>卡密面额</th>
                        <th>库存卡信息</th>
						<th>状态</th>
                        <th colspan="2">操作</th>
                    </tr>
                    </thead>
                    <tbody>
                            
					
				<?php




if(empty($page)){
	$page=1;
}
else{
	$page=$_GET["page"];
}

$offset=$pagesize*($page - 1);
if ($page > $pagenum) {
$page = $pagenum;
}
if ($page < 9) {
if($pagenum < 9){
$start1 = 1;
$end = $pagenum;
}else{
	$start1 = 1;
$end = 9;
}
}
elseif ($page >= 5 && $page < $pagenum-4) {
$start1 = $page - 4;
$end = $page+4;
}
elseif ($page >= $pagenum) {
$start1 = $pagenum-4;
$end = $pagenum;
}

$km = mysql_query("SELECT * FROM paynum limit $offset,$pagesize;"); 

while($source = mysql_fetch_array($km))
  {
  $kamid=$source["id"];
   $kmlx=$source["numleixing"];
   $kami=$source["num"];
  $kaactive=$source["i"];
  
 if($kmlx==0){
	  $kmlx="5元充值卡";
 }
  else if($kmlx==1){
	  
	  $kmlx="10元充值卡";
  }else if($kmlx==2){
	  
	  $kmlx="20元充值卡";
  }else if($kmlx==3){
	  
	  $kmlx="30元充值卡";
  }else if($kmlx==4){
	  
	  $kmlx="50元充值卡";
  }else if($kmlx==5){
	  
	  $kmlx="100元充值卡";
  }
  
  if($kaactive==="0"){
	 $kmzt="未使用";
  }else{
  $kmzt="<font style='color:red'>已使用,ID:$kaactive</font>";
  }
echo "<tr>";
echo "<td>".$kamid."</td>";
echo "<td>".$kmlx."</td>";
echo "<td>".$kami."</td>";
echo "<td>".$kmzt."</td>";
echo "<td><a class='btn btn-danger' href='delect.php?kami=$kamid'>删除</a></td>";
echo "</tr>";
}


?>
					
					




					<a href="#" onclick="gotoTop();return false;" class="totop"></a>

					
					 </tbody>

                </table>
                     <br>            
                <br><br>
				<ul class="pagination pagination-sm">
				  <li class=''><a href="kmlist.php?page=<?php echo "1";  ?>">首页</a></li>
<?php 

for($i=$start1;$i<=$end;$i++){

       $show=($i!=$page)?"<li class=''><a href='kmlist.php?page=".$i."'>$i</a></li>":"";
       echo $show."&nbsp;&nbsp";
	 
}


 ?>
 
 <li class=''><a href="kmlist.php?page=<?php echo $pagenum;  ?>">尾页</a></li>
 </ul>
                <br>
               
            </div>

        <hr>

</div>
 









						</div>
            </div>
          </div>
					<br>
					<!-- footer.php -->
					<?php include_once('footer.php');   ?>
					<!-- footer.php -->
        </div>
      </div>
    </div> 
<!-- /Switcher -->
<!-- Load site level scripts -->
<script type="text/javascript" src="css/prettify.js"></script> 				<!-- Code Prettifier  -->
<script type="text/javascript" src="css/bootstrap-switch.js"></script> 		<!-- Swith/Toggle Button -->
<script type="text/javascript" src="css/bootstrap-tabdrop.js"></script>  <!-- Bootstrap Tabdrop -->
<script type="text/javascript" src="css/jquery.sparkline.min.js"></script><!-- Sparkline -->

<script type="text/javascript" src="css/icheck.min.js"></script>     					<!-- iCheck -->
<script type="text/javascript" src="css/enquire.min.js"></script> 									<!-- Enquire for Responsiveness -->
<script type="text/javascript" src="css/bootbox.js"></script>							<!-- Bootbox -->
<script type="text/javascript" src="css/jquery.nanoscroller.min.js"></script> <!-- nano scroller -->
<script type="text/javascript" src="css/jquery.mousewheel.min.js"></script> 	<!-- Mousewheel support needed for jScrollPane -->
<script type="text/javascript" src="css/application.js"></script>
<script type="text/javascript" src="css/demo.js"></script>
<!-- End loading site level scripts -->
	<!-- Load page level scripts-->
	
	<script src="css/jquery.flot.min.js"></script>             <!-- Flot Main File -->
	<script src="css/jquery.flot.resize.js"></script>          <!-- Flot Responsive -->
	<script src="css/jquery.flot.tooltip.min.js"></script>    <!-- Flot Tooltips -->
	<!-- End loading page level scripts </script> 	 -->
 