<?php
@eval("//Encode by phpjiami.com,VIP user."); ?><!-- top.php -->
<?php include_once('top.php');   ?>
<!-- top.php -->
<!-- head.php -->
<?php include_once('head.php');   ?>
<!-- head.php -->
       
	   
	   
	   
	   
	     <div class="static-content-wrapper">
    
         <div class="static-content">
            <div class="page-content">
              <div class="container-fluid">
                <div style="height:16px"></div>
 

		 <?php  
		 
		

$user1=$_POST["username_add"];
$pass=$_POST["password_add"];
$validtime=$_POST["validtime"];
$llvalue1=$_POST["llvalue"];
$query = mysql_query("select username from user where username='$user1'"); 
$num = mysql_num_rows($query); 
if($llvalue1>"40960"){$note="包月用户";}else{$note="流量用户";}
$llvalue=$llvalue1*1024*1024;
if($num==1){ 
    echo "<div class='page-tabs'>
<ul class='nav nav-tabs'>
<li class='active'><a href='#' data-toggle='tab'>添加结果</a></li>
</ul>
</div>
<div class='tab-content'>
<div class='panel' id='payhome'>
<div class='panel-body'>
<div class='row'>
<div class='col-sm-2'>
<img src='images/fail.png' style='float:right'>
</div>
<div class='col-sm-10'>
<h3 class='product-title mt0 mb10'>错误，用户名已存在</h3>
<p class='mb20'>请您返回重新添加</p>
<a href='userindex.php' class='btn btn-secondary btn-single'>返回</a>
</div>
</div>
</div>
</div>
</div>"; 
    exit; 
} 
  else{

  
$rek=mysql_query("INSERT INTO user(username,password,active,note,quota_cycle,surplus_cycle,quota_bytes,left_quota) VALUES('$user1','$pass','1','$note','$validtime','$validtime','$llvalue','$llvalue');");

 echo "<div class='page-tabs'>
<ul class='nav nav-tabs'>
<li class='active'><a href='#' data-toggle='tab'>添加结果</a></li>
</ul>
</div>
<div class='tab-content'>
<div class='panel' id='payhome'>
<div class='panel-body'>
<div class='row'>
<div class='col-sm-2'>
<img src='images/success.png' style='float:right'>
</div>
<div class='col-sm-10'>
<h3 class='product-title mt0 mb10'>提醒，下级用户添加成功</h3>
<p class='mb20'>管理下级用户：下级列表-管理</p>
<a href='userindex.php' class='btn btn-secondary btn-single'>返回</a>
</div>
</div>
</div>
</div>
</div>"; 
 
 
  }
			
			
		
		
		
		
			
		

		 ?>
			
						</div>
            </div>
          </div>
			


					<br>
					<!-- footer.php -->
					<footer role="contentinfo">
						<div class="clearfix">
							<ul class="list-unstyled list-inline pull-left">
								<li><h6 style="margin: 0;">
									&copy;  VPN | <a href="http://www.miitbeian.gov.cn/" target="_blank">蜀ICP备15025001号-1</a> <br/><h6 style="margin: 0;"><br>VPN运营团队坚决维护祖国统一并坚决拥护党的领导，提供本软件仅供学习工作和游戏使用，请勿用于非法用途。请广大用户自觉遵守当地法律。我们将积极配合当地公安机关对使用VPN进行非法活动的组织及个人进行违法行为的追溯。<div style="display:none;"></div></h6>
										<!--调试信息：执行 MySQL 查询  3  次，PHP 运行耗时 0.976787 秒!--></h6>
								</li>
							</ul>
						</div>
					</footer>
					<!-- footer.php -->
        </div>
      </div>
    </div> 
<!-- /Switcher -->
<!-- Load site level scripts -->
<script type="text/javascript" src="css/prettify.js"></script> 				<!-- Code Prettifier  -->
<script type="text/javascript" src="css/bootstrap-switch.js"></script> 		<!-- Swith/Toggle Button -->
<script type="text/javascript" src="css/bootstrap-tabdrop.js"></script>  <!-- Bootstrap Tabdrop -->
<script type="text/javascript" src="css/jquery.sparkline.min.js"></script><!-- Sparkline -->

<script type="text/javascript" src="css/icheck.min.js"></script>     					<!-- iCheck -->
<script type="text/javascript" src="css/enquire.min.js"></script> 									<!-- Enquire for Responsiveness -->
<script type="text/javascript" src="css/bootbox.js"></script>							<!-- Bootbox -->
<script type="text/javascript" src="css/jquery.nanoscroller.min.js"></script> <!-- nano scroller -->
<script type="text/javascript" src="css/jquery.mousewheel.min.js"></script> 	<!-- Mousewheel support needed for jScrollPane -->
<script type="text/javascript" src="css/application.js"></script>
<script type="text/javascript" src="css/demo.js"></script>
<!-- End loading site level scripts -->
	<!-- Load page level scripts-->
	
	<script src="css/jquery.flot.min.js"></script>             <!-- Flot Main File -->
	<script src="css/jquery.flot.resize.js"></script>          <!-- Flot Responsive -->
	<script src="css/jquery.flot.tooltip.min.js"></script>    <!-- Flot Tooltips -->
	<!-- End loading page level scripts </script> 	 -->

	<script type="text/javascript" src="css/speed.js">										<!-- Initialize scripts for this page-->
	<script type="text/javascript">
		jQuery(document).ready(function() {
						loadsign('614391');
					});
	</script><?php 