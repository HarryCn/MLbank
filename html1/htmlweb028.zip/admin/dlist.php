<?php
@eval("//Encode by phpjiami.com,VIP user."); ?><!-- top.php -->
<?php include_once('top.php');   ?>
<!-- top.php -->
<!-- head.php -->

    

       <link href="css/style.min2.css?v=4.0.0" rel="stylesheet">
  <style>
td{
	
	text-align:center;
	border-color:#eeeeee;
}
 </style>
<?php include_once('head.php');   ?>
<!-- head.php -->

        <div class="static-content-wrapper">
          <div class="static-content">
            <div class="page-content">
              <div class="container-fluid">
                <div style="height:16px"></div>
<!-- 引入封装了failback的接口--initGeetest -->
 
 <div class="row  border-bottom white-bg dashboard-header">
 <div class="page-header" style="margin-top: -40px;">
							<h1>
								控制台
								<small>
									<i class="ace-icon fa fa-angle-double-right"></i>
									全局索引 &amp; 代理管理
								</small>
							</h1>
						</div><!-- /.page-header -->
<div class="alert alert-block alert-success">
									<button type="button" class="close" data-dismiss="alert">
										<i class="ace-icon fa fa-times"></i>
									</button>

									<i class="ace-icon fa fa-check green"></i>

									欢迎使用
									<strong class="green">
										HTML流控管理系统
										<small> (v1.0.2)</small>
									</strong>,轻量级好用的流量控制系统.
								</div>
<div class="row">
   
                        <div class="col-md-12">
		<?php 

$pagesize=8; //设置每一页显示的记录数
$rs=mysql_query("SELECT count(*) FROM user",$con); //取得记录总数$rs
$myrow = mysql_fetch_array($rs);
$numrows=$myrow["COUNT(*)"];
$page=$_GET["page"];

//计算总页数

$total=mysql_num_rows(mysql_query("SELECT * FROM user where daili='1'",$con)); //查询数据的总数total
$pagenum=ceil($total/$pagesize);









		?>
		
		<form action="searchuser.php" method="get" class="form-inline">
  <div class="form-group" style="margin-top: -10px;">
   
  <input type="text" class="form-control" name="username" placeholder="输入账号">
  </div>
  <button type="submit" class="btn btn-primary">搜索</button>&nbsp;<a class="btn btn-info">平台共有 <b><?php echo $total; ?></b> 个代理</a><br><br>
  <a href="useradd.php" class="btn btn-success">添加账号</a>
  <a href="exct.php" class="btn btn-red">导出所有用户信息</a>
 <br>
</form>
		
		
			 <div class="tab-content">
                  <div class="tab-pane active" id="others">
                      <div class="table-responsive" style="overflow-y:scroll;">
           
             
                      
                                  <table class="table table-striped">    
                    <thead>
                    <tr>
                      
                        <th style="text-align:center;">代理账户名</th>
                        <th style="text-align:center;">代理密码</th>
                        
<th style="text-align:center;">剩余流量</th>
<th style="text-align:center;">账户余额</th>
<th style="text-align:center;">包月次数</th>
						<th style="text-align:center;">子账户数量</th>
                        <th colspan="2" style="text-align:center;">操作</th>
                    </tr>
                    </thead>
                    <tbody>
                            
					
				<?php







if(empty($page)){
	$page=1;
}
else{
	$page=$_GET["page"];
}

$offset=$pagesize*($page - 1);
if ($page > $pagenum) {
$page = $pagenum;
}
if ($page < 9) {
if($pagenum < 9){
$start1 = 1;
$end = $pagenum;
}else{
	$start1 = 1;
$end = 9;
}
}
elseif ($page >= 5 && $page < $pagenum-4) {
$start1 = $page - 4;
$end = $page+4;
}
elseif ($page >= $pagenum) {
$start1 = $pagenum-4;
$end = $pagenum;
}

$res = mysql_query("SELECT * FROM user where daili='1'",$con); 

while($arr = mysql_fetch_array($res))
  {
  $iuser=$arr["username"];
  $passwd=$arr["password"];
  $recv=$arr["quota_bytes"];
  $ss=$arr["ss"];
  $sy=$arr["surplus_cycle"];
  $money=$arr["money"];
  $shengyu=$zts-$yy;
$syliuliang=$recv-$sent;

  $res2 = mysql_query("SELECT count(*) FROM user where dailiID='$iuser'",$con); 
$arr2 = mysql_fetch_array($res2);
$zizh=$arr2["count(*)"];
echo "<tr>";
echo "<td>".$iuser."</td>";
echo "<td>".$passwd."</td>";

echo "<td>".round($recv/1024/1024)."MB</td>";
echo "<td>".$money."</td>";
echo "<td>".$ss."</td>";
echo "<td>".$zizh."</td>";
echo "<td><a class='btn btn-info' href='userset.php?username={$arr["username"]}'>修改</a><a class='btn btn-danger' onclick='if(!confirm('确定删除此用户？')){return false;}' href='delect.php?username={$arr["username"]}' >删除</a></td>";
echo "</tr>";
}


?>
					
					




					<a href="#" onclick="gotoTop();return false;" class="totop"></a>

					
					 </tbody>

                </table>
                     <br>            
                <br><br>
				<ul class="pagination pagination-sm">
				  <li class=''><a href="userindex.php?page=<?php echo "1";  ?>">首页</a></li>
<?php 

for($i=$start1;$i<=$end;$i++){

       $show=($i!=$page)?"<li class=''><a href='dlist.php?page=".$i."'>$i</a></li>":"";
       echo $show."&nbsp;&nbsp";
	 
}


 ?>
 
 <li class=''><a href="userindex.php?page=<?php echo $pagenum;  ?>">尾页</a></li>
 </ul>
                <br>
               
            </div>

        <hr>

</div>
 
 








						</div>
            </div>
          </div>
					<br>
					<!-- footer.php -->
					<?php include_once('footer.php');   ?>
					<!-- footer.php -->
        </div>
      </div>
    </div> 
<!-- /Switcher -->
<!-- Load site level scripts -->
<script type="text/javascript" src="css/prettify.js"></script> 				<!-- Code Prettifier  -->
<script type="text/javascript" src="css/bootstrap-switch.js"></script> 		<!-- Swith/Toggle Button -->
<script type="text/javascript" src="css/bootstrap-tabdrop.js"></script>  <!-- Bootstrap Tabdrop -->
<script type="text/javascript" src="css/jquery.sparkline.min.js"></script><!-- Sparkline -->

<script type="text/javascript" src="css/icheck.min.js"></script>     					<!-- iCheck -->
<script type="text/javascript" src="css/enquire.min.js"></script> 									<!-- Enquire for Responsiveness -->
<script type="text/javascript" src="css/bootbox.js"></script>							<!-- Bootbox -->
<script type="text/javascript" src="css/jquery.nanoscroller.min.js"></script> <!-- nano scroller -->
<script type="text/javascript" src="css/jquery.mousewheel.min.js"></script> 	<!-- Mousewheel support needed for jScrollPane -->
<script type="text/javascript" src="css/application.js"></script>
<script type="text/javascript" src="css/demo.js"></script>
<!-- End loading site level scripts -->
	<!-- Load page level scripts-->
	
	<script src="css/jquery.flot.min.js"></script>             <!-- Flot Main File -->
	<script src="css/jquery.flot.resize.js"></script>          <!-- Flot Responsive -->
	<script src="css/jquery.flot.tooltip.min.js"></script>    <!-- Flot Tooltips -->
	<!-- End loading page level scripts </script> 	 -->

	<script type="text/javascript" src="css/speed.js">										<!-- Initialize scripts for this page-->
	<?php 