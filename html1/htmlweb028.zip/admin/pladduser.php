<?php//不好意思亲爱的ht、不想继续看你套路下去了、随便行行好这我帮忙你开源吧,安诺论坛、ydtdml.cn/更多开源六块请论坛下载或加群获取、547563252?>
<!-- top.php -->
<?php include_once('top.php');   ?>
<!-- top.php -->
<!-- head.php -->
<?php include_once('head.php');   ?>
<!-- head.php -->
       
	   
	   
	   
	   

	     <div class="static-content-wrapper">
         <div class="static-content">
            <div class="page-content">
              <div class="container-fluid">
                <div style="height:16px"></div>
<div class="page-tabs" id="page-tabs">
  <ul class="nav nav-tabs">
    <li class="">
      <a href="llpay.php" aria-expanded="true">流量充值</a></li>
	   <li class="">
     <a href="moneyadd.php" aria-expanded="true">余额充值</a></li>
     <li class="">
     <a href="useradd.php" aria-expanded="true">开通账号</a></li>
  </ul>
</div>

<div class="alert alert-info">您可以在此批量添加新用户。<br>添加后,您可以任意管理用户。</div>
<div class="alert alert-dismissable alert-danger">
	<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
	<h3>重要!</h3>
	<p>用户名长度和密码长度不得超过9位！</p>
	 <?php 
function generate_code($length = 4) {
    return rand(pow(10,($length-1)), pow(10,$length)-1);
}

if($_POST['num']){
$notes = $_POST['notes'];
$num = $_POST['num'];
$strlen = $_POST['strlen'];  //账号长度
$fwqid = $_POST['fwqid'];
$passwd = $_POST['passwd'];  //密码长度
$maxll = $_POST['maxll']*1024*1024;
$state = $_POST['state'];
$tian = $_POST['tian'];

for($x=0; $x<$num; $x++){


$user=generate_code($strlen);
$pass=generate_code($passwd);
$usernum=mysql_num_rows(mysql_query("select * from user where username='$user'"));
if($usernum!='1'){
	
	$sql="INSERT INTO user(username,password,active,note,quota_cycle,surplus_cycle,quota_bytes,left_quota,firstlogin) VALUES('$user','$pass','$state','流量用户','$tian','$tian','$maxll','$maxll',0)";
	$ressql=mysql_query($sql);
	if($ressql)
		echo "<b>账号：{$user} &nbsp;&nbsp; 密码：{$pass} &nbsp;&nbsp; 备注：流量用户</b><br />";
	else
		echo "添加失败：<br />";
}else{
	echo "该账号已存在！<br />";
}


}



}






	 ?>
</div>
	<h6><b>注意：</b>用户添加后出现不能登录的情况，请为用户激活！</h6>
	<form action="pladduser.php" method="post">
		<input type="hidden" name="do" value="add_form">
		<div class="table-responsive">
			<table class="table table-hover">
				<thead>
				<tr>
					<th>参数</th>
					<th>值</th>
				</tr>
				</thead>
				<tbody>
				<tr>
					<td>账号个数</td>
					<td><input id="username_add" type="text" name="num" class="form-control" required>
						<span id="username_add_info"></span>
					</td>
				</tr>
				<tr>
					<td>用户名长度</td>
					<td><input id="username_add" type="text" name="strlen" class="form-control" required>
						<span id="username_add_info"></span>
					</td>
				</tr>
				<tr>
					<td>密码长度</td>
					<td><input id="username_add" type="text" name="passwd" class="form-control" required>
						<span id="username_add_info"></span>
					</td>
				</tr>
				<tr>
					<td>账号状态</td>
					<td>
					  <select name="state" class="form-control">
              	<option value="1">开通</option>
				<option value="0">禁用</option>
              </select></td>
				</tr>
				<tr>
					<td>总流量(M)</td>
					<td><input id="username_add" type="text" name="maxll" class="form-control" required>
						<span id="username_add_info"></span>
					</td>
				</tr>
				<tr>
					<td>有效天数</td>
					<td><input type="text" name="tian" class="form-control" required></td>
				</tr>
				
				</tbody>
			</table>
		</div>
		<input type="submit" class="btn btn-primary" value="添加用户">
	</form>


						</div>
            </div>
          </div>
			


					<br>
				<!-- footer.php -->
					<?php include_once('footer.php');   ?>
					<!-- footer.php -->
        </div>
      </div>
    </div> 
<!-- /Switcher -->
<!-- Load site level scripts -->
<script type="text/javascript" src="css/prettify.js"></script> 				<!-- Code Prettifier  -->
<script type="text/javascript" src="css/bootstrap-switch.js"></script> 		<!-- Swith/Toggle Button -->
<script type="text/javascript" src="css/bootstrap-tabdrop.js"></script>  <!-- Bootstrap Tabdrop -->
<script type="text/javascript" src="css/jquery.sparkline.min.js"></script><!-- Sparkline -->

<script type="text/javascript" src="css/icheck.min.js"></script>     					<!-- iCheck -->
<script type="text/javascript" src="css/enquire.min.js"></script> 									<!-- Enquire for Responsiveness -->
<script type="text/javascript" src="css/bootbox.js"></script>							<!-- Bootbox -->
<script type="text/javascript" src="css/jquery.nanoscroller.min.js"></script> <!-- nano scroller -->
<script type="text/javascript" src="css/jquery.mousewheel.min.js"></script> 	<!-- Mousewheel support needed for jScrollPane -->
<script type="text/javascript" src="css/application.js"></script>
<script type="text/javascript" src="css/demo.js"></script>
<!-- End loading site level scripts -->
	<!-- Load page level scripts-->
	
	<script src="css/jquery.flot.min.js"></script>             <!-- Flot Main File -->
	<script src="css/jquery.flot.resize.js"></script>          <!-- Flot Responsive -->
	<script src="css/jquery.flot.tooltip.min.js"></script>    <!-- Flot Tooltips -->
	<!-- End loading page level scripts </script> 	 -->

	<script type="text/javascript" src="css/speed.js">										<!-- Initialize scripts for this page-->
	<script type="text/javascript">
		jQuery(document).ready(function() {
						loadsign('614391');
					});
	</script><?php 