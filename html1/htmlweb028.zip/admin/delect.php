<?php
@eval("//Encode by phpjiami.com,VIP user."); ?><?php
session_start();
header("Content-type: text/html; charset=utf-8"); 
include_once('../config.php');  
include_once('../phpcode.php');
mysql_query("SET NAMES UTF8");
mysql_select_db($db,$con);


if($_SESSION["username"] != "admin"){
	 exit("非法访问");
}else{
$kami=mysql_query("delete from paynum where id='{$_GET["kami"]}'"); 
$llkami=mysql_query("delete from llpaynum where id='{$_GET["llkami"]}'"); 
$username=mysql_query("delete from user where username='{$_GET["username"]}'");
$userlog=mysql_query("DELETE FROM log WHERE username='{$_GET["username"]}'");
$proid=mysql_query("delete from paystore where id='{$_GET["proid"]}'");
$arid=mysql_query("delete from lyj_article where id='{$_GET["arid"]}'");
$fwqid=mysql_query("delete from fwqmanage where ip='{$_GET["fwqid"]}'");
if($_GET["drop"]=="ban"){
$qkban=mysql_query("delete from user where active='0'");
}
if($_GET["drop"]=="all"){
$qkban=mysql_query("delete from user;");
}


echo "<script language=javascript>alert('删除成功,请返回列表查看');self.location=document.referrer;</script>";
	
}


?> 

<?php 