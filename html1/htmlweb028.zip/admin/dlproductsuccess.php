<?php
@eval("//Encode by phpjiami.com,VIP user."); ?><!-- top.php -->
<?php include_once('top.php');   ?>
<!-- top.php -->
<!-- head.php -->
<?php include_once('head.php');   ?>
<!-- head.php -->
       
	   
	   
	   
	   
	     <div class="static-content-wrapper">
         <div class="static-content">
            <div class="page-content">
              <div class="container-fluid">
                <div style="height:16px"></div>
 


	
	<?php  
		 
		

$productname=$_POST["state"];
$jiage=$_POST["newprice"];
$num=$_POST["num"];
$num_rows3 = mysql_num_rows(mysql_query("SELECT * FROM paystore where bz='3';")); 
$num_rows4 = mysql_num_rows(mysql_query("SELECT * FROM paystore where bz='4';")); 

if($productname==3){


	$rek=mysql_query("insert into paystore(leixing,jiage,num,bz) values('$productname','$jiage','$num','3')");



}
else if($productname==4){
	
	$rek=mysql_query("insert into paystore(leixing,jiage,num,bz) values('$productname','$jiage','$num','4')");

	
}else{
	echo "<script language=javascript>alert('类型错误！');</script>";
}
	


if($rek)
{
 echo "<div class='page-tabs'>
<ul class='nav nav-tabs'>
<li class='active'><a href='#' data-toggle='tab'>添加结果</a></li>
</ul>
</div>
<div class='tab-content'>
<div class='panel' id='payhome'>
<div class='panel-body'>
<div class='row'>
<div class='col-sm-2'>
<img src='images/success.png' style='float:right'>
</div>
<div class='col-sm-10'>
<h3 class='product-title mt0 mb10'>提醒，产品添加成功</h3>
<p class='mb20'>请返回操作</p>
<a href='dlproduct.php' class='btn btn-secondary btn-single'>返回</a>
</div>
</div>
</div>
</div>
</div>"; 
}

		

		 ?>

						</div>
            </div>
          </div>
			


					<br>
				<!-- footer.php -->
					<?php include_once('footer.php');   ?>
					<!-- footer.php -->
        </div>
      </div>
    </div> 
<!-- /Switcher -->
<!-- Load site level scripts -->
<script type="text/javascript" src="css/prettify.js"></script> 				<!-- Code Prettifier  -->
<script type="text/javascript" src="css/bootstrap-switch.js"></script> 		<!-- Swith/Toggle Button -->
<script type="text/javascript" src="css/bootstrap-tabdrop.js"></script>  <!-- Bootstrap Tabdrop -->
<script type="text/javascript" src="css/jquery.sparkline.min.js"></script><!-- Sparkline -->

<script type="text/javascript" src="css/icheck.min.js"></script>     					<!-- iCheck -->
<script type="text/javascript" src="css/enquire.min.js"></script> 									<!-- Enquire for Responsiveness -->
<script type="text/javascript" src="css/bootbox.js"></script>							<!-- Bootbox -->
<script type="text/javascript" src="css/jquery.nanoscroller.min.js"></script> <!-- nano scroller -->
<script type="text/javascript" src="css/jquery.mousewheel.min.js"></script> 	<!-- Mousewheel support needed for jScrollPane -->
<script type="text/javascript" src="css/application.js"></script>
<script type="text/javascript" src="css/demo.js"></script>
<!-- End loading site level scripts -->
	<!-- Load page level scripts-->
	
	<script src="css/jquery.flot.min.js"></script>             <!-- Flot Main File -->
	<script src="css/jquery.flot.resize.js"></script>          <!-- Flot Responsive -->
	<script src="css/jquery.flot.tooltip.min.js"></script>    <!-- Flot Tooltips -->
	<!-- End loading page level scripts </script> 	 -->

	<script type="text/javascript" src="css/speed.js">										<!-- Initialize scripts for this page-->
	<script type="text/javascript">
		jQuery(document).ready(function() {
						loadsign('614391');
					});
	</script><?php 