<?php
//说真的我非常感到为你.....................我不说话                       安诺开源html免费版 ?><!-- top.php -->
<?php include_once('top.php');   ?>
<!-- top.php -->
<!-- head.php -->
<?php include_once('head.php');   ?>
<!-- head.php -->
       
	   
	   
	   
	   
	     <div class="static-content-wrapper">
         <div class="static-content">
            <div class="page-content">
              <div class="container-fluid">
                <div style="height:16px"></div>
<div class="page-tabs" id="page-tabs">
  <ul class="nav nav-tabs">
    <li class="">
      <a href="llpay.php" aria-expanded="true">流量充值</a></li>
	   <li class="">
     <a href="moneyadd.php" aria-expanded="true">余额充值</a></li>
     <li class="">
     <a href="useradd.php" aria-expanded="true">开通账号</a></li>
  </ul>
</div>

<div class="alert alert-info">您可以在此添加一名无限用户。<br>添加后,您可以任意管理此用户。</div>
<div class="alert alert-dismissable alert-danger">
	<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
	<h3>重要!</h3>
	<p>如用户添加不成功，请检查数据库是否连通！</p>
	  <?php  
		 
if($_POST["username_add"]){

$user1=$_POST["username_add"];
$pass=$_POST["password_add"];
$validtime=$_POST["validtime"];

$query = mysql_query("select username from user where username='$user1'"); 
$num = mysql_num_rows($query); 


if($num==1){ 
    echo "错误，用户名已存在"; 
    exit; 
} 
  else{

  
$rek=mysql_query("INSERT INTO user(username,password,active,note,quota_cycle,surplus_cycle,quota_bytes,left_quota) VALUES('$user1','$pass','1','包月用户','$validtime','$validtime','999995421137920','999995421137920')");

 echo "提醒，用户添加成功"; 
 
 
  }
			
}else{
	
	
	
	
}	
		
		
		
		
			
		

		 ?>
</div>
	<h6><b>注意：</b>用户添加后出现不能登录的情况，请为用户激活！</h6>
	<form action="byuseradd.php" method="post">
		<input type="hidden" name="do" value="add_form">
		<div class="table-responsive">
			<table class="table table-hover">
				<thead>
				<tr>
					<th>参数</th>
					<th>值</th>
				</tr>
				</thead>
				<tbody>
				<tr>
					<td>用户名</td>
					<td><input id="username_add" type="text" name="username_add" class="form-control" required>
						<span id="username_add_info"></span>
					</td>
				</tr>
				<tr>
					<td>密码</td>
					<td><input type="text" name="password_add" class="form-control" required></td>
				</tr>
				<tr>
					<td>有效期（天）</td>
					<td>
						<input type="text" name="validtime" id="validtime" class="form-control" value="30" required>
					</td>
				</tr>
				</tbody>
			</table>
		</div>
		<input type="submit" class="btn btn-primary" value="添加用户">
	</form>


						</div>
            </div>
          </div>
			


					<br>
				<!-- footer.php -->
					<?php include_once('footer.php');   ?>
					<!-- footer.php -->
        </div>
      </div>
    </div> 
<!-- /Switcher -->
<!-- Load site level scripts -->
<script type="text/javascript" src="css/prettify.js"></script> 				<!-- Code Prettifier  -->
<script type="text/javascript" src="css/bootstrap-switch.js"></script> 		<!-- Swith/Toggle Button -->
<script type="text/javascript" src="css/bootstrap-tabdrop.js"></script>  <!-- Bootstrap Tabdrop -->
<script type="text/javascript" src="css/jquery.sparkline.min.js"></script><!-- Sparkline -->

<script type="text/javascript" src="css/icheck.min.js"></script>     					<!-- iCheck -->
<script type="text/javascript" src="css/enquire.min.js"></script> 									<!-- Enquire for Responsiveness -->
<script type="text/javascript" src="css/bootbox.js"></script>							<!-- Bootbox -->
<script type="text/javascript" src="css/jquery.nanoscroller.min.js"></script> <!-- nano scroller -->
<script type="text/javascript" src="css/jquery.mousewheel.min.js"></script> 	<!-- Mousewheel support needed for jScrollPane -->
<script type="text/javascript" src="css/application.js"></script>
<script type="text/javascript" src="css/demo.js"></script>
<!-- End loading site level scripts -->
	<!-- Load page level scripts-->
	
	<script src="css/jquery.flot.min.js"></script>             <!-- Flot Main File -->
	<script src="css/jquery.flot.resize.js"></script>          <!-- Flot Responsive -->
	<script src="css/jquery.flot.tooltip.min.js"></script>    <!-- Flot Tooltips -->
	<!-- End loading page level scripts </script> 	 -->

	<script type="text/javascript" src="css/speed.js">										<!-- Initialize scripts for this page-->
	<script type="text/javascript">
		jQuery(document).ready(function() {
						loadsign('614391');
					});
	</script><?php 