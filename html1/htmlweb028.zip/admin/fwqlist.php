<?php
@eval("//Encode by phpjiami.com,VIP user."); ?>
<?php 

 

session_start(); // 启动Session  
$_SESSION['count']; // 注册Session变量Count  
isset($PHPSESSID)?session_id($PHPSESSID):$PHPSESSID = session_id();  
// 如果设置了$PHPSESSID，就将SessionID赋值为$PHPSESSID，否则生成SessionID 
$_SESSION['count']++; // 变量count加1  
setcookie('PHPSESSID', $PHPSESSID, time()+3156000); // 储存SessionID到Cookie中  

if($_SESSION["status"] != "ok"){
header("location:index.php");
exit("<h2>会话过期，请重新登录</h2>");
}
if($_SESSION["username"] != "admin"){
header("location:index.php");
exit("<h2>非法访问</h2>");
}
$dailiname=$_SESSION["username"];
$iuser=$_SESSION["username"];
$username=$_SESSION["username"];
include_once('../phpcode.php');
header("Content-type: text/html; charset=utf-8"); 
include_once('../config.php');  
mysql_query("SET NAMES UTF8");
mysql_select_db($db,$con);
		

if(isset($_GET["method"])){

		$value = $_POST['value'];
		$ip = $_POST['ip'];
		$spd="".$value."mbit";
		
	  $res=mysql_query("update fwqmanage set speed='$spd' where ip='$ip';",$con);
	 echo "<script language=JavaScript>alert('修改成功,请重启VPN生效');self.location=document.referrer;</script>";
	
	 
	 
}
	


 ?>
      

<!-- top.php -->
<?php include_once('top.php');   ?>
<!-- top.php -->
<!-- head.php -->

    
	<script src="http://cdn.bootcss.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
	 <link href="css/loading.css" rel="stylesheet">
       <link href="css/style.min2.css?v=4.0.0" rel="stylesheet">
  <style>
td{
	
	text-align:center;
	border-color:#eeeeee;
}

 
 </style>
 
    <div id="form-limit" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content" style="background: rgba(4, 4, 4, 0.5);top: 120px;">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                    <h4 class="modal-title" style="color: #f5f5f5">限速设置</h4><br>
				 
                </div>
                <form class="modal-body form-horizontal" action="fwqlist.php?method=update_limit" method="post">

                    <div class="form-group">
                        <label class="col-sm-2 control-label" style="color: #f5f5f5">值(MB)</label>
                        <div class="col-sm-8">
                            <input type="text" id="value" name="value" class="form-control" value="" />
                        </div>
                    </div>

                    <input type="hidden" id="ip" name="ip" value="" />

               
                <div class="modal-footer">
                     
					
					 <button type="submit" class="btn btn-green">保存</button>
					 
					 
                     
                </div>
				 </form>
            </div>
        </div>
    </div>
 
<?php include_once('head.php');   ?>
<!-- head.php -->

        <div class="static-content-wrapper">
		
		
		
		
          <div class="static-content">
            <div class="page-content">
              <div class="container-fluid">
                <div style="height:16px"></div>
<!-- 引入封装了failback的接口--initGeetest -->

<div class="row  border-bottom white-bg dashboard-header">

 <div class="page-header" style="margin-top: -40px;">
							<h1>
								控制台
								<small>
									<i class="ace-icon fa fa-angle-double-right"></i>
									服务器管理 &amp; 服务器列表
								</small>
							</h1>
						</div><!-- /.page-header -->
<div class="alert alert-block alert-success">
									<button type="button" class="close" data-dismiss="alert">
										<i class="ace-icon fa fa-times"></i>
									</button>

									<i class="ace-icon fa fa-check green"></i>

									欢迎使用
									<strong class="green">
										HTML流控管理系统
										<small> (v1.0.2)</small>
									</strong>,轻量级好用的流量控制系统.
								</div>
            <div class="row">
                <div class="col-sm-12">
                    
						<form action="fwqlist.php" method="get" class="form-inline">
  <div class="form-group">
   
  <input type="text" class="form-control" size="25" name="fwqname" placeholder="服务器名称">
  </div>
   <button type="submit" class="btn btn-secondary btn-single">查询</button>&nbsp; <a href="onlineuser.php" class="btn btn-blue" style="margin-top: 10px;">参考:在线人数:共计<?php
   
$res=mysql_query("SELECT * FROM fwqmanage;",$con);

 

$num  = 0;
while($arr = mysql_fetch_array($res))
  {
  $name=$arr["name"];
  $times= $arr["times"];
  $ip=$arr["ip"];
 
$str=file_get_contents('http://'.$ip.'/resources/openvpn-status.txt',false,stream_context_create(array('http' => array('method' => "GET", 'timeout' => 0.3))));
$onlinenum = (substr_count($str,date('Y'))-1)/2;

$str2=file_get_contents('http://'.$ip.'/resources/openvpn-statusudp.txt',false,stream_context_create(array('http' => array('method' => "GET", 'timeout' => 0.3))));

$onlinenum2 = (substr_count($str2,date('Y'))-1)/2;

$str3=file_get_contents('http://'.$ip.'/resources/openvpn-statusudp2.txt',false,stream_context_create(array('http' => array('method' => "GET", 'timeout' => 0.3))));

$onlinenum3 = (substr_count($str3,date('Y'))-1)/2;

$onlinelast=$onlinenum+$onlinenum2+$onlinenum3;

$num=$num+$onlinelast;
	 
  }
  
  echo ceil($num);
 ?>人</a><br>
   <a href="addfwq.php" class="btn btn-info">添加服务器</a>
  
 <br>
</form>
               
                     

                    <div class="tab-content">
                  <div class="tab-pane active" id="others">
                      <div class="table-responsive" style="overflow-y:scroll;">
           
             
                      
                                  <table class="table table-striped">    
                                      <thead>
                                          <tr>
                                               
                                                <th data-priority="1" style="text-align:center;">服务器名称</th>
                                                <th data-priority="3" style="text-align:center;">地址</th>
                                                <th data-priority="6" style="text-align:center;">在线人数</th>
                                                <th data-priority="6" style="text-align:center;">添加时间</th>
                                                <th data-priority="6" style="text-align:center;">操作</th>
                                          </tr>
                                      </thead>
                                      <tbody>
									 
									  
									  <?php 

$seafwq=$_GET["fwqname"];
if(empty($seafwq)){

$res=mysql_query("SELECT * FROM fwqmanage;",$con);


while($arr = mysql_fetch_array($res))
  {
  $name=$arr["name"];
  $times= $arr["times"];
  $ip=$arr["ip"];
  $speed=$arr["speed"];
 if(preg_match('/\d+/',$speed,$arr)){
       $speed=$arr[0];
    }	
$str=file_get_contents('http://'.$ip.'/resources/openvpn-status.txt',false,stream_context_create(array('http' => array('method' => "GET", 'timeout' => 0.3))));
$onlinenum = (substr_count($str,date('Y'))-1)/2;

$str2=file_get_contents('http://'.$ip.'/resources/openvpn-statusudp.txt',false,stream_context_create(array('http' => array('method' => "GET", 'timeout' => 0.3))));

$onlinenum2 = (substr_count($str2,date('Y'))-1)/2;

$str3=file_get_contents('http://'.$ip.'/resources/openvpn-statusudp2.txt',false,stream_context_create(array('http' => array('method' => "GET", 'timeout' => 0.3))));

$onlinenum3 = (substr_count($str3,date('Y'))-1)/2;

$onlinelast=$onlinenum+$onlinenum2+$onlinenum3;
$onlinelast=ceil($onlinelast);

if($onlinelast < 0){
	
			$onlinelast="<font style='color:red'>超时</font>";
}else{
	

}

 echo "<tr>";
 echo "<td>".$name."</td>";
 echo "<td>".$ip."</td>"; 
 echo "<td>".$onlinelast."</td>"; 
  echo "<td>".$times."</td>";
  
  
 echo "<td><a href=\"javascript:;\" onclick=\"limit('".$speed."','".$ip."');\" class='btn btn-info'>限速</a><a href='delect.php?fwqid=$ip' class='btn btn-danger' onclick=\"if(!confirm('你确实要删除此记录吗？')){return false;}\">删除</a></td>";
echo '<tr>';
                                         

  }

}
else{
	
	

$res=mysql_query("SELECT * FROM fwqmanage where name='$seafwq';",$con);
$arr = mysql_fetch_array($res);
  $name=$arr["name"];
  $times= $arr["times"];
  $ip=$arr["ip"];
 
$str=file_get_contents('http://'.$ip.'/resources/openvpn-status.txt',false,stream_context_create(array('http' => array('method' => "GET", 'timeout' => 0.3))));
$onlinenum = (substr_count($str,date('Y'))-1)/2;

 
 echo "<tr>";
 echo "<td>".$name."</td>";
 echo "<td>".$ip."</td>"; 
 echo "<td>".$onlinenum."</td>"; 
  echo "<td>".$times."</td>";
 echo "<td><a href=\"javascript:;\" onclick=\"limit();\" class='btn btn-info'>限速</a><a href='delect.php?fwqid=$ip' class='btn btn-danger' onclick=\"if(!confirm('你确实要删除此记录吗？')){return false;}\">删除</a></td>";
echo '<tr>';
                                         

 
	
	
}




									  ?>
									  
									  
									  
									  
                                                                               

                                                                                </tbody>
                                  </table>
                      
                      </div>
                      
                      <ul class="pagination pagination-sm"><li class="disabled"><a>首页</a></li><li class="disabled"><a>«</a></li><li class="disabled"><a>1</a></li><li class="disabled"><a>»</a></li><li class="disabled"><a>尾页</a></li></ul>                      
                    </div>

        <hr>

</div>




 </div>
                  </div>
                </div>


						</div>
            </div>
          </div>
		  
					<br>
					  

            
           
		   
					<!-- footer.php -->
					<?php include_once('footer.php');   ?>
					<!-- footer.php -->
        
  </div></div></div>

<!-- /Switcher -->
<!-- Load site level scripts -->
<script type="text/javascript" src="css/prettify.js"></script> 				<!-- Code Prettifier  -->
<script type="text/javascript" src="css/bootstrap-switch.js"></script> 		<!-- Swith/Toggle Button -->
<script type="text/javascript" src="css/bootstrap-tabdrop.js"></script>  <!-- Bootstrap Tabdrop -->
<script type="text/javascript" src="css/jquery.sparkline.min.js"></script><!-- Sparkline -->

<script type="text/javascript" src="css/icheck.min.js"></script>     					<!-- iCheck -->
<script type="text/javascript" src="css/enquire.min.js"></script> 									<!-- Enquire for Responsiveness -->
<script type="text/javascript" src="css/bootbox.js"></script>							<!-- Bootbox -->
<script type="text/javascript" src="css/jquery.nanoscroller.min.js"></script> <!-- nano scroller -->
<script type="text/javascript" src="css/jquery.mousewheel.min.js"></script> 	<!-- Mousewheel support needed for jScrollPane -->
<script type="text/javascript" src="css/application.js"></script>
<script type="text/javascript" src="css/demo.js"></script>
<!-- End loading site level scripts -->
	<!-- Load page level scripts-->
	
	<script src="css/jquery.flot.min.js"></script>             <!-- Flot Main File -->

	<script src="css/jquery.flot.tooltip.min.js"></script>    <!-- Flot Tooltips -->
	<!-- End loading page level scripts </script> 	 -->

	<script type="text/javascript" src="css/speed.js">		</script>								<!-- Initialize scripts for this page-->
	  <script>
    //
    function limit(id,ip){
        $("#ip").val(ip);
         $("#value").val(id);
        $("#form-limit").modal("show");
    }

   


    // $(function(){

        // $("#form-limit .modal-footer .btn-primary").click(function(){
            // var btn = $(this);
            // var data = $("#form-limit form").serialize();
            // btn.button("loading");
            // $.post("/admin/fwqlist.php?method=update_limit", data, function(data){
                // if (data.s == 0){
                    // alert("保存成功，稍后将自动刷新页面..", "success", function(){ location.reload(); }, "#form-limit .modal-body");
                // }else{
                    // alert(data.err, "error", null, "#form-limit .modal-body");
                // }
                // btn.button('reset');
            // }, "json");
        // });
    // });


    // $(function(){

        // $("#restartvpn").click(function(){
            // var id = $("#remoteserver-id").val();
            // $.post("/admin/fwqlist.php?method=restartvpn", {id:id}, function(data){
                // if (data.s == 0){
                    // alert("重启成功，稍后将自动刷新页面..", "success", function(){ location.reload(); }, "#form-limit .modal-body");
                // }else{
                    // alert(data.err, "error", null, "#form-limit .modal-body");
                // }
                // btn.button('reset');
            // }, "json");
        // });
    // });

	
 
</script>
	
	
 
<?php 