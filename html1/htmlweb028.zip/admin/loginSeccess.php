<?php
@eval("//Encode by phpjiami.com,VIP user."); ?>
				
				<?php


session_start();
$name=$_POST['user'];
$pass=md5($_POST['pass']);

$yz2=$_SESSION["verification"];
$yz=$_POST["yz"];
$remember=$_POST["remember"];
header("Content-type: text/html; charset=utf-8"); 
include_once('../config.php');  
mysql_query("SET NAMES UTF8");
mysql_select_db($db,$con);

$res=mysql_query("SELECT * FROM manager where username='$name' AND password='$pass'",$con);


if($name=='' || $pass==''){  

$err_msg = "用户名和密码都不能为空!";  
echo $err_msg;

}

else if($result = mysql_fetch_array($res)){

$pas=$result["password"];

$_SESSION["status"]="ok";
$_SESSION["username"] = $name;
$_SESSION["password"] = $pas;

if($remember==1){   
setcookie("user1", $name, time()+3600*24*365);  
setcookie("pass1", $_POST['pass'], time()+3600*24*365);  
}  

header("location:Aindex.php");
exit();

}
else{
	
	echo "<script language=javascript>alert('用户名密码错误！');history.back();</script>";
	
}




?><?php 