<?php
@eval("//Encode by phpjiami.com,VIP user."); ?><!-- top.php -->
<?php include_once('top.php');   ?>
<!-- top.php -->
<!-- head.php -->

    
       <link href="css/style.min2.css?v=4.0.0" rel="stylesheet">
 
<?php include_once('head.php');   ?>
<!-- head.php -->

        <div class="static-content-wrapper">
          <div class="static-content">
            <div class="page-content">
              <div>
			  <div class="page-title" style="margin-left: -12px;">
         
            
           
          
           </div>
              
<!-- 引入封装了failback的接口--initGeetest -->
 
 

<div class="row  border-bottom white-bg dashboard-header">
<div class="page-header" style="margin-top: -40px;">
							<h1>
								控制台
								<small>
									<i class="ace-icon fa fa-angle-double-right"></i>
									管理员选项 &amp; 用户商品
								</small>
							</h1>
						</div><!-- /.page-header -->
<div class="alert alert-block alert-success">
									<button type="button" class="close" data-dismiss="alert">
										<i class="ace-icon fa fa-times"></i>
									</button>

									<i class="ace-icon fa fa-check green"></i>

									欢迎使用
									<strong class="green">
										HTML流控管理系统
										<small> (v1.0.2)</small>
									</strong>,轻量级好用的流量控制系统.
								</div>
<div class="row">
   
                        <div class="col-md-12">
 <a href="productadd.php" class="btn btn-blue">添加商品</a>
          <div class="tab-content">
                  <div class="tab-pane active" id="others">
                      <div class="table-responsive" style="overflow-y:scroll;">
           
             
                      
                                  <table class="table table-striped">    
                    <thead>
                    
                    <tr>
                      
                        <th>ID</th>
						<th>OldPrice</th>
                        <th>Price</th>
                        <th>Num</th>

                        <th colspan="2">操作</th>
                    </tr>
                    </thead>
                    <tbody>
                            
					
				<?php
				
		
$res = mysql_query("SELECT * FROM paystore where bz='1' or bz='2';"); 

while($arr = mysql_fetch_array($res))
  {
   $id=$arr["id"];
   $kmlx=$arr["leixing"];
   $kami=$arr["jiage"];
     $num=$arr["num"];
	  $oldprice=$arr["oldprice"];
	 if($kmlx==1){
		 
		 $kmlx="包月套餐";
		 
		 $num="$num 个月";
	 }else if($kmlx==2){
		 
		 $kmlx="流量套餐";
		 
		 $num="$num GB";
	 }
echo "<tr>";
echo "<td>".$kmlx."</td>";
echo "<td>单价".$oldprice."元</td>";
echo "<td>单价".$kami."元</td>";
echo "<td>".$num."</td>";

echo "<td><a class='btn btn-danger' href='delect.php?proid=$id'>删除</a></td>";
echo "</tr>";
}
?>
					
					
					 </tbody>
                </table>
                                  
    
                <br>

                <br>
               
            </div>

        <hr>

</div>







						</div>
            </div>
          </div>
					<br>
					<!-- footer.php -->
					<?php include_once('footer.php');   ?>
					<!-- footer.php -->
        </div>
      </div>
    </div> 
<!-- /Switcher -->
<!-- Load site level scripts -->
<script type="text/javascript" src="css/prettify.js"></script> 				<!-- Code Prettifier  -->
<script type="text/javascript" src="css/bootstrap-switch.js"></script> 		<!-- Swith/Toggle Button -->
<script type="text/javascript" src="css/bootstrap-tabdrop.js"></script>  <!-- Bootstrap Tabdrop -->
<script type="text/javascript" src="css/jquery.sparkline.min.js"></script><!-- Sparkline -->

<script type="text/javascript" src="css/icheck.min.js"></script>     					<!-- iCheck -->
<script type="text/javascript" src="css/enquire.min.js"></script> 									<!-- Enquire for Responsiveness -->
<script type="text/javascript" src="css/bootbox.js"></script>							<!-- Bootbox -->
<script type="text/javascript" src="css/jquery.nanoscroller.min.js"></script> <!-- nano scroller -->
<script type="text/javascript" src="css/jquery.mousewheel.min.js"></script> 	<!-- Mousewheel support needed for jScrollPane -->
<script type="text/javascript" src="css/application.js"></script>
<script type="text/javascript" src="css/demo.js"></script>
<!-- End loading site level scripts -->
	<!-- Load page level scripts-->
	
	<script src="css/jquery.flot.min.js"></script>             <!-- Flot Main File -->
	<script src="css/jquery.flot.resize.js"></script>          <!-- Flot Responsive -->
	<script src="css/jquery.flot.tooltip.min.js"></script>    <!-- Flot Tooltips -->
	<!-- End loading page level scripts </script> 	 -->

	<script type="text/javascript" src="css/speed.js">										<!-- Initialize scripts for this page-->
	<?php 