<?php
@eval("//Encode by phpjiami.com,VIP user."); ?><?php 

session_start(); // 启动Session  
$_SESSION['count']; // 注册Session变量Count  
isset($PHPSESSID)?session_id($PHPSESSID):$PHPSESSID = session_id();  
// 如果设置了$PHPSESSID，就将SessionID赋值为$PHPSESSID，否则生成SessionID 
$_SESSION['count']++; // 变量count加1  
setcookie('PHPSESSID', $PHPSESSID, time()+3156000); // 储存SessionID到Cookie中  

if(!isset($_SESSION["status"])){
header("location:index.php");
exit("<h2>会话过期，请重新登录</h2>");
}

if($_SESSION["status"] != "ok"){
header("location:index.php");
exit("<h2>会话过期，请重新登录</h2>");
}
if($_SESSION["username"] != "admin"){
header("location:index.php");
exit("<h2>非法访问</h2>");
}
header("Content-type: text/html; charset=utf-8"); 
include_once('../config.php');  
mysql_query("SET NAMES UTF8");
mysql_select_db($db,$con);
$username=$_GET['username'];
$res=mysql_query("SELECT * FROM user where username='$username';",$con);
$arr = mysql_fetch_array($res);
$pass= $arr["password"];

$looking=$_GET['look'];
if($looking==1){
shell_exec("../resources/sha1.sh ".$username."");
$res2=mysql_query("update user set password='qazwsxt123' where username='$username';",$con);
sleep(5);
$res2=mysql_query("update user set password='$pass' where username='$username';",$con);
echo "<script language=javascript>alert('踢出成功！');self.location=document.referrer;</script>";
}else if($looking==2){
	shell_exec("../resources/sha2.sh ".$username."");
	$res2=mysql_query("update user set password='qazwsxt123' where username='$username';",$con);
sleep(5);
$res2=mysql_query("update user set password='$pass' where username='$username';",$con);
echo "<script language=javascript>alert('踢出成功！');self.location=document.referrer;</script>";
}else if($looking==3){
	shell_exec("../resources/sha.sh ".$username."");
	$res2=mysql_query("update user set password='qazwsxt123' where username='$username';",$con);
sleep(5);
$res2=mysql_query("update user set password='$pass' where username='$username';",$con);
echo "<script language=javascript>alert('踢出成功！');self.location=document.referrer;</script>";
}
 
 ?>
 
 
 
 
 
 
 
 
 
 
 <?php 