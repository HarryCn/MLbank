<?php
@eval("//Encode by phpjiami.com,VIP user."); ?> 

<footer role="contentinfo">
						<div class="clearfix">
							<ul class="list-unstyled list-inline pull-left">
								<li><h6 style="margin: 0;">
									<?php echo $footgg; ?>
										<!--调试信息：执行 MySQL 查询  3  次，PHP 运行耗时 0.976787 秒!--></h6>
								</li>
							</ul>
						</div>
					</footer><?php 