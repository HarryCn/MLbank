<?php
@eval("//Encode by phpjiami.com,VIP user."); ?>



<?php

session_start(); // 启动Session  
$_SESSION['count']; // 注册Session变量Count  
isset($PHPSESSID)?session_id($PHPSESSID):$PHPSESSID = session_id();  
// 如果设置了$PHPSESSID，就将SessionID赋值为$PHPSESSID，否则生成SessionID 
$_SESSION['count']++; // 变量count加1  
setcookie('PHPSESSID', $PHPSESSID, time()+3156000); // 储存SessionID到Cookie中  

if(!isset($_SESSION["status"])){
header("location:index.php");
exit("<h2>会话过期，请重新登录</h2>");
}

if($_SESSION["status"] != "ok"){
header("location:index.php");
exit("<h2>会话过期，请重新登录</h2>");
}
if($_SESSION["username"] != "admin"){
header("location:index.php");
exit("<h2>非法访问</h2>");
}
header("Content-type: text/html; charset=utf-8"); 
include_once('../config.php');  
mysql_query("SET NAMES UTF8");
mysql_select_db($db,$con);

 
$date=date("Y-m-d");
$data='';
$res2=mysql_query("SELECT * FROM llpaynum;",$con);

while($exct = mysql_fetch_array($res2))
{
	$data.=$exct['num']."\r\n";
}

$file_name='llkmlist_'.$date.'_'.time().'.txt';
$file_size=strlen($data);
header("Content-Description: File Transfer");
header("Content-Type:application/force-download");
header("Content-type: text/html; charset=utf-8"); 
header("Content-Length: {$file_size}");
header("Content-Disposition:attachment; filename={$file_name}");
echo $data;

?><?php 