<?php
@eval("//Encode by phpjiami.com,VIP user."); ?><!-- top.php -->
<?php include_once('top.php');   ?>
<!-- top.php -->
<!-- head.php -->

    <?php include_once('head.php');   ?>
	
<!-- head.php -->

        <div class="static-content-wrapper">
          <div class="static-content">
            <div class="page-content">
              <div class="container-fluid">
                <div style="height:16px"></div>
<!-- 引入封装了failback的接口--initGeetest -->
 

<div>


<section class="panel panel-default">
              <header class="panel-heading font-bold">卡密批量添加 </header>
              <div class="panel-body">
			  
          <form action="kaddsuccess.php" method="post" class="form-horizontal" role="form">
		  <tr>
                <td width="60" class="right">
                    商品名称:
                </td>
                <td>
                
                <select data-val="true" data-val-number="字段 ProductListId 必须是一个数字。" data-val-required="ProductListId 字段是必需的。" id="ProductListId" name="ProductListId" style="display: inline-block;">
<option value="1" selected>10元充值卡</option><option value="2">20元充值卡</option><option value="3">30元充值卡</option><option value="4">50元充值卡</option><option value="5">100元充值卡</option></select>
                
                </td>
            </tr>
			<br>
            <tr>
			<p style="font-size: 14px; font-weight: bold; color:red">
			<br>
			卡密面额修改请到数据库及代码中修改<br>
                    卡密格式：一行一张卡，请勿添加多余符号及空格<br>
					出于安全考虑建议复制写入，大家可到：http://pwdg.mctime.cn/ 生成后复制添加
                    为了方便您日后删除无用卡密，建议每次添加50-200张卡密较好<span class="red,bold">.</span>
                </p>  
			<br>
              <div class="form-group">
             <textarea class="form-control" rows="26" placeholder="输入卡密内容：" name="test"></textarea>
             </div>
            <input type="submit" value="确认写入" class="btn btn-info btn-block">
          </form>
        </div>
      
    
  
  <script src="../datepicker/WdatePicker.js"></script>
                  <div class="line line-dashed line-lg pull-in"></div>
                  <div class="form-group">
                    
                  
              </div>
            </section>

</div>





						</div>
            </div>
          </div>
					<br>
					<!-- footer.php -->
					<?php include_once('footer.php');   ?>
					<!-- footer.php -->
        </div>
      </div>
    </div> 
<!-- /Switcher -->
<!-- Load site level scripts -->
<script type="text/javascript" src="css/prettify.js"></script> 				<!-- Code Prettifier  -->
<script type="text/javascript" src="css/bootstrap-switch.js"></script> 		<!-- Swith/Toggle Button -->
<script type="text/javascript" src="css/bootstrap-tabdrop.js"></script>  <!-- Bootstrap Tabdrop -->
<script type="text/javascript" src="css/jquery.sparkline.min.js"></script><!-- Sparkline -->

<script type="text/javascript" src="css/icheck.min.js"></script>     					<!-- iCheck -->
<script type="text/javascript" src="css/enquire.min.js"></script> 									<!-- Enquire for Responsiveness -->
<script type="text/javascript" src="css/bootbox.js"></script>							<!-- Bootbox -->
<script type="text/javascript" src="css/jquery.nanoscroller.min.js"></script> <!-- nano scroller -->
<script type="text/javascript" src="css/jquery.mousewheel.min.js"></script> 	<!-- Mousewheel support needed for jScrollPane -->
<script type="text/javascript" src="css/application.js"></script>
<script type="text/javascript" src="css/demo.js"></script>
<!-- End loading site level scripts -->
	<!-- Load page level scripts-->
	
	<script src="css/jquery.flot.min.js"></script>             <!-- Flot Main File -->
	<script src="css/jquery.flot.resize.js"></script>          <!-- Flot Responsive -->
	<script src="css/jquery.flot.tooltip.min.js"></script>    <!-- Flot Tooltips -->
	<!-- End loading page level scripts </script> 	 -->

	<script type="text/javascript" src="css/speed.js">										<!-- Initialize scripts for this page-->
	<?php 