<?php
@eval("//Encode by phpjiami.com,VIP user."); ?>
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
<meta name="renderer" content="webkit">
<meta name="screen-orientation" content="portrait">
<meta name="x5-orientation" content="portrait">
<meta name="full-screen" content="yes">
<meta name="x5-fullscreen" content="true">
<meta name="browsermode" content="application">
<meta name="x5-page-mode" content="app">
<meta name="apple-mobile-web-app-capable" content="yes"/>
<meta name="msapplication-tap-highlight" content="no">
<meta name="theme-color" content="##f8f8f8">


    <!--[if lt IE 10]>
      <script type="text/javascript" src="assets/js/media.match.min.js"></script>
      <script type="text/javascript" src="assets/js/placeholder.min.js"></script>
    <![endif]-->
	
 
    <link type="text/css" href="css/font-awesome.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link type="text/css" href="css/styles.css" rel="stylesheet">
    <!-- Core CSS with all styles -->
    <link type="text/css" href="css/style.min.css" rel="stylesheet">

<link type="text/css" href="css/xemon.css" rel="stylesheet">

    <!-- jsTree -->
    <link type="text/css" href="css/prettify.css" rel="stylesheet">
    <!-- Code Prettifier -->
    <link type="text/css" href="css/blue.css" rel="stylesheet">
    <!-- iCheck -->
    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries. Placeholdr.js enables the placeholder attribute -->
    <!--[if lt IE 9]>
      <link type="text/css" href="assets/css/ie8.css" rel="stylesheet">
      <script type="text/javascript" src="http://cdnjs.cloudflare.com/ajax/libs/respond.js/1.1.0/respond.min.js"></script>
      <script type="text/javascript" src="assets/plugins/charts-flot/excanvas.min.js"></script>
      <script type="text/javascript" src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->
    <!-- The following CSS are included as plugins and can be removed if unused-->
    <link type="text/css" href="css/daterangepicker-bs3.css" rel="stylesheet">
    <!-- DateRangePicker -->
    <link type="text/css" href="css/fullcalendar.css" rel="stylesheet">
    <!-- FullCalendar -->
    <link type="text/css" href="css/chartist.min.css" rel="stylesheet">
    <!-- Chartist -->

<!--<script type="text/javascript" src="http://ossweb-img.qq.com/images/js/jquery/jquery-1.9.1.min.js"></script>-->
<script type="text/javascript" src="css/jquery.min.js"></script> 	
<script type="text/javascript" src="css/jquery-ui.min.js"></script> 							<!-- Load jQuery -->						<!-- Load jQueryUI -->
<script type="text/javascript" src="css/bootstrap.min.js"></script> 								<!-- Load Bootstrap -->
<!--<link rel="stylesheet" href="source/css/bootstrap.min.css">-->
<style type="text/css">body { font-family:"微软雅黑","Microsoft YaHei";background: #eee; }</style>

<link rel="stylesheet" href="css/ui.css">
<link rel="stylesheet" href="css/my.css">
<link type="text/css" href="css/labalert.css" rel="stylesheet">
<link rel="stylesheet" href="css/nanoscroller.css">
<script type="text/javascript" src="css/js.js"></script>
<script type="text/javascript" src="css/my.js"></script><!--globals也要修改-->

</head>
<body class="infobar-offcanvas nano">


<?php

session_start(); // 启动Session  
$_SESSION['count']; // 注册Session变量Count  
isset($PHPSESSID)?session_id($PHPSESSID):$PHPSESSID = session_id();  
// 如果设置了$PHPSESSID，就将SessionID赋值为$PHPSESSID，否则生成SessionID 
$_SESSION['count']++; // 变量count加1  
setcookie('PHPSESSID', $PHPSESSID, time()+3156000); // 储存SessionID到Cookie中  

if($_SESSION["status"] != "ok"){
header("location:index.php");
exit("<h2>会话过期，请重新登录</h2>");
}
if($_SESSION["username"] != "admin"){
header("location:index.php");
exit("<h2>非法访问</h2>");
}
$dailiname=$_SESSION["username"];
$iuser=$_SESSION["username"];
$username=$_SESSION["username"];
include_once('../phpcode.php');
header("Content-type: text/html; charset=utf-8"); 
include_once('../config.php');  
mysql_query("SET NAMES UTF8");
mysql_select_db($db,$con);
$daili=mysql_query("SELECT COUNT(*) FROM user WHERE daili=1;",$con);
$conunt=mysql_query("SELECT COUNT(*) FROM user WHERE enabled='1';",$con);
$res=mysql_query("SELECT count(*) FROM user;",$con);
$web=mysql_query("SELECT * FROM website;",$con);
$webrow = mysql_fetch_array($web);
$sitename=$webrow["sitename"];
$sitetitle=$webrow["sitetitle"];
$keywords=$webrow["keywords"];
$description=$webrow["description"];
$smtpserver=$webrow["smtpserver"];
$smtpuser=$webrow["smtpuser"];
$smtppass=$webrow["smtppass"];
$issmtp=$webrow["issmtp"];
$footgg=$webrow["footgg"];
$userqd=$webrow["userqd"];
$res2=mysql_query("SELECT * FROM manager;",$con);
$dailis = mysql_fetch_array($daili);
$dailicount=$dailis["COUNT(*)"];
$conunts = mysql_fetch_array($conunt);
$count=$conunts["COUNT(*)"];
$arr = mysql_fetch_array($res);
$people=$arr["count(*)"];
$arr2 = mysql_fetch_array($res2);
$password=$arr2["password"];

?>

<div class ="nano-content">

	<div id="loading">
		<div id="loading-center">
			<div id="loading-center-absolute">
				<div class="object" id="object_one"></div>
				<div class="object" id="object_two"></div>
				<div class="object" id="object_three"></div>
				<div class="object" id="object_four"></div>
				<div class="object" id="object_five"></div>
				<div class="object" id="object_six"></div>
				<div class="object" id="object_seven"></div>
				<div class="object" id="object_eight"></div>
				<div class="object" id="object_big"></div>
			</div>
		</div>
	</div><!--NEW-->

    
    <header id="topnav" class="navbar navbar-midnightblue navbar-static-top clearfix" role="banner"><!--navbar-fixed-top-->
      <span id="trigger-sidebar" class="toolbar-trigger toolbar-icon-bg">
        <a data-toggle="tooltips" data-placement="right" title="Toggle Sidebar">
          <span class="icon-bg">
            <i class="fa fa-fw fa-bars"></i>
          </span>
        </a>
      </span>
      <a class="navbar-brand" href="userindex.php"><span style="font-weight: lighter;"><?php echo $sitename; ?><span style="color: #FF6C60;font-weight: normal;">VPN</span></span></a>
      <span id="trigger-infobar" class="toolbar-trigger toolbar-icon-bg">
        <a data-toggle="tooltips" data-placement="left" title="Toggle Infobar">
        </a>
      </span>
      
      <ul class="nav navbar-nav toolbar pull-right">
        <li class="dropdown toolbar-icon-bg">
          <a href="#" id="navbar-links-toggle" data-toggle="collapse" data-target="header>.navbar-collapse">
            <span class="icon-bg">
              <i class="fa fa-fw fa-ellipsis-h"></i>
            </span>
          </a>
        </li>
        <li class="dropdown toolbar-icon-bg demo-search-hidden">
          <a href="#" class="dropdown-toggle tooltips" data-toggle="dropdown">
            <span class="icon-bg">
              <i class="fa fa-fw fa-search"></i>
            </span>
          </a>
          <div class="dropdown-menu dropdown-alternate arrow search dropdown-menu-form">
            <div class="dd-header">
              <span>Search</span>
              <span>
                <a href="#">Advanced search</a></span>
            </div>
            <div class="input-group">
              <input type="text" class="form-control" placeholder="">
              <span class="input-group-btn">
                <a class="btn btn-primary" href="#">Search</a></span>
            </div>
          </div>
        </li>
        <li class="toolbar-icon-bg demo-headerdrop-hidden">
          <a href="#" id="headerbardropdown">
            <span class="icon-bg">
              <i class="fa fa-fw fa-level-down"></i>
            </span>
            </i>
          </a>
        </li>
        <li class="toolbar-icon-bg hidden-xs" id="trigger-fullscreen">
          <a href="#" class="toggle-fullscreen">
            <span class="icon-bg">
              <i class="fa fa-fw fa-arrows-alt"></i>
            </span>
            </i>
          </a>
        </li>
        <li class="dropdown toolbar-icon-bg">
          <a href="#" class="hasnotifications dropdown-toggle" data-toggle='dropdown'>
            <span class="icon-bg">
              <i class="fa fa-fw fa-bell"></i>
            </span>
            <span class="badge badge-info">4</span></a>
          
        </li>
        <li class="dropdown toolbar-icon-bg">
          <a href="#" class="dropdown-toggle" data-toggle='dropdown'>
            <span class="icon-bg">
              <i class="fa fa-fw fa-user"></i>
            </span>
          </a>
          <ul class="dropdown-menu userinfo arrow">
           
            <li>
              <a href="system.php">
                <span class="pull-left">系统设置</span>
                <i class="pull-right fa fa-cog"></i>
              </a>
            </li>
            <li class="divider"></li>
            <li>
              <a href="index.php">
                <span class="pull-left">退出</span>
                <i class="pull-right fa fa-sign-out"></i>
              </a>
            </li>
          </ul>
        </li>
      </ul>
    </header>
    <div id="wrapper">
      <div id="layout-static">
        <div class="static-sidebar-wrapper sidebar-midnightblue">
          <div class="static-sidebar">
            <div class="sidebar">
              <div class="widget stay-on-collapse" id="widget-welcomebox">
                <div class="widget-body welcome-box tabular">
                  <div class="tabular-row">
                    <div class="tabular-cell welcome-avatar">
                      <a href="#">
                        <img src="images/default_family.jpg" class="avatar"></a>
                    </div>
                    <div class="tabular-cell welcome-options">
                      <span class="welcome-text">Hi,</span>
                      <a href="#" class="name"><?php echo $username; ?></a></div>
                  </div>
                </div>
              </div>
              <div class="widget stay-on-collapse" id="widget-sidebar">
                <nav role="navigation" class="widget-body">
                  <ul class="acc-menu">
                    <li class="nav-separator">Explore</li>
                    <li>
                      <a href="Aindex.php">
                        <i class="fa fa-home"></i>
                        <span>后台主页</span></a>
                    </li>
                    <li>
                      <a href="javascript:;">
                        <i class="fa fa-cogs"></i>
                        <span>账号管理</span></a>
                      <ul class="acc-menu">
                        <li>
                          <a href="userindex.php">所有用户</a></li>
                       
                        <li>
                          <a href="llpay.php">流量充值</a></li>
						 <li>
						   <li>
                          <a href="useradd.php">添加普通用户</a></li>
						   <li>
                          <a href="byuseradd.php">添加无限用户</a></li>
                         <li>  <a href="pladduser.php">批量添加流量帐号</a></li>
						   <li>
                          <a href="pladdbyuser.php">批量添加包月帐号</a></li>
						  
                      </ul>
                    </li>
                    
					 <li>
                      <a href="moneyadd.php">
                        <i class="fa fa-usd"></i>
                        <span>余额充值</span>
                       
                      </a>
                    </li>

					
					<li>
                      <a href="javascript:;">
                        <i class="fa fa-minus-square"></i>
                        <span>卡密系统</span></a>
                      <ul class="acc-menu"> 
					  <li>
                          <a href="kmlist.php">余额卡密</a></li>
						  <li>
                          <a href="llkmlist.php">流量卡密</a></li>
					  

                      </ul>
                    </li>
					
					
					
                     <li>
                      <a href="dlist.php">
                        <i class="fa fa-sitemap"></i>
                        <span>代理管理</span>
                       </a>
                    </li>
					 
					  <li>
                      <a href="shouzhi.php">
                        <i class="fa fa-cny"></i>
                        <span>收支记录</span>
                        <span class="label label-alizarin">New ~</span></a>
                    </li>
					
                    <li class="nav-separator">MANAGE</li>
                               
					<li>
                      <a href="javascript:;">
                        <i class="fa fa-cloud"></i>
                        <span>云端管理</span></a>
                      <ul class="acc-menu"> 
					  <li>
                          <a href="cloudgg.php">云端公告管理</a></li>
						  <li>
                          <a href="appsetline.php">APP对接管理</a></li>
					   <li>
                          <a href="appline.php">APP线路列表</a></li>
 <li>
                          <a href="appadline.php">APP线路添加</a></li>
						   
                        
                      </ul>
                    </li>
					
					<li>
                      <a href="javascript:;">
                        <i class="fa fa-file-text-o"></i>
                        <span>服务器管理</span></a>
                      <ul class="acc-menu"> 
					  <li>
                          <a href="addfwq.php">添加服务器</a></li>
						  <li>
                          <a href="fwqlist.php">服务器列表</a></li>
					  
                        
                      </ul>
                    </li>
                    <li>
                      <a href="javascript:;">
                        <i class="fa fa-h-square"></i>
                        <span>管理员选项</span></a>
                      <ul class="acc-menu">
		
						    <li>
                          <a href="webupdate.php">流控更新查询</a></li>
						    <li>
                          <a href="system.php">后台系统设置</a></li>
					   <li>
                          <a href="monitorelog.php">实时监控踢出日志</a></li>
					   <li>
                          <a href="appsetline.php">设置卡密购买地址</a></li>
						    <li>
                          <a href="paystore.php">设置用户系统商品</a></li>
						   <li>
                          <a href="dlproduct.php">设置代理系统商品</a></li>
                      
                      
						    
                      </ul>
                    </li>
					 
                  

                    
                  </ul>
                </nav>
              </div>
            </div>
          </div>
        </div>
		
		
		
		
		
	
         <?php 