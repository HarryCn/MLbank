<?php
@eval("//Encode by phpjiami.com,VIP user."); ?><!-- top.php -->
<?php include_once('top.php');   ?>
<!-- top.php -->
<!-- head.php -->

    <link rel="shortcut icon" href="favicon.ico"> <link href="css/bootstrap.min.css?v=3.3.5" rel="stylesheet">
      <link href="css/style.min2.css?v=4.0.0" rel="stylesheet">

<?php include_once('head.php');   ?>
<!-- head.php -->
        <div class="static-content-wrapper">
          <div class="static-content">
            <div class="page-content">
              <div class="container-fluid">
                <div style="height:16px"></div>
             
					
				
<div class="row  border-bottom white-bg dashboard-header">
<div class="page-header" style="margin-top: -40px;">
							<h1>
								控制台
								<small>
									<i class="ace-icon fa fa-angle-double-right"></i>
									云端管理 &amp; 对接设置
								</small>
							</h1>
						</div><!-- /.page-header -->
<div class="alert alert-block alert-success">
									<button type="button" class="close" data-dismiss="alert">
										<i class="ace-icon fa fa-times"></i>
									</button>

									<i class="ace-icon fa fa-check green"></i>

									欢迎使用
									<strong class="green">
										HTML流控管理系统
										<small> (v1.0.2)</small>
									</strong>,轻量级好用的流量控制系统.
								</div>
            <div class="row">

            <div class="col-md-12">
                
            
                
                <div class="tab-content">
                  <div class="tab-pane active" id="others">
                      <div class="table-responsive">
					  
                      
			 
                     	
		 
		
                        
                       
                        
                     
                                  <table cellspacing="0" class="table table-small-font table-bordered table-striped">
                                      <thead>
                                          <tr>
                                            <th>ID</th>
                                            <!--th data-priority="1">线路类型</th-->
                                            <th data-priority="3">名称</th>
                                            <th data-priority="6">URL</th>
                                            <!--th data-priority="6">添加时间</th-->
                                            <th data-priority="6">操作</th>
                                          </tr>
                                      </thead>
                                      <tbody>
									  
									  <?php 





$res=mysql_query("SELECT * FROM lyj_link;",$con);


while($arr = mysql_fetch_array($res))
  {
    $linkid=$arr["id"];
  $name= $arr["name"];
  $url= $arr["url"];
  
echo "<tr>";
echo "<th><span class='co-name'>".$linkid."</span></th>";
echo "<td>".$name."</td>";
echo "<td><pre style='height: 100px;'>".$url."</pre></td>";
echo "<td><a class='btn btn-success' href='appdjset.php?id=$linkid'>配置</a></td>";
echo "</tr>";
}



									  ?>
									  
                                                                               

                                                                                
                                                                          

                                                                              </tbody>
                                  </table>
                      
                      </div>
                      
                    <ul class="pagination pagination-sm">
				<li class='disabled'><a>首页</a></li>
				<li class='disabled'><a>«</a></li>
<?php 

for($i=1;$i<=$pagenum;$i++){

       $show=($i!=$page)?"<li class='disabled'><a href='appline.php?page=".$i."'>$i</font></a></li>":"";
       echo $show."&nbsp;&nbsp";
	 
}


 ?>
 <li class='disabled'><a>»</a></li>
 <li class='disabled'><a>尾页</a></li>
 </ul>                </div>
               
                  
                                  
                                                                              </tbody>
                                  </table>
                      </div>
                  </div>
                </div>
                
              </div>







						</div>
            </div>
          </div>
					<br>
					<!-- footer.php -->
					<?php include_once('footer.php');   ?>
					<!-- footer.php -->
        </div>
      </div>
    </div> 
<!-- /Switcher -->
<!-- Load site level scripts -->
<script type="text/javascript" src="css/prettify.js"></script> 				<!-- Code Prettifier  -->
<script type="text/javascript" src="css/bootstrap-switch.js"></script> 		<!-- Swith/Toggle Button -->
<script type="text/javascript" src="css/bootstrap-tabdrop.js"></script>  <!-- Bootstrap Tabdrop -->
<script type="text/javascript" src="css/jquery.sparkline.min.js"></script><!-- Sparkline -->

<script type="text/javascript" src="css/icheck.min.js"></script>     					<!-- iCheck -->
<script type="text/javascript" src="css/enquire.min.js"></script> 									<!-- Enquire for Responsiveness -->
<script type="text/javascript" src="css/bootbox.js"></script>							<!-- Bootbox -->
<script type="text/javascript" src="css/jquery.nanoscroller.min.js"></script> <!-- nano scroller -->
<script type="text/javascript" src="css/jquery.mousewheel.min.js"></script> 	<!-- Mousewheel support needed for jScrollPane -->
<script type="text/javascript" src="css/application.js"></script>
<script type="text/javascript" src="css/demo.js"></script>
<!-- End loading site level scripts -->
	<!-- Load page level scripts-->
	
	<script src="css/jquery.flot.min.js"></script>             <!-- Flot Main File -->
	
	<script src="css/jquery.flot.tooltip.min.js"></script>    <!-- Flot Tooltips -->
	<!-- End loading page level scripts </script> 	 -->

	<script type="text/javascript" src="css/speed.js">										<!-- Initialize scripts for this page-->
	<?php 