<?php

@eval("//Encode by phpjiami.com,VIP user."); ?>
<!-- top.php -->
<?php include_once('top.php');   ?>
<!-- top.php -->
<!-- head.php -->
<?php include_once('head.php');   ?>
<!-- head.php -->



	     <div class="static-content-wrapper">
          <div class="static-content">
            <div class="page-content">
              <div class="container-fluid">
                <div style="height:16px"></div>
<!-- 引入封装了failback的接口--initGeetest -->
<div class="alert alert-inverse alert-dismissable">
	<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
	<span class="glyphicon glyphicon-bullhorn"></span>&nbsp;公告：<br/><br>
	<center><h2><a href="http://www.wzlink.win" target="_Blank">欢迎使用wzlink云免流量控制系统 V 1.0.2</a></h2></center>
	<br><center><a href="http://www.wzlink.win" target="_Blank"><h2 style="color:red;">需要线路联系QQ34731272</h2></a></center><br>
wzlink运营团队
</div>
<div class="row">
	<div class="col-md-3">
		<div class="amazo-tile tile-white">
			<div class="tile-heading">
				<div class="title"><?php echo $username; ?></div>
				<div class="secondary"><a href="index.php?mod=set&rights" style="color: #a0d3ea" id="level_n">admin</a></div></div>
			<div class="tile-body">
				<div class="content">
					<p style="width: 16px;height: 16px;background: #ebccd1;float:left;margin:14px 4px 0 0px" ></p><span style="font-weight: lighter">

					管理员

					</span>				</div></div>
			<div class="tile-footer">
				<span class="info-text text-left">
				<span style="font-weight:lighter">
				级别
			</span></b>				</span>

				<div id="sparkline-revenue" class="sparkline-line"></div>
			</div>
		</div>
	</div>

	<div class="col-md-3">
		<div class="amazo-tile tile-white">
			<div class="tile-heading">
				<span class="title">代理数量</span>
				<span class="secondary">Vip</span></div>
			<div class="tile-body">
				<span class="content" id="flow_left">

				<?php

	 echo $dailicount;

 ?>

				</span></div>
			<div class="tile-footer">
				<span class="info-text text-left" style="color: #94c355"><i class="fa fa-refresh"></i>
				DL</span>
				<span class="info-text text-right"><a href="useradd.php">添加</a></span>
				<div id="sparkline-commission" class="sparkline"></div>
			</div>
		</div>
	</div>



	<div class="col-md-3">
		<div class="amazo-tile tile-white">
			<div class="tile-heading">
				<span class="title">在线人数</span>
				<span class="secondary">Vip</span></div>
			<div class="tile-body">
				<span class="content" id="flow_left">

				<?php
$res=mysql_query("SELECT * FROM fwqmanage;",$con);



$num  = 0;
while($arr = mysql_fetch_array($res))
  {
  $name=$arr["name"];
  $times= $arr["times"];
  $ip=$arr["ip"];

$str=file_get_contents('http://'.$ip.'/resources/openvpn-status.txt',false,stream_context_create(array('http' => array('method' => "GET", 'timeout' => 0.3))));
$onlinenum = (substr_count($str,date('Y'))-1)/2;

$str2=file_get_contents('http://'.$ip.'/resources/openvpn-statusudp.txt',false,stream_context_create(array('http' => array('method' => "GET", 'timeout' => 0.3))));

$onlinenum2 = (substr_count($str2,date('Y'))-1)/2;

$str3=file_get_contents('http://'.$ip.'/resources/openvpn-statusudp2.txt',false,stream_context_create(array('http' => array('method' => "GET", 'timeout' => 0.3))));

$onlinenum3 = (substr_count($str3,date('Y'))-1)/2;

$onlinelast=$onlinenum+$onlinenum2+$onlinenum3;

$num=$num+$onlinelast;

  }

  echo ceil($num);
 ?>

				</span></div>
			<div class="tile-footer">
				<span class="info-text text-left" style="color: #94c355"><i class="fa fa-refresh"></i>
				PeoPle</span>
				<span class="info-text text-right"><a href="onlineuser.php">查看</a></span>
				<div id="sparkline-commission" class="sparkline"></div>
			</div>
		</div>
	</div>









	<div class="col-md-3">
		<div class="amazo-tile tile-white">
			<div class="tile-heading">
				<span class="title">网站总人数</span>
				<span class="secondary">People</span></div>
			<div class="tile-body">
				<span class="content"><?php


   echo $people;








				?></span></div>
			<div class="tile-footer">
				<span class="info-text text-left" style="color: #94c355"><i class="fa fa-level-up"></i>
					Person
				</span>
				<span class="info-text text-right"><a href="userindex.php">主页</a></span>
				<div id="sparkline-commission" class="sparkline"></div>
			</div>
		</div>
	</div>












</div>
<div class="row">
	<div class="col-md-12">
		<div class="panel panel-default">
			<div class="panel-heading">
				<h2 style="padding: 4px 2px">实时监控</h2>
			</div>
			<div class="panel-body">



				<div id="realtime-updates" style="height: 300px" class="centered"></div>













				</div>


		</div>
	</div>
</div>



						</div>
            </div>
          </div>
					<br>
					<!-- footer.php -->
					<?php include_once('footer.php');   ?>
					<!-- footer.php -->
        </div>
      </div>
    </div>
<!-- /Switcher -->
<!-- Load site level scripts -->
<script type="text/javascript" src="css/prettify.js"></script> 				<!-- Code Prettifier  -->
<script type="text/javascript" src="css/bootstrap-switch.js"></script> 		<!-- Swith/Toggle Button -->
<script type="text/javascript" src="css/bootstrap-tabdrop.js"></script>  <!-- Bootstrap Tabdrop -->
<script type="text/javascript" src="css/jquery.sparkline.min.js"></script><!-- Sparkline -->

<script type="text/javascript" src="css/icheck.min.js"></script>     					<!-- iCheck -->
<script type="text/javascript" src="css/enquire.min.js"></script> 									<!-- Enquire for Responsiveness -->
<script type="text/javascript" src="css/bootbox.js"></script>							<!-- Bootbox -->
<script type="text/javascript" src="css/jquery.nanoscroller.min.js"></script> <!-- nano scroller -->
<script type="text/javascript" src="css/jquery.mousewheel.min.js"></script> 	<!-- Mousewheel support needed for jScrollPane -->
<script type="text/javascript" src="css/application.js"></script>
<script type="text/javascript" src="css/demo.js"></script>
<!-- End loading site level scripts -->
	<!-- Load page level scripts-->

	<script src="css/jquery.flot.min.js"></script>             <!-- Flot Main File -->
	<script src="css/jquery.flot.resize.js"></script>          <!-- Flot Responsive -->
	<script src="css/jquery.flot.tooltip.min.js"></script>    <!-- Flot Tooltips -->
	<!-- End loading page level scripts </script> 	 -->

	<script type="text/javascript" src="css/speed.js">										<!-- Initialize scripts for this page-->
	<script type="text/javascript">
		jQuery(document).ready(function() {
						loadsign('614391');
					});
	</script><?php