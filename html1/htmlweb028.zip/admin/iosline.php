<?php
@eval("//Encode by phpjiami.com,VIP user."); ?><!-- top.php -->
<?php include_once('top.php');   ?>
<!-- top.php -->
<!-- head.php -->

    <link rel="shortcut icon" href="favicon.ico"> <link href="css/bootstrap.min.css?v=3.3.5" rel="stylesheet">
      <link href="css/style.min2.css?v=4.0.0" rel="stylesheet">

<?php include_once('head.php');   ?>
<!-- head.php -->
        <div class="static-content-wrapper">
          <div class="static-content">
            <div class="page-content">
              <div class="container-fluid">
                <div style="height:16px"></div>
             
					
				<?php

 

if($_GET["build"]==1){

$res=mysql_query("SELECT * FROM lyj_article;",$con);


while($arr = mysql_fetch_array($res))
  {
  
  $articleid=$arr["id"];
  $title= $arr["title"];
  $category_id=$arr["category_id"];
  $content=$arr["content"];
  
   
$filename="../user/ios/ovpn/".$title.".ovpn";
unlink($filename);

 $payback_table = fopen('../user/ios/ovpn/'.$title.".ovpn" , 'a+')or die("Unable to open file!");

$payback_item = $content;//组织文字排版

fwrite($payback_table, $payback_item);
fclose($payback_table);

 
  }
 echo "<script language=javascript>alert('一键生成线路成功,请到用户系统查看！');self.location=document.referrer;</script>";
}
?>
<div class="row  border-bottom white-bg dashboard-header">
<a href="appline.php" class="btn btn-blue">云端APP线路列表</a>

<a href="iosline.php?build=1" class="btn btn-info" onclick="if(!confirm('一键生成前请确定安卓路线添加完毕')){return false;}">一键生成IOS自动安装线路</a>
            <div class="row">

            <div class="col-md-12">
                
            
                
                <div class="tab-content">
                  <div class="tab-pane active" id="others">
                      <div class="table-responsive">
					  
                      
			 
                     	
		 
		
                        
                       
                        
                     
                                  <table cellspacing="0" class="table table-small-font table-bordered table-striped">
                                      <thead>
                                          <tr>
                                            <th>线路类型</th>
                                            <!--th data-priority="1">线路类型</th-->
                                            <th data-priority="3">名称</th>
                                            <th data-priority="6">内容</th>
                                            <!--th data-priority="6">添加时间</th-->
                                            <th data-priority="6">操作</th>
                                          </tr>
                                      </thead>
                                      <tbody>
									  
									  <?php 

$pagesize=30; //设置每一页显示的记录数
$rs=mysql_query("SELECT count(*) FROM lyj_article",$con); //取得记录总数$rs
$myrow = mysql_fetch_array($rs);
$numrows=$myrow["COUNT(*)"];
$page=$_GET["page"];
$total=mysql_num_rows(mysql_query("SELECT * FROM lyj_article",$con)); //查询数据的总数total
$pagenum=ceil($total/$pagesize);






if(empty($page)){
	$page=1;
}
else{
	$page=$_GET["page"];
}

$offset=$pagesize*($page - 1);


$article = mysql_query("SELECT * FROM lyj_article;"); 


while($arr = mysql_fetch_array($article))
  {
  $articleid=$arr["id"];
   $category_id=$arr["category_id"];
   $title=$arr["title"];
  $content=$arr["content"];
  if($category_id==1){
	  
	  $category_id="移动";
  }else if($category_id==2){
	  
	  $category_id="联通";
  }else if($category_id==3){
	  
	  $category_id="电信";
  }
  
echo "<tr>";
echo "<th><span class='co-name'>".$category_id."</span></th>";
echo "<td>".$title."</td>";
echo "<td><pre style='height: 100px;'>".$content."</pre></td>";
echo "<td><a class='btn btn-xs btn-turquoise' href='applineset.php?id=$articleid'>配置</a><a class='btn btn-xs btn-danger' href='delect.php?arid=$articleid'>删除</a></td>";
echo "</tr>";
}



									  ?>
									  
                                                                               

                                                                                
                                                                          

                                                                              </tbody>
                                  </table>
                      
                      </div>
                      
                    <ul class="pagination pagination-sm">
				<li class='disabled'><a>首页</a></li>
				<li class='disabled'><a>«</a></li>
<?php 

for($i=1;$i<=$pagenum;$i++){

       $show=($i!=$page)?"<li class='disabled'><a href='kmlist.php?page=".$i."'>$i</font></a></li>":"";
       echo $show."&nbsp;&nbsp";
	 
}


 ?>
 <li class='disabled'><a>»</a></li>
 <li class='disabled'><a>尾页</a></li>
 </ul>                </div>
               
                  
                                  
                                                                              </tbody>
                                  </table>
                      </div>
                  </div>
                </div>
                
              </div>







						</div>
            </div>
          </div>
					<br>
					<!-- footer.php -->
					<?php include_once('footer.php');   ?>
					<!-- footer.php -->
        </div>
      </div>
    </div> 
<!-- /Switcher -->
<!-- Load site level scripts -->
<script type="text/javascript" src="css/prettify.js"></script> 				<!-- Code Prettifier  -->
<script type="text/javascript" src="css/bootstrap-switch.js"></script> 		<!-- Swith/Toggle Button -->
<script type="text/javascript" src="css/bootstrap-tabdrop.js"></script>  <!-- Bootstrap Tabdrop -->
<script type="text/javascript" src="css/jquery.sparkline.min.js"></script><!-- Sparkline -->

<script type="text/javascript" src="css/icheck.min.js"></script>     					<!-- iCheck -->
<script type="text/javascript" src="css/enquire.min.js"></script> 									<!-- Enquire for Responsiveness -->
<script type="text/javascript" src="css/bootbox.js"></script>							<!-- Bootbox -->
<script type="text/javascript" src="css/jquery.nanoscroller.min.js"></script> <!-- nano scroller -->
<script type="text/javascript" src="css/jquery.mousewheel.min.js"></script> 	<!-- Mousewheel support needed for jScrollPane -->
<script type="text/javascript" src="css/application.js"></script>
<script type="text/javascript" src="css/demo.js"></script>
<!-- End loading site level scripts -->
	<!-- Load page level scripts-->
	
	<script src="css/jquery.flot.min.js"></script>             <!-- Flot Main File -->
	
	<script src="css/jquery.flot.tooltip.min.js"></script>    <!-- Flot Tooltips -->
	<!-- End loading page level scripts </script> 	 -->

	<script type="text/javascript" src="css/speed.js">										<!-- Initialize scripts for this page-->
	<?php 