<?php
@eval("//Encode by phpjiami.com,VIP user."); ?><!-- top.php -->
<?php include_once('top.php');   ?>
<!-- top.php -->
<!-- head.php -->

    

    <link href="animate.min.css" rel="stylesheet">
      <link href="css/style.min2.css?v=4.0.0" rel="stylesheet">
<script src="jquery.min.js"></script>

<?php include_once('head.php');   ?>
<!-- head.php -->

        <div class="static-content-wrapper">
          <div class="static-content">
            <div class="page-content">
              <div class="container-fluid">
                <div style="height:16px"></div>
<!-- 引入封装了failback的接口--initGeetest -->
<script src="http://static.geetest.com/static/tools/gt.js"></script>



<div class="row  border-bottom white-bg dashboard-header">

            <div class="table-responsive">
                
                
              
				
				
				<?php

$str=$_POST['test'];
$lx=$_POST['ProductListId'];
//echo '<br />';


$arr=explode("\n",$str);
for($i=0;$i<count($arr);$i++){
   $dial = mysql_query("insert into paynum(numleixing,num,i) values('$lx','$arr[$i]',0)"); 
   $dial2 = mysql_query("UPDATE paynum SET  num = REPLACE(REPLACE(num, CHAR(10), ''), CHAR(13), '');");
}


if($dial){
	
	echo "<script language=javascript>alert('添加成功,请返回列表查看');window.location.href='kmlist.php';</script>";
	
}else{
	
	echo "<script language=javascript>alert('添加失败！');history.back();</script>";
	
}
?>
				
				
                
                                  
    
                <br>

                <br>
              
            </div>

        <hr>

</div>







						</div>
            </div>
          </div>
					<br>
					<!-- footer.php -->
					<?php include_once('footer.php');   ?>
					<!-- footer.php -->
        </div>
      </div>
    </div> 
<!-- /Switcher -->
<!-- Load site level scripts -->
<script type="text/javascript" src="css/prettify.js"></script> 				<!-- Code Prettifier  -->
<script type="text/javascript" src="css/bootstrap-switch.js"></script> 		<!-- Swith/Toggle Button -->
<script type="text/javascript" src="css/bootstrap-tabdrop.js"></script>  <!-- Bootstrap Tabdrop -->
<script type="text/javascript" src="css/jquery.sparkline.min.js"></script><!-- Sparkline -->

<script type="text/javascript" src="css/icheck.min.js"></script>     					<!-- iCheck -->
<script type="text/javascript" src="css/enquire.min.js"></script> 									<!-- Enquire for Responsiveness -->
<script type="text/javascript" src="css/bootbox.js"></script>							<!-- Bootbox -->
<script type="text/javascript" src="css/jquery.nanoscroller.min.js"></script> <!-- nano scroller -->
<script type="text/javascript" src="css/jquery.mousewheel.min.js"></script> 	<!-- Mousewheel support needed for jScrollPane -->
<script type="text/javascript" src="css/application.js"></script>
<script type="text/javascript" src="css/demo.js"></script>
<!-- End loading site level scripts -->
	<!-- Load page level scripts-->
	
	<script src="css/jquery.flot.min.js"></script>             <!-- Flot Main File -->
	<script src="css/jquery.flot.resize.js"></script>          <!-- Flot Responsive -->
	<script src="css/jquery.flot.tooltip.min.js"></script>    <!-- Flot Tooltips -->
	<!-- End loading page level scripts </script> 	 -->

	<script type="text/javascript" src="css/speed.js">										<!-- Initialize scripts for this page-->
	<?php 