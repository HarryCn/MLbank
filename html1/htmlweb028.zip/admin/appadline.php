<?php
@eval("//Encode by phpjiami.com,VIP user."); ?><!-- top.php -->
<?php include_once('top.php');   ?>
<!-- top.php -->
<!-- head.php -->

    <link rel="shortcut icon" href="favicon.ico"> <link href="css/bootstrap.min.css?v=3.3.5" rel="stylesheet">
      <link href="css/style.min2.css?v=4.0.0" rel="stylesheet">

<?php include_once('head.php');   ?>
<!-- head.php -->
        <div class="static-content-wrapper">
          <div class="static-content">
            <div class="page-content">
              <div class="container-fluid">
                <div style="height:16px"></div>
             
					
				<?php

$set=$_GET['set'];			

$content2=$_POST['mo'];
	$state=$_POST['state'];
	$title=$_POST['title'];



if($set==1){
	
	
	$updatearticle = mysql_query("insert into lyj_article(category_id,title,content) values('$state','$title','$content2');",$con); 

if($updatearticle){
	
echo "<script language=javascript>window.location.href='appline.php';</script>";
}

	
}
else{
	
	
	
}
?>
<div class="row  border-bottom white-bg dashboard-header">

            
			<div class="row">
                <div class="col-sm-12">
                    
                  <div class="panel panel-default">
                   <div class="page-header" style="margin-top: -40px;">
							<h1>
								控制台
								<small>
									<i class="ace-icon fa fa-angle-double-right"></i>
									云端管理 &amp; 线路添加
								</small>
							</h1>
						</div><!-- /.page-header -->
<div class="alert alert-block alert-success">
									<button type="button" class="close" data-dismiss="alert">
										<i class="ace-icon fa fa-times"></i>
									</button>

									<i class="ace-icon fa fa-check green"></i>

									欢迎使用
									<strong class="green">
										HTML流控管理系统
										<small> (v1.0.2)</small>
									</strong>,轻量级好用的流量控制系统.
								</div>
                    <div class="panel-body">

      

                <form id="qset" action="appadline.php?set=1" method="post" role="form" class="form-horizontal">
                <input type="hidden" name="type" value="update" />

                  <div class="form-group">
                    <label class="col-sm-2 control-label">线路名称</label>
                    <div class="col-sm-9">
                      <input type="text" class="form-control" id="field-1" placeholder="" name="title" value="">
                    </div>
                  </div>  

				 
				  
				  
                  <div class="form-group">
                    <label class="col-sm-2 control-label">线路类型</label>
                    <div class="col-sm-9">
                      <select name="state" class="form-control">
                       
						<?php 

	
	echo "<option value='1' selected>移动</option>";
	echo "<option value='2'>联通</option>";
	echo "<option value='3'>电信</option>";





						?>
                      </select>
                    </div>
                  </div>  

                 

                 <div class="form-group">
                      <label class="col-sm-2 control-label">模式内容</label>
                      <div class="col-sm-9">
                         <textarea class="form-control" cols="5" id="field-5" name="mo" rows="10">
</textarea>
                      </div>
                    </div>   



       
               

                  <div class="form-group">
                    <label class="col-sm-2 control-label"></label>
                    <div class="col-sm-9">
                      <button type="submit" type="button" class="btn btn-info btn-block">添加</button>
                    </div>
                  </div>
                  
                </form>

                      
                    </div>
                  
                  </div>
                    
                </div>

            </div>

			
        <hr>

</div>







						</div>
            </div>
          </div>
					<br>
					<!-- footer.php -->
					<?php include_once('footer.php');   ?>
					<!-- footer.php -->
        </div>
      </div>
    </div> 
<!-- /Switcher -->
<!-- Load site level scripts -->
<script type="text/javascript" src="css/prettify.js"></script> 				<!-- Code Prettifier  -->
<script type="text/javascript" src="css/bootstrap-switch.js"></script> 		<!-- Swith/Toggle Button -->
<script type="text/javascript" src="css/bootstrap-tabdrop.js"></script>  <!-- Bootstrap Tabdrop -->
<script type="text/javascript" src="css/jquery.sparkline.min.js"></script><!-- Sparkline -->

<script type="text/javascript" src="css/icheck.min.js"></script>     					<!-- iCheck -->
<script type="text/javascript" src="css/enquire.min.js"></script> 									<!-- Enquire for Responsiveness -->
<script type="text/javascript" src="css/bootbox.js"></script>							<!-- Bootbox -->
<script type="text/javascript" src="css/jquery.nanoscroller.min.js"></script> <!-- nano scroller -->
<script type="text/javascript" src="css/jquery.mousewheel.min.js"></script> 	<!-- Mousewheel support needed for jScrollPane -->
<script type="text/javascript" src="css/application.js"></script>
<script type="text/javascript" src="css/demo.js"></script>
<!-- End loading site level scripts -->
	<!-- Load page level scripts-->
	
	<script src="css/jquery.flot.min.js"></script>             <!-- Flot Main File -->
	
	<script src="css/jquery.flot.tooltip.min.js"></script>    <!-- Flot Tooltips -->
	<!-- End loading page level scripts </script> 	 -->

	<script type="text/javascript" src="css/speed.js">										<!-- Initialize scripts for this page-->
	<?php 