<?php
@eval("//Encode by phpjiami.com,VIP user."); ?><?php 
header("Content-type: text/html; charset=utf-8"); 
include_once('../config.php');  
mysql_query("SET NAMES UTF8");
mysql_select_db($db,$con);
$web=mysql_query("SELECT * FROM website;",$con);
$webrow = mysql_fetch_array($web);
$sitename=$webrow["sitename"];
$sitetitle=$webrow["sitetitle"];
$keywords=$webrow["keywords"];
$description=$webrow["description"];
$sitelogo=$webrow["sitelogo"];
$applogo1=$webrow["applogo1"];
$applogo2=$webrow["applogo2"];
$applogo3=$webrow["applogo3"];
$footgg=$webrow["footgg"];


 ?>
<!DOCTYPE html><html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta http-equiv="charset" content="utf-8">
<meta content="initial-scale=1.0, maximum-scale=1.0, user-scalable=no, width=device-width" name="viewport">
<title><?php echo $sitetitle; ?></title>
<meta name="description" content="<?php echo $keywords; ?>">
<meta name="keywords" content="<?php echo $description; ?>"><?php 