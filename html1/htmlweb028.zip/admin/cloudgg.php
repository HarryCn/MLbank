<?php
@eval("//Encode by phpjiami.com,VIP user."); ?><!-- top.php -->
<?php include_once('top.php');   ?>
<!-- top.php -->
<!-- head.php -->

    <link rel="shortcut icon" href="favicon.ico"> <link href="" rel="stylesheet">

     
      <link href="css/style.min2.css?v=4.0.0" rel="stylesheet">
 

<?php include_once('head.php');   ?>

<!-- head.php -->

        <div class="static-content-wrapper">
          <div class="static-content">
            <div class="page-content">
              <div class="container-fluid">
                <div style="height:16px"></div>
<!-- 引入封装了failback的接口--initGeetest -->



<?php







$appfile="../gg.txt"; 
$appconn=file_get_contents($appfile); 
$appconn=str_replace("rn","<br/>",file_get_contents($appfile)); 

$userfile="../daili/dailigg.txt"; 
$dailiconn=file_get_contents($userfile); 
$dailiconn=str_replace("rn","<br/>",file_get_contents($userfile)); 

$dailifile="../user/usergg.txt"; 
$userconn=file_get_contents($dailifile); 
$userconn=str_replace("rn","<br/>",file_get_contents($dailifile)); 



if($_GET["type"]=="app"){


$myfile = fopen("../gg.txt", "w") or die("Unable to open file!");
fwrite($myfile, $_POST["appcontent"]);
fclose($myfile);
echo "<script language=JavaScript>window.location.href='cloudgg.php';</script>";
}else if($_GET["type"]=="user"){
	
	$myfile = fopen("../user/usergg.txt", "w") or die("Unable to open file!");

fwrite($myfile, $_POST["usercontent"]);
fclose($myfile);
echo "<script language=JavaScript>window.location.href='cloudgg.php';</script>";
	
}else if($_GET["type"]=="daili"){
	
	$myfile = fopen("../daili/dailigg.txt", "w") or die("Unable to open file!");

fwrite($myfile, $_POST["dailicontent"]);
fclose($myfile);
echo "<script language=JavaScript>window.location.href='cloudgg.php';</script>";
	
}else{
	
}



?>

<div>
 <div class="page-header" style="margin-top: -40px;">
							<h1>
								控制台
								<small>
									<i class="ace-icon fa fa-angle-double-right"></i>
									云端管理 &amp; 公告管理
								</small>
							</h1>
						</div><!-- /.page-header -->
<div class="alert alert-block alert-success">
									<button type="button" class="close" data-dismiss="alert">
										<i class="ace-icon fa fa-times"></i>
									</button>

									<i class="ace-icon fa fa-check green"></i>

									欢迎使用
									<strong class="green">
										HTML流控管理系统
										<small> (v1.0.2)</small>
									</strong>,轻量级好用的流量控制系统.
								</div>
<section class="panel panel-default">
              <header class="panel-heading font-bold">APP公告信息 </header>
              <div class="panel-body">
          <form action="cloudgg.php?type=app" method="post" class="form-horizontal" role="form">
              <div class="form-group"><label>&nbsp;&nbsp;公告内容：</label>
              <textarea class="form-control diff-textarea" placeholder="输入公告内容" name="appcontent" rows="6"><?php echo $appconn; ?></textarea>
             </div>
            <input type="submit" value="确认写入" class="btn btn-info btn-block">
          </form>
        </div>
      
    
  
  <script src="../datepicker/WdatePicker.js"></script>
                  <div class="line line-dashed line-lg pull-in"></div>
                  <div class="form-group">
                    
                  
              </div>
            </section>
			
			
			
			
			<section class="panel panel-default">
              <header class="panel-heading font-bold">用户系统公告信息 </header>
               <div class="panel-body">
          <form action="cloudgg.php?type=user" method="post" class="form-horizontal" role="form">
              <div class="form-group"><label>&nbsp;&nbsp;公告内容：</label>
              <textarea class="form-control diff-textarea" placeholder="输入公告内容" name="usercontent" rows="6"><?php echo $userconn; ?></textarea>
             </div>
            <input type="submit" value="确认写入" class="btn btn-info btn-block">
          </form>
        </div>
      
    
  
  <script src="../datepicker/WdatePicker.js"></script>
                  <div class="line line-dashed line-lg pull-in"></div>
                  <div class="form-group">
                    
                  
              </div>
            </section>
			
			
			
			<section class="panel panel-default">
              <header class="panel-heading font-bold">代理系统公告信息 </header>
              <div class="panel-body">
          <form action="cloudgg.php?type=daili" method="post" class="form-horizontal" role="form">
              <div class="form-group"><label>&nbsp;&nbsp;公告内容：</label>
              <textarea class="form-control diff-textarea" placeholder="输入公告内容" name="dailicontent" rows="6"><?php echo $dailiconn; ?></textarea>
             </div>
            <input type="submit" value="确认写入" class="btn btn-info btn-block">
          </form>
        </div>
      
    
  
  <script src="../datepicker/WdatePicker.js"></script>
                  <div class="line line-dashed line-lg pull-in"></div>
                  <div class="form-group">
                    
                  
              </div>
            </section>
			
			
			
			
			
			

</div>


          </div>
					<br>
					<!-- footer.php -->
					<?php include_once('footer.php');   ?>
					<!-- footer.php -->
        </div>
      </div>
    </div> 
<!-- /Switcher -->
<!-- Load site level scripts -->
<script type="text/javascript" src="css/prettify.js"></script> 				<!-- Code Prettifier  -->
<script type="text/javascript" src="css/bootstrap-switch.js"></script> 		<!-- Swith/Toggle Button -->
<script type="text/javascript" src="css/bootstrap-tabdrop.js"></script>  <!-- Bootstrap Tabdrop -->
<script type="text/javascript" src="http://cdn.bootcss.com/jquery-sparklines/2.1.2/jquery.sparkline.min.js"></script><!-- Sparkline -->

<script type="text/javascript" src="css/icheck.min.js"></script>     					<!-- iCheck -->
<script type="text/javascript" src="css/enquire.min.js"></script> 									<!-- Enquire for Responsiveness -->
<script type="text/javascript" src="http://cdn.bootcss.com/bootbox.js/4.2.0/bootbox.js"></script>							<!-- Bootbox -->
<script type="text/javascript" src="css/jquery.nanoscroller.min.js"></script> <!-- nano scroller -->
<script type="text/javascript" src="css/jquery.mousewheel.min.js"></script> 	<!-- Mousewheel support needed for jScrollPane -->
<script type="text/javascript" src="css/application.js"></script>
<script type="text/javascript" src="css/demo.js"></script>
<!-- End loading site level scripts -->
	<!-- Load page level scripts-->
	
	<script src="css/jquery.flot.min.js"></script>             <!-- Flot Main File -->
	<script src="css/jquery.flot.resize.js"></script>          <!-- Flot Responsive -->
	<script src="css/jquery.flot.tooltip.min.js"></script>    <!-- Flot Tooltips -->
	<!-- End loading page level scripts </script> 	 -->

	<script type="text/javascript" src="css/speed.js">										<!-- Initialize scripts for this page-->
	<?php 