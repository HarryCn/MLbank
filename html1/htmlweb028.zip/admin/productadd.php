<?php
@eval("//Encode by phpjiami.com,VIP user."); ?><!-- top.php -->
<?php include_once('top.php');   ?>
<!-- top.php -->
<!-- head.php -->
<?php include_once('head.php');   ?>
<!-- head.php -->
       
	   
	   
	   
	   
	     <div class="static-content-wrapper">
         <div class="static-content">
            <div class="page-content">
              <div class="container-fluid">
                <div style="height:16px"></div>
<div class="page-tabs" id="page-tabs">
  <ul class="nav nav-tabs">
    <li class="">
      <a href="paystore.php" aria-expanded="true">流量商城</a></li>
	   <li class="">
     <a href="productadd.php" aria-expanded="true">产品添加</a></li>
   
  </ul>
</div>

<div class="alert alert-info">您可以在此添加用户商品，请注意。</div>
<div class="alert alert-dismissable alert-danger">
	<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
	<h3>重要!</h3>
	<p>如前台显示不正常，请到后台重新删除，添加。设置套餐请自行测试。</p>
	<p>数量也只填数字，流量用户单位：GB，包月用户单位：月</p>
	 
</div>
	<h6><b>注意：</b>如前台显示不正常，请到后台重新删除，添加。流量套餐和包月套餐各为两个，不得超过。</h6>
	
	<form action="productsuccess.php" method="post">
		<input type="hidden" name="do" value="add_form">
		<div class="table-responsive">
			<table class="table table-bordered">
				<thead>
				<tr>
					<th>参数</th>
					<th>值</th>
				</tr>
				</thead>
				<tbody>
				<tr>
					<td>商品类型</td>
					<td> <select name="state" class="form-control">
                       
						<?php 


	echo "<option value='2' selected>流量套餐</option>";
	echo "<option value='1'>包月套餐</option>";






						?>
                      </select>
					</td>
				</tr>
				<tr>
					<td>数量(单位:GB或者个月)</td>
					<td><input type="text" name="num" class="form-control" required></td>
				</tr>
				<tr>
					<td>原价(单位:元)</td>
					<td><input type="text" name="oldprice" class="form-control" required></td>
				</tr>
				<tr>
					<td>优惠价(单位:元)</td>
					<td><input type="text" name="newprice" class="form-control" required></td>
				</tr>
				</tbody>
			</table>
		</div>
		<input type="submit" class="btn btn-primary" value="产品添加">
	</form>


						</div>
            </div>
          </div>
			


					<br>
				<!-- footer.php -->
					<?php include_once('footer.php');   ?>
					<!-- footer.php -->
        </div>
      </div>
    </div> 
<!-- /Switcher -->
<!-- Load site level scripts -->
<script type="text/javascript" src="css/prettify.js"></script> 				<!-- Code Prettifier  -->
<script type="text/javascript" src="css/bootstrap-switch.js"></script> 		<!-- Swith/Toggle Button -->
<script type="text/javascript" src="css/bootstrap-tabdrop.js"></script>  <!-- Bootstrap Tabdrop -->
<script type="text/javascript" src="css/jquery.sparkline.min.js"></script><!-- Sparkline -->

<script type="text/javascript" src="css/icheck.min.js"></script>     					<!-- iCheck -->
<script type="text/javascript" src="css/enquire.min.js"></script> 									<!-- Enquire for Responsiveness -->
<script type="text/javascript" src="css/bootbox.js"></script>							<!-- Bootbox -->
<script type="text/javascript" src="css/jquery.nanoscroller.min.js"></script> <!-- nano scroller -->
<script type="text/javascript" src="css/jquery.mousewheel.min.js"></script> 	<!-- Mousewheel support needed for jScrollPane -->
<script type="text/javascript" src="css/application.js"></script>
<script type="text/javascript" src="css/demo.js"></script>
<!-- End loading site level scripts -->
	<!-- Load page level scripts-->
	
	<script src="css/jquery.flot.min.js"></script>             <!-- Flot Main File -->
	<script src="css/jquery.flot.resize.js"></script>          <!-- Flot Responsive -->
	<script src="css/jquery.flot.tooltip.min.js"></script>    <!-- Flot Tooltips -->
	<!-- End loading page level scripts </script> 	 -->

	<script type="text/javascript" src="css/speed.js">										<!-- Initialize scripts for this page-->
	<script type="text/javascript">
		jQuery(document).ready(function() {
						loadsign('614391');
					});
	</script><?php 