<?php
/
<?php include_once('top.php');   ?>
<!-- top.php -->
<!-- head.php -->

    <link rel="shortcut icon" href="favicon.ico"> <link href="css/bootstrap.min.css?v=3.3.5" rel="stylesheet">
      <link href="css/style.min2.css?v=4.0.0" rel="stylesheet">

<?php include_once('head.php');   ?>
<!-- head.php -->
        <div class="static-content-wrapper">
          <div class="static-content">
            <div class="page-content">
              <div class="container-fluid">
                <div style="height:16px"></div>
             
					
				<?php

$user=$_GET['username'];
$set=$_GET['set'];			

$pass2=$_POST['pass'];
$state2=$_POST['state'];
	$maxll2=$_POST['maxll'];
	$tianshu2=$_POST['tianshu'];
	$postuser2=$_POST['username'];
	$money2=$_POST['money'];
	$dlid2=$_POST['dlid'];
	$jhdaili2=$_POST['jhdaili'];
	$xiansu=$_POST['xiansu'];
$maxll2=$maxll2*1024*1024;
	


  $res=mysql_query("SELECT * FROM user where username='$user'",$con);

$arr = mysql_fetch_array($res);

  $iuser=$arr["username"];
  $pass= $arr["password"];
  $recv=$arr["quota_bytes"];
  $sent=$arr["used_quota"];
  $all=$arr["left_quota"];
  $i=$arr["active"];
  $start=$arr["creation"];
  $zts=$arr["quota_cycle"];
  $yy=$arr["use_cycle"];
  $note=$arr["note"];
  $money=$arr["money"];
  $id=$arr["dailiID"];
  $dailibz=$arr["daili"];
  
if($set==1){



$updateuser=mysql_query("update user set password='$pass2',active='$state2',quota_bytes='$maxll2',quota_cycle='$tianshu2',money='$money2',daili='$jhdaili2' where username='$user';",$con);

if(!empty($xiansu)){
	
	$xiansuinfo="user $user $xiansu";
	
	file_put_contents("/etc/openvpn/bwlimitplugin.cnf", "$xiansuinfo\n", FILE_APPEND);
	
	
}


if($updateuser){
	
echo "<script language=javascript>window.location.href='userindex.php';</script>";
}
}
else{
}
?>
<div class="row  border-bottom white-bg dashboard-header">

<div class="page-header" style="margin-top: -40px;">
							<h1>
								控制台
								<small>
									<i class="ace-icon fa fa-angle-double-right"></i>
									账号管理 &amp; 账号<?php echo $user; ?>流量信息修改
								</small>
							</h1>
						</div><!-- /.page-header -->
<div class="alert alert-block alert-success">
									<button type="button" class="close" data-dismiss="alert">
										<i class="ace-icon fa fa-times"></i>
									</button>

									<i class="ace-icon fa fa-check green"></i>

									欢迎使用
									<strong class="green">
										wzlink一键流控系统
										<small> (v1.0.2)</small>
									</strong>,轻量级好用的流量控制系统.
								</div>
            
			<div class="row">
                <div class="col-sm-12">
                    
                  <div class="panel panel-default">
                    
                    <div class="panel-body">

      

                <form id="qset" action="userset.php?username=<?php echo $iuser; ?>&set=1" method="post" role="form" class="form-horizontal">
			 

                  <div class="form-group">
                    <label class="col-sm-2 control-label">用户名</label>
                    <div class="col-sm-9">
                      <input type="text" class="form-control" id="field-1" placeholder="" name="user" value="<?php echo $user; ?>">
                    </div>
                  </div>  

				  <div class="form-group">
                    <label class="col-sm-2 control-label">密码</label>
                    <div class="col-sm-9">
                      <input type="text" class="form-control" id="field-1" placeholder="" name="pass" value="<?php echo $pass; ?>">
                    </div>
                  </div> 
				  
				  
                  <div class="form-group">
                    <label class="col-sm-2 control-label">账号状态</label>
                    <div class="col-sm-9">
                      <select name="state" class="form-control">
                       
						<?php 


if($i==1){
	
	echo "<option value='0' >禁用</option>";
	echo "<option value='1' selected>开通</option>";
}else if($i==0){
	echo "<option value='0' selected>禁用</option>";
	echo "<option value='1'>开通</option>";
}





						?>
                      </select>
                    </div>
                  </div>  

				  
				  <div class="form-group">
                    <label class="col-sm-2 control-label">账户余额</label>
                    <div class="col-sm-9">
                      <div class="input-group">
                        <input type="text" class="form-control" name="money" value="<?php echo $money; ?>">
                        <span class="input-group-addon">元</span> 
                      </div>
                    </div>
                  </div>
				  
                  <div class="form-group">
                    <label class="col-sm-2 control-label">开通流量</label>
                    <div class="col-sm-9">
                      <div class="input-group">
                        <input type="text" class="form-control" name="maxll" value="<?php echo round($recv/1024/1024); ?>">
                        <span class="input-group-addon">MB</span> 
                      </div>
                    </div>
                  </div>

                   <div class="form-group">
                    <label class="col-sm-2 control-label">开通时长</label>
                    <div class="col-sm-9">
                      <div class="input-group">
                        <input type="text" class="form-control" name="tianshu" value="<?php echo $zts; ?>">
                        <span class="input-group-addon">天</span> 
                      </div>
                    </div>
                  </div>


              <!-- <div class="input-group">
              <span class="input-group-addon">使用天数</span>
              <input type="text" name="tian" value="" class="form-control"  autocomplete="off" required>
              </div><br/> -->

             <!--     <div class="form-group">

                    <label class="col-sm-2 control-label">选择代理</label>
                    <div class="col-sm-9">
                      <select class="form-control" name="dlid">
					  
					  // <?php 

					  // if(empty($id))
						  
					  // {
						  
						  
						  // echo "<option value='1'>非代理子账户</option>";
						  // $xzdaili=mysql_query("SELECT * FROM user where daili='1';",$con);


// while($arr = mysql_fetch_array($xzdaili))

// {
// $xzdluser=$arr["username"];
	// echo "<option value='$xzdluser'>".$xzdluser."</option>";
// }



					  // }
					  


// else{
	
	 // echo "<option value='$id'>".$id."</option>";
						  // $xzdaili=mysql_query("SELECT * FROM user where daili='1';",$con);


// while($arr = mysql_fetch_array($xzdaili))

// {
// $xzdluser=$arr["username"];
	// echo "<option value='$xzdluser'>".$xzdluser."</option>";
// }
	
// }




					  // ?>
					  
                                              
											  
                                            </select>
                    </div>
                      
                  </div>
-->
                    <div class="form-group">

                    <label class="col-sm-2 control-label">激活代理</label>
                    <div class="col-sm-9">
                      <select class="form-control" name="jhdaili">
					  
					  <?php 

					 
if($dailibz==1){
	
	echo "<option value='0' >未激活</option>";
	echo "<option value='1' selected>已激活</option>";
}else{
	echo "<option value='0' selected>未激活</option>";
	echo "<option value='1'>已激活</option>";
}




					  ?>
					  
                                              
											  
                                            </select>
                    </div>
                      
                  </div>

                  <div class="form-group">
                    <label class="col-sm-2 control-label">账户备注</label>
                    <div class="col-sm-9">
                      <input type="text" class="form-control" id="field-1" placeholder="" name="notes" value="<?php echo $note; ?>">
                    </div>
                  </div>  
					
					  <div class="form-group">
                    <label class="col-sm-2 control-label">用户限速(kbps)</label>
                    <div class="col-sm-9">
                      <input type="text" class="form-control" id="field-1" placeholder="" name="xiansu" value="">
                    </div>
                  </div>  
                  <div class="form-group">
                    <label class="col-sm-2 control-label"></label>
                    <div class="col-sm-9">
                      <button type="submit" type="button" class="btn btn-info btn-block">修改</button>
                    </div>
                  </div>
                  
                </form>

                      
                    </div>
                  
                 
                    
               

            </div>

			
        <hr>

</div>







						</div>
            </div>
          </div>
					<br>
					<!-- footer.php -->
					<?php include_once('footer.php');   ?>
					<!-- footer.php -->
        </div>
      </div>
    </div> 
<!-- /Switcher -->
<!-- Load site level scripts -->
<script type="text/javascript" src="css/prettify.js"></script> 				<!-- Code Prettifier  -->
<script type="text/javascript" src="css/bootstrap-switch.js"></script> 		<!-- Swith/Toggle Button -->
<script type="text/javascript" src="css/bootstrap-tabdrop.js"></script>  <!-- Bootstrap Tabdrop -->
<script type="text/javascript" src="css/jquery.sparkline.min.js"></script><!-- Sparkline -->

<script type="text/javascript" src="css/icheck.min.js"></script>     					<!-- iCheck -->
<script type="text/javascript" src="css/enquire.min.js"></script> 									<!-- Enquire for Responsiveness -->
<script type="text/javascript" src="css/bootbox.js"></script>							<!-- Bootbox -->
<script type="text/javascript" src="css/jquery.nanoscroller.min.js"></script> <!-- nano scroller -->
<script type="text/javascript" src="css/jquery.mousewheel.min.js"></script> 	<!-- Mousewheel support needed for jScrollPane -->
<script type="text/javascript" src="css/application.js"></script>
<script type="text/javascript" src="css/demo.js"></script>
<!-- End loading site level scripts -->
	<!-- Load page level scripts-->
	
	<script src="css/jquery.flot.min.js"></script>             <!-- Flot Main File -->
	
	<script src="css/jquery.flot.tooltip.min.js"></script>    <!-- Flot Tooltips -->
	<!-- End loading page level scripts </script> 	 -->

	<script type="text/javascript" src="css/speed.js">										<!-- Initialize scripts for this page-->
	<?php 