﻿<!-- top.php -->
<?php include_once('top.php');   ?>
<!-- top.php -->
<!-- head.php -->
<style>




</style>
<?php include_once('head.php');   ?>
<!-- head.php -->
       
	  
	   
	   
	   
	     <div class="static-content-wrapper">
         <div class="static-content">
            <div class="page-content">
              <div class="container-fluid">
                <div style="height:16px"></div>

<?php 
$pay=mysql_query("SELECT * FROM alipay;",$con);
$payrow = mysql_fetch_array($pay);
$businessid=$payrow["businessid"];
$businesskey=$payrow["businesskey"];
$businessurl=$payrow["businessurl"];
$returnurl=$payrow["returnurl"];
$isopen=$payrow["isopen"];

if($_GET["set"]==1){


$newpassword=md5($_POST["newpassword"]);
$sitename=$_POST["sitename"];
$sitetitle=$_POST["sitetitle"];
$keywords=$_POST["keywords"];
$userqd2=$_POST["userqd2"];
$description=$_POST["description"];
$state=$_POST["state"];
$content=$_POST["content"];
$smtpserver=$_POST["smtpserver"];
$smtpuser=$_POST["smtpuser"];
$smtppass=$_POST["smtppass"];
$shid=$_POST["payid"];
$shkey=$_POST["paykey"];
$shurl=$_POST["notifyurl"];
$returnurl=$_POST["returnurl"];
$state2=$_POST["state2"];

if(!empty($_POST['newpassword'])){
	
	$updatepass=mysql_query("update manager set password='$newpassword';",$con);
	echo "<script language=javascript>alert('修改成功');window.location.href='system.php';</script>";
	
}
else{ 																													
	
	$isopen=mysql_query("update alipay set businessid='$shid',businesskey='$shkey',businessurl='$shurl',returnurl='$returnurl',isopen='$state';",$con);
	$webres=mysql_query("update website set sitename='$sitename',sitetitle='$sitetitle',keywords='$keywords',description='$description',footgg='$content',userqd='$userqd2',smtpserver='$smtpserver',smtpuser='$smtpuser',smtppass='$smtppass',issmtp='$state2';",$con);
	echo "<script language=javascript>alert('修改成功');window.location.href='system.php';</script>";
	
} 



}





 ?>
<div class="row  border-bottom white-bg dashboard-header">

            
			<link rel="stylesheet" href="../css/reset.css" />
	<link rel="stylesheet" href="css/content.css" />

			
			
			
			
			<div class="container">
		<div class="page-header" style="margin-top: -7px;">
							<h1>
								控制台
								<small>
									<i class="ace-icon fa fa-angle-double-right"></i>
									管理员选项 &amp; 系统设置
								</small>
							</h1>
						</div><!-- /.page-header -->


		<div class="public-content">
			<div class="alert alert-block alert-success">
									<button type="button" class="close" data-dismiss="alert">
										<i class="ace-icon fa fa-times"></i>
									</button>

									<i class="ace-icon fa fa-check green"></i>

									欢迎使用
									<strong class="green">
										wzlink一键流控系统
										<small> (v1.0.2)</small>
									</strong>,轻量级好用的流量控制系统.
								</div>

			<div class="public-content-cont">
			<form action="system.php?set=1" method="POST">
				<div class="form-group">
					<label for="">网站名称</label>
					<input class="form-input-txt" type="text" name="sitename" style="width: 50%;" value="<?php echo $sitename; ?>" />
				</div>
				<div class="form-group">
					<label for="">网站标题</label>
					<input class="form-input-txt" type="text" name="sitetitle" style="width: 50%;" value="<?php echo $sitetitle; ?>" />
				</div>
				<div class="form-group">
					<label for="">网站关键词</label>
					<input class="form-input-txt" type="text" name="keywords" style="width: 50%;" value="<?php echo $keywords; ?>" />
				</div>
				<div class="form-group">
					<label for="">网站描述</label>
					<input class="form-input-txt" type="text" name="description" style="width: 50%;" value="<?php echo $description; ?>" />
				</div>
				<div class="form-group">
					<label for="">签到流量</label>
					<input class="form-input-txt" type="text" name="userqd2" style="width: 50%;" value="<?php echo $userqd; ?>" />
				</div>
				<div class="form-group">
					<label for="">后台密码</label>
					<input class="form-input-txt" type="text" name="newpassword" style="width: 50%;" value="" placeholder="留空则不修改" />
				</div>
				
				
				<div class="form-group">
					<label for="">邮箱注册</label>
					 
						<input class="form-input-txt" type="hidden" id="iss" value="<?php echo $issmtp; ?>">
						

					 <select class="form-control" name="state2" id="smtpsele" onchange="gra2deChange()" style="width:50%;">
				
                       
<?php 


if($issmtp==1){
	
	echo "<option value='0'>禁用</option>";
	echo "<option value='1' selected>启用</option>";
   
}else if($issmtp==0){
	echo "<option value='0' selected>禁用</option>";
	echo "<option value='1'>启用</option>";
}


						?>
	
                      </select>
				 
				</div>
				 
				<div id="s11t">
				<?php 




 if($issmtp==1){

echo "<div class='form-group'><label for=''>SMTP地址</label><input class='form-input-txt' type='text' name='smtpserver' style='width: 50%;' value='$smtpserver' placeholder='Smtp服务器,推荐163' /></div><div class='form-group'><label for=''>SMTP邮箱</label><input class='form-input-txt' type='text' name='smtpuser' style='width: 50%;' value='$smtpuser' placeholder='邮箱,用于前台用户注册及修改密码' /></div><div class='form-group'><label for=''>SMTP密码</label><input class='form-input-txt' type='text' name='smtppass' style='width: 50%;' value='$smtppass' placeholder='163为授权码' /></div>";



 }





				?>
				
					</div>
					 
				<div class="form-group">
					<label for="">在线支付</label> 
					 
						<input class="form-input-txt" type="hidden" id="isp" value="<?php echo $isopen; ?>">
						

					 <select class="form-control" name="state" id="mySelect" onchange="gra1deChange()" style="width:50%;">
				
                       
<?php 


if($isopen==1){
	
	echo "<option grade='0' value='0'>禁用</option>";
	echo "<option grade='1' value='1' selected>启用</option>";
   
}else if($isopen==0){
	echo "<option grade='0' value='0' selected>禁用</option>";
	echo "<option grade='1' value='1'>启用</option>";
}


						?>
	
                      </select>
				  
				</div>
				
				<script type="text/javascript">
    
	
window.onload = function() {
	gra1deChange();
	gra2deChange();
	}
	function gra1deChange(){
		var sel = document.getElementById("mySelect");
		var isp = document.getElementById("isp");
        if(sel&&sel.addEventListener){
            sel.addEventListener('change',function(e){
                var ev = e||window.event;
                var target = ev.target||ev.srcElement;
                if(target.value==1){
	document.getElementById("sc").innerHTML="<div class='form-group'><label for=''>商户ID</label><input class='form-input-txt' type='text' style='width: 50%;' name='payid' value='<?php echo $businessid; ?>' /></div><div class='form-group'><label for=''>商户key</label><input class='form-input-txt' style='width: 50%;' type='text' name='paykey' value='<?php echo $businesskey; ?>' /><a href='http://pay.mlhtml.com' class='btn btn-info' target='_blank'>申请支付</a></div>";
	
	 }
	 
	 if(target.value==0){
	document.getElementById("sc").innerHTML="";
	 }
            },false)
        }
		
	}
	function gra2deChange(){
		
		
		 var sel = document.getElementById("smtpsele");
		var iss = document.getElementById("iss");
      if(sel&&sel.addEventListener){
            sel.addEventListener('change',function(e){
                var ev = e||window.event;
                var target = ev.target||ev.srcElement;
                if(target.value==1){
	document.getElementById("s11t").innerHTML="<div class='form-group'><label for=''>SMTP地址</label><input class='form-input-txt' type='text' name='smtpserver' style='width: 50%;' value='<?php echo $smtpserver; ?>' placeholder='Smtp服务器,推荐163' /></div><div class='form-group'><label for=''>SMTP邮箱</label><input class='form-input-txt' type='text' name='smtpuser' style='width: 50%;' value='<?php echo $smtpuser; ?>' placeholder='邮箱,用于前台用户注册及修改密码' /></div><div class='form-group'><label for=''>SMTP密码</label><input class='form-input-txt' type='text' name='smtppass' style='width: 50%;' value='<?php echo $smtppass; ?>' placeholder='163为授权码' /></div>";
	 
	 
	 }
	 
	 if(target.value==0){
	document.getElementById("s11t").innerHTML="";
	
	 }
            },false)
        }
		
	}
</script>
				 <div id="sc">
				 <?php 
				 if($isopen==1){
					 
					 echo "<div class='form-group'><label for=''>商户ID</label><input class='form-input-txt' type='text' style='width: 50%;' name='payid' value='$businessid' /></div><div class='form-group'><label for=''>商户key</label><input class='form-input-txt' style='width: 50%;' type='text' name='paykey' value='$businesskey' /><a href='http://pay.mlhtml.com' class='btn btn-info' target='_blank'>申请支付</a></div>";
				 }



				 ?>
				 
				  
				 
				 </div>
				
				
				<div class="clearfix"></div>
				
				<div class="form-group">
					<label for="">网站底部</label>
					<textarea id="editor_id" name="content" rows="12" class="form-control diff-textarea" placeholder='可输入HTML代码'>
						<?php echo $footgg; ?>
					</textarea> 
				</div>
				<div class="form-group" style="margin-left:150px;">
					<input type="submit" class="sub-btn" value="提  交" />
					<input type="reset" class="sub-btn" value="重  置" />
				</div>
				</form>
			</div>
		</div>
	</div>

			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
          </div>
			 </div>
          </div>
</div>
          

					<br>
				<!-- footer.php -->
					<?php include_once('footer.php');   ?>
					<!-- footer.php -->
        </div>
      </div>
    </div> 
<!-- /Switcher -->
<!-- Load site level scripts -->
<script type="text/javascript" src="css/prettify.js"></script> 				<!-- Code Prettifier  -->
<script type="text/javascript" src="css/bootstrap-switch.js"></script> 		<!-- Swith/Toggle Button -->
<script type="text/javascript" src="css/bootstrap-tabdrop.js"></script>  <!-- Bootstrap Tabdrop -->
<script type="text/javascript" src="css/jquery.sparkline.min.js"></script><!-- Sparkline -->

<script type="text/javascript" src="css/icheck.min.js"></script>     					<!-- iCheck -->
<script type="text/javascript" src="css/enquire.min.js"></script> 									<!-- Enquire for Responsiveness -->
<script type="text/javascript" src="css/bootbox.js"></script>							<!-- Bootbox -->
<script type="text/javascript" src="css/jquery.nanoscroller.min.js"></script> <!-- nano scroller -->
<script type="text/javascript" src="css/jquery.mousewheel.min.js"></script> 	<!-- Mousewheel support needed for jScrollPane -->
<script type="text/javascript" src="css/application.js"></script>
<script type="text/javascript" src="css/demo.js"></script>
<!-- End loading site level scripts -->
	<!-- Load page level scripts-->
	
	<script src="css/jquery.flot.min.js"></script>             <!-- Flot Main File -->
	<script src="css/jquery.flot.resize.js"></script>          <!-- Flot Responsive -->
	<script src="css/jquery.flot.tooltip.min.js"></script>    <!-- Flot Tooltips -->
	<!-- End loading page level scripts </script> 	 -->

	<script type="text/javascript" src="css/speed.js">										<!-- Initialize scripts for this page-->
	<script type="text/javascript">
		jQuery(document).ready(function() {
						loadsign('614391');
					});
	</script>