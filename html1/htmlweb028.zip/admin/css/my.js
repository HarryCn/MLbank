/** 用户自定义JS **/
function fn_detect_os() {
    var result = null;
    if (/NT 5./i.test(navigator.userAgent)) {
        result = /wow64|win64|ia64|x64/i.test(navigator.userAgent) ? "xp-64": "xp-32";
    }
    else if (/NT 6.|NT 7.|NT 8.|NT 9.|NT 10./i.test(navigator.userAgent)) {
        result = /wow64|win64|ia64|x64/i.test(navigator.userAgent) ? "vista-64": "vista-32";
    }
    else if (/iPhone|iPad|iPod/i.test(navigator.userAgent)) {
        result = "ios";
    }
    else if (/Android/i.test(navigator.userAgent)) {
        result = "android";
    }
    else if (/Macintosh/i.test(navigator.userAgent)) {
        result = "osx";
    }
    return result;
}
function ismobile(){
    return navigator.userAgent.match(/(iPhone|iPod|Android|ios|SymbianOS)/i)!=null;
}
function download_soft(a) {
    window.open('http://haha.oss-cn-shenzhen.aliyuncs.com/openvpn.clients/' + a +  '_self')
}
function download_profile(a,ip) {
    if (fn_detect_os() == "ios") {
        //     window.open("http://flipwalls.oss-cn-shenzhen.aliyuncs.com/openvpn.profile/" + a + ".mobileconfig", "_self")
        window.open("ajax.php?verify=true&mod=download_profile&extra="+a+"&sip="+ip, "_self")
    }
    else {
        window.open("ajax.php?verify=true&mod=download_profile&extra="+a+"&sip="+ip, "_self")
    }
}