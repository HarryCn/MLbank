<?php
session_start();
header("Content-type: text/html; charset=utf-8"); 
include_once('../config.php');  
include_once('../phpcode.php');
mysql_query("SET NAMES UTF8");
mysql_select_db($db,$con);


if($_SESSION["username"] != "admin"){
	
}else{
	
	if($_GET['km']=="ll")
	{
		
		$res2=mysql_query("delete from llpaynum");
	}else if($_GET['km']=="ye")

	{
$res=mysql_query("delete from paynum");
	}else if($_GET['km']=="used"){
		
		$res=mysql_query("delete from paynum where i=1");
		$res2=mysql_query("delete from llpaynum where i=1");
	}

}

?> 
<?php 
//页面跳转，实现方式为javascript 
echo "<script language=javascript>history.back();location.replace(location.href);</script>";
?>
