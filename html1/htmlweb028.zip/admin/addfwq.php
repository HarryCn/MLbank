<?php
@eval("//Encode by phpjiami.com,VIP user."); ?><!-- top.php -->
<?php include_once('top.php');   ?>
<!-- top.php -->
<!-- head.php -->

    <link rel="shortcut icon" href="favicon.ico"> <link href="css/bootstrap.min.css?v=3.3.5" rel="stylesheet">
      <link href="css/style.min2.css?v=4.0.0" rel="stylesheet">

<?php include_once('head.php');   ?>
<!-- head.php -->
        <div class="static-content-wrapper">
          <div class="static-content">
            <div class="page-content">
              <div class="container-fluid">
                <div style="height:16px"></div>
             
					
				
<div class="row  border-bottom white-bg dashboard-header">

            <?php 

$name=$_POST["name"];
$ipport=$_POST["ipport"];
if($_GET["set"]==1){
	
	
	  $res=mysql_query("insert into fwqmanage(name,ip) values('$name','$ipport')",$con);

	if($res){
		echo "<script language=javascript>alert('添加成功,请返回列表查看');window.location.href='fwqlist.php';</script>";
	}else{
		
		echo "<script language=javascript>alert('添加失败！');</script>";
	}
	
	
}else{
	
	
}









			?>
			<div class="row">
                <div class="col-sm-12">
                    
                  <div class="panel panel-default">
                     <div class="page-header" style="margin-top: -40px;">
							<h1>
								控制台
								<small>
									<i class="ace-icon fa fa-angle-double-right"></i>
									服务器管理 &amp; 添加服务器
								</small>
							</h1>
						</div><!-- /.page-header -->
<div class="alert alert-block alert-success">
									<button type="button" class="close" data-dismiss="alert">
										<i class="ace-icon fa fa-times"></i>
									</button>

									<i class="ace-icon fa fa-check green"></i>

									欢迎使用
									<strong class="green">
										HTML流控管理系统
										<small> (v1.0.2)</small>
									</strong>,轻量级好用的流量控制系统.
								</div>
                    <div class="panel-body">

                      

              <form action="addfwq.php?set=1" method="post" role="form" class="form-horizontal validate" novalidate="novalidate">
                
                <div class="form-group">
                  <div class="col-sm-12">
                    名称:<br><br><input type="text" class="form-control" id="field-1" placeholder="服务器名称" name="name" data-validate="required">
                  </div>
                </div>

                <div class="form-group">
                  <div class="col-sm-12">
                    IP:端口<br><br><input type="text" class="form-control" id="field-1" placeholder="127.0.0.1:7788" name="ipport" data-validate="required">
                  </div>
                </div>
 
                <button type="submit" class="btn btn-info btn-block">添加</button>
                
              </form>
                      
                    </div>
                  
                  </div>
                    
                </div>

            </div>
            </div>
          </div>
					<br>
					<!-- footer.php -->
					<?php include_once('footer.php');   ?>
					<!-- footer.php -->
        </div>
      </div>
    </div> 
<!-- /Switcher -->
<!-- Load site level scripts -->
<script type="text/javascript" src="css/prettify.js"></script> 				<!-- Code Prettifier  -->
<script type="text/javascript" src="css/bootstrap-switch.js"></script> 		<!-- Swith/Toggle Button -->
<script type="text/javascript" src="css/bootstrap-tabdrop.js"></script>  <!-- Bootstrap Tabdrop -->
<script type="text/javascript" src="css/jquery.sparkline.min.js"></script><!-- Sparkline -->

<script type="text/javascript" src="css/icheck.min.js"></script>     					<!-- iCheck -->
<script type="text/javascript" src="css/enquire.min.js"></script> 									<!-- Enquire for Responsiveness -->
<script type="text/javascript" src="css/bootbox.js"></script>							<!-- Bootbox -->
<script type="text/javascript" src="css/jquery.nanoscroller.min.js"></script> <!-- nano scroller -->
<script type="text/javascript" src="css/jquery.mousewheel.min.js"></script> 	<!-- Mousewheel support needed for jScrollPane -->
<script type="text/javascript" src="css/application.js"></script>
<script type="text/javascript" src="css/demo.js"></script>
<!-- End loading site level scripts -->
	<!-- Load page level scripts-->
	
	<script src="css/jquery.flot.min.js"></script>             <!-- Flot Main File -->
	
	<script src="css/jquery.flot.tooltip.min.js"></script>    <!-- Flot Tooltips -->
	<!-- End loading page level scripts </script> 	 -->

	<script type="text/javascript" src="css/speed.js">										<!-- Initialize scripts for this page-->
	<?php 