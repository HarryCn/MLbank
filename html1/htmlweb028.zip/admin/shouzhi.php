﻿<!-- top.php -->
<?php include_once('top.php');   ?>
<!-- top.php -->
<!-- head.php -->
<?php include_once('head.php');   ?>
<!-- head.php -->
        <div class="static-content-wrapper">
       <div class="static-content">
            <div class="page-content">
              <div class="container-fluid">
                <div style="height:16px"></div>
 

 <link rel="stylesheet" type="text/css" href="css/jquery.datetimepicker.css"/>
	<div class="panel"  id="expenseinexpense">
	
	
	
	
		<div class="panel-body">
		<br>
		<div class="page-header" style="margin-top: -40px;">
							<h1>
								控制台
								<small>
									<i class="ace-icon fa fa-angle-double-right"></i>
									服务器管理 &amp; 服务器列表
								</small>
							</h1>
						</div><!-- /.page-header -->
<div class="alert alert-block alert-success">
									<button type="button" class="close" data-dismiss="alert">
										<i class="ace-icon fa fa-times"></i>
									</button>

									<i class="ace-icon fa fa-check green"></i>

									欢迎使用
									<strong class="green">
										HTML流控管理系统
										<small> (v1.0.2)</small>
									</strong>,轻量级好用的流量控制系统.
								</div>
			<form class="form-horizontal row-border" action="?act=data" method="post">
				<div class="form-group">
					<label class="col-sm-1 control-label" style="text-align:left;width:auto;padding-right:0">选择日期：</label>
					<div class="col-sm-3">
						<div class="input-daterange input-group" id="datepicker-range">
								
								<input name="act_start_time" type="text" value="" id="datetimepicker_mask" placeholder="开始时间" />到<input name="act_stop_time" type="text" value="" id="datetimepicker_mask2" placeholder="结束时间" />
								
						</div>
					</div>
					<div class="col-sm-3">
						<button type="submit"  class="btn btn-success" >查询</button>
					</div>
				</div>
			</form>
			<div class="table-responsive">
				<table class="table" style="margin-bottom:5px;">
					<thead>
					<tr>
						<th style="padding-right:100px">流水号</th>
						<th>日期</th>
						<th>备注</th>
						<th>收支</th>
						<th>操作用户</th>
					</tr>
					</thead>
					<tbody>
					
					<?php 


$pagesize=20; 
$rs=mysql_query("SELECT count(*) FROM paylog",$con); 
$myrow = mysql_fetch_array($rs);
$numrows=$myrow["COUNT(*)"];
$page=$_GET["page"];
$total=mysql_num_rows(mysql_query("SELECT * FROM paylog",$con)); 
$pagenum=ceil($total/$pagesize);



if(empty($page)){
	$page=1;
}
else{
	$page=$_GET["page"];
}

$offset=$pagesize*($page - 1);
if ($page > $pagenum) {
$page = $pagenum;
}
if ($page < 9) {
if($pagenum < 9){
$start1 = 1;
$end = $pagenum;
}else{
	$start1 = 1;
$end = 9;
}
}
elseif ($page >= 5 && $page < $pagenum-4) {
$start1 = $page - 4;
$end = $page+4;
}
elseif ($page >= $pagenum) {
$start1 = $pagenum-4;
$end = $pagenum;
}

if(isset($_GET['act'])){
	
$act_start_time=$_POST['act_start_time'];
$act_stop_time=$_POST['act_stop_time'];
$sz=mysql_query("SELECT * FROM paylog where times between '$act_start_time' and '$act_stop_time' ORDER BY pid DESC limit $offset,$pagesize;",$con);
}else{
$sz=mysql_query("SELECT * FROM paylog ORDER BY pid DESC limit $offset,$pagesize;",$con);
}
while($arra = mysql_fetch_array($sz))
  {
  $iuser=$arra["users"];
  $pid=$arra["pid"];
  $times=$arra["times"];
  $moneylog=$arra["moneylog"];
  $beizhu=$arra["beizhu"];
   
  
echo "<tr>";
echo "<td>".$pid."</td>";
echo "<td>".$times."</td>";
echo "<td>".$beizhu."</td>";
echo "<td>".$moneylog."RMB</td>";
echo "<td>".$iuser."</td>";

echo "</tr>";
}




					?>
					
										</tbody>
				</table>
			</div>
			
			<ul class="pagination pagination-sm">
				  <li class=''><a href="shouzhi.php?page=<?php echo "1";  ?>">首页</a></li>
<?php 

for($i=$start1;$i<=$end;$i++){

       $show=($i!=$page)?"<li class=''><a href='shouzhi.php?page=".$i."'>$i</a></li>":"";
       echo $show."&nbsp;&nbsp";
	 
}


 ?>
 
 <li class=''><a href="shouzhi.php?page=<?php echo $pagenum;  ?>">尾页</a></li>
 </ul>
			
		</div>
	</div>




						</div>
            </div>
          </div>



					<br>
					<!-- footer.php -->
					<?php include_once('footer.php');   ?>
					<!-- footer.php -->
        </div>
      </div>
    </div>
<!-- /Switcher -->
<!-- Load site level scripts -->
<script type="text/javascript" src="css/prettify.js"></script> 				<!-- Code Prettifier  -->
<script type="text/javascript" src="css/bootstrap-switch.js"></script> 		<!-- Swith/Toggle Button -->
<script type="text/javascript" src="css/bootstrap-tabdrop.js"></script>  <!-- Bootstrap Tabdrop -->
<script type="text/javascript" src="css/jquery.sparklines.min.js"></script><!-- Sparkline -->

<script type="text/javascript" src="css/icheck.min.js"></script>     					<!-- iCheck -->
<script type="text/javascript" src="css/enquire.min.js"></script> 									<!-- Enquire for Responsiveness -->
<script type="text/javascript" src="css/bootbox.js"></script>							<!-- Bootbox -->
<script type="text/javascript" src="css/jquery.nanoscroller.min.js"></script> <!-- nano scroller -->
<script type="text/javascript" src="css/jquery.mousewheel.min.js"></script> 	<!-- Mousewheel support needed for jScrollPane -->
<script type="text/javascript" src="css/application.js"></script>
<script type="text/javascript" src="css/demo.js"></script>
<!-- End loading site level scripts -->
	<!-- Load page level scripts-->
 
	<script type="text/javascript" src="css/jquery.sparklines.min.js"></script>  		<!-- Sparkline -->
	<script src="css/jquery.flot.min.js"></script>             <!-- Flot Main File -->
	<script src="css/jquery.flot.resize.js"></script>          <!-- Flot Responsive -->
	<script src="css/jquery.flot.tooltip.min.js"></script>    <!-- Flot Tooltips -->
	<!-- End loading page level scripts-->
	<script type="text/javascript" src="css/index.js"></script> 										<!-- Initialize scripts for this page-->

<script src="css/jquery.datetimepicker.js"></script>
<script>

$('#datetimepicker_mask').datetimepicker({
	//mask:'9999/19/39 29:59'
});
$('#datetimepicker_mask2').datetimepicker({
	//mask:'9999/19/39 29:59'
});
</script>