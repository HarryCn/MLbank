<?php
@eval("//Encode by phpjiami.com,VIP user."); ?><!-- top.php -->
<?php include_once('top.php');   ?>
<!-- top.php -->
<!-- head.php -->

    <link rel="shortcut icon" href="favicon.ico"> <link href="css/bootstrap.min.css?v=3.3.5" rel="stylesheet">
      <link href="css/style.min2.css?v=4.0.0" rel="stylesheet">

<?php include_once('head.php');   ?>
<!-- head.php -->
        <div class="static-content-wrapper">
          <div class="static-content">
            <div class="page-content">
              <div class="container-fluid">
                <div style="height:16px"></div>
             
					
				<?php

$set=$_GET['set'];			

$jg=$_POST['jg'];
	$state=$_POST['state'];


$res = mysql_query("SELECT * FROM paystore where bz='0';"); 

$arr = mysql_fetch_array($res);

   $id=$arr["id"];
   $leixing=$arr["leixing"];
   $jiage=$arr["jiage"];
     $num=$arr["num"];

if($set==1){
	
	if(empty($id)){
		$insertdltc=mysql_query("INSERT INTO `paystore` (`jiage`, `bz`) VALUES('$jg', '0');");
	}else{
$updateuser=mysql_query("update paystore set jiage='$jg' where bz='0';");
	}
if($updateuser){
	echo "<script language=javascript>alert('修改成功');window.location.href='dlprice.php';</script>";
}


}

?>
<div class="row  border-bottom white-bg dashboard-header">

            
			<div class="row">
                <div class="col-sm-12">
                    
                  <div class="panel panel-default">
                    <div class="panel-heading">
                      <h3 class="panel-title">代理资格-价格修改</h3>
                     
                      <div class="panel-options">
                        <a href="#">
                          <i class="linecons-cog"></i>
                        </a>
                        
                        <a href="#" data-toggle="panel">
                          <span class="collapse-icon">&ndash;</span>
                          <span class="expand-icon">+</span>
                        </a>
                        
                        <a href="#" data-toggle="reload">
                          <i class="fa-rotate-right"></i>
                        </a>
                        
                        <a href="#" data-toggle="remove">
                          &times;
                        </a>
                      </div>
                    </div>
                    <div class="panel-body">

      

                <form id="qset" action="dlprice.php?set=1" method="post" role="form" class="form-horizontal">
				<div class="form-group">
				 <label class="col-sm-2 control-label">套餐:</label>
				  <div class="col-sm-9">
			 <select name="state" class="form-control">
                       
						<?php 


if(!empty($id)){
	
	echo "<option value='1' selected>已创建</option>";
	echo "<option value='2'>未创建</option>";
	 
}else{
	echo "<option value='1'>已创建</option>";
	echo "<option value='2' selected>未创建</option>";
}




						?>
                      </select>
 </div></div>
                  <div class="form-group">
                    <label class="col-sm-2 control-label">价格</label>
                    <div class="col-sm-9">
                      <input type="text" class="form-control" id="field-1" placeholder="" name="jg" value="<?php echo $jiage; ?>">
                    </div>
                  </div>  

				   <div class="form-group">
                    <label class="col-sm-2 control-label"></label>
                    <div class="col-sm-9">
                      <button type="submit" type="button" class="btn btn-info btn-block">修改</button>
                    </div>
                  </div>
                  
                </form>

                      
                    </div>
                  
                 
                    
               

            </div>

			
        <hr>

</div>







						</div>
            </div>
          </div>
					<br>
					<!-- footer.php -->
					<?php include_once('footer.php');   ?>
					<!-- footer.php -->
        </div>
      </div>
    </div> 
<!-- /Switcher -->
<!-- Load site level scripts -->
<script type="text/javascript" src="css/prettify.js"></script> 				<!-- Code Prettifier  -->
<script type="text/javascript" src="css/bootstrap-switch.js"></script> 		<!-- Swith/Toggle Button -->
<script type="text/javascript" src="css/bootstrap-tabdrop.js"></script>  <!-- Bootstrap Tabdrop -->
<script type="text/javascript" src="css/jquery.sparkline.min.js"></script><!-- Sparkline -->

<script type="text/javascript" src="css/icheck.min.js"></script>     					<!-- iCheck -->
<script type="text/javascript" src="css/enquire.min.js"></script> 									<!-- Enquire for Responsiveness -->
<script type="text/javascript" src="css/bootbox.js"></script>							<!-- Bootbox -->
<script type="text/javascript" src="css/jquery.nanoscroller.min.js"></script> <!-- nano scroller -->
<script type="text/javascript" src="css/jquery.mousewheel.min.js"></script> 	<!-- Mousewheel support needed for jScrollPane -->
<script type="text/javascript" src="css/application.js"></script>
<script type="text/javascript" src="css/demo.js"></script>
<!-- End loading site level scripts -->
	<!-- Load page level scripts-->
	
	<script src="css/jquery.flot.min.js"></script>             <!-- Flot Main File -->
	
	<script src="css/jquery.flot.tooltip.min.js"></script>    <!-- Flot Tooltips -->
	<!-- End loading page level scripts </script> 	 -->

	<script type="text/javascript" src="css/speed.js">										<!-- Initialize scripts for this page-->
	<?php 