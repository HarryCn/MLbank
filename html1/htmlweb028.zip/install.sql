SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;


CREATE TABLE IF NOT EXISTS `alipay` (
  `businessid` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `businesskey` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `businessurl` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `returnurl` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `isopen` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  KEY `businessid` (`businessid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `alipay` (`businessid`, `businesskey`, `businessurl`, `returnurl`,`isopen`) VALUES
(NULL, NULL, NULL, NULL,'0');

CREATE TABLE IF NOT EXISTS `fwqmanage` (
  `name` varchar(50) NOT NULL,
  `times` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `ip` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
ALTER TABLE  `fwqmanage` ADD  `speed` VARCHAR( 50 ) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT  '300mbit' AFTER  `ip` ;
CREATE TABLE IF NOT EXISTS `llpaynum` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `num` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `llvalue` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `lltian` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `i` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=12 ;

CREATE TABLE IF NOT EXISTS `log` (
  `username` varchar(32) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `start_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `end_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `trusted_ip` varchar(64) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `trusted_port` int(10) DEFAULT NULL,
  `protocol` varchar(16) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `remote_ip` varchar(64) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `remote_netmask` varchar(64) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `bytes_received` bigint(20) DEFAULT '0',
  `bytes_sent` bigint(20) DEFAULT '0',
  `total_used` bigint(20) DEFAULT '0',
  `status` int(11) NOT NULL DEFAULT '1',
  KEY `idx_username` (`username`),
  KEY `idx_start_time` (`start_time`),
  KEY `idx_end_time` (`end_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `lyj_article` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `category_id` int(10) unsigned NOT NULL,
  `title` varchar(255) NOT NULL DEFAULT '无题',
  `content` text NOT NULL,
  `visit_count` int(10) unsigned NOT NULL DEFAULT '0',
  `timeline` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `title` (`title`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='文章表' AUTO_INCREMENT=1 ;

CREATE TABLE IF NOT EXISTS `lyj_category` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL DEFAULT '默认栏目',
  `description` varchar(255) NOT NULL DEFAULT '栏目简介',
  `sortby` int(5) NOT NULL DEFAULT '0',
  `hidden` int(2) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='栏目表' AUTO_INCREMENT=4 ;

INSERT INTO `lyj_category` (`id`, `name`, `description`, `sortby`, `hidden`) VALUES
(1, '移动', '', 1, 0),
(2, '联通', '', 2, 0),
(3, '电信', '', 3, 0);

CREATE TABLE IF NOT EXISTS `lyj_link` (
  `id` int(8) unsigned NOT NULL AUTO_INCREMENT,
  `category_id` int(10) unsigned NOT NULL,
  `name` varchar(200) NOT NULL DEFAULT '链接名称',
  `description` varchar(255) NOT NULL DEFAULT '链接简介',
  `url` varchar(255) NOT NULL DEFAULT 'http://',
  `icon` varchar(255) NOT NULL DEFAULT 'http://',
  `sortby` int(5) NOT NULL DEFAULT '0',
  `hidden` int(2) NOT NULL DEFAULT '0',
  `timeline` int(8) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `url` (`url`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='友链表' AUTO_INCREMENT=7 ;

INSERT INTO `lyj_link` (`id`, `category_id`, `name`, `description`, `url`, `icon`, `sortby`, `hidden`, `timeline`) VALUES
(2, 1, '官方商城', '链接简介', 'http://127.0.0.1:7788/appadmin/index.php', '.', 0, 0, 1469891212),
(4, 1, '流控地址', '链接简介', 'http://127.0.0.1:7788/user/', '.', 2, 0, 1469891494),
(6, 1, '卡密地址', '链接简介', 'http://917ka.com', '.', 4, 0, 1469891545);

CREATE TABLE IF NOT EXISTS `lyj_token` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `token` varchar(32) NOT NULL,
  `expire_timeline` int(10) NOT NULL,
  `update_timeline` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='登录令牌表' AUTO_INCREMENT=3 ;

INSERT INTO `lyj_token` (`id`, `user_id`, `token`, `expire_timeline`, `update_timeline`) VALUES
(1, 1, '9651bf37257165b96e92e1839afa59b2', 1472321068, 1469729068),
(2, 2, '1ade3b90bde227ec3242fa4c65369ad9', 1789665003, 1789665003);

CREATE TABLE IF NOT EXISTS `lyj_user` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `account` varchar(15) DEFAULT NULL,
  `password` varchar(32) DEFAULT NULL,
  `nick` varchar(15) NOT NULL,
  `face` varchar(255) DEFAULT NULL,
  `sex` int(2) DEFAULT '0',
  `device_id` varchar(20) NOT NULL,
  `is_forbidden` int(10) NOT NULL DEFAULT '0',
  `is_app` int(2) DEFAULT '0',
  `timeline` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `account` (`account`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='用户表' AUTO_INCREMENT=2 ;

INSERT INTO `lyj_user` (`id`, `account`, `password`, `nick`, `face`, `sex`, `device_id`, `is_forbidden`, `is_app`, `timeline`) VALUES
(1, 'admin', '3c2cdcf201b73855bd3086f6ae38a80a', 'html', '', 1, '1789665003', 0, 0, 0);

CREATE TABLE IF NOT EXISTS `manager` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(20) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

INSERT INTO `manager` (`id`, `username`, `password`) VALUES
(1, 'admin', '21232f297a57a5a743894a0e4a801fc3');

CREATE TABLE IF NOT EXISTS `paylog` (
  `pid` varchar(50) NOT NULL,
  `times` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `moneylog` float DEFAULT NULL,
  `beizhu` varchar(20) DEFAULT NULL,
  `users` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`pid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `paynum` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `numleixing` varchar(10) DEFAULT NULL,
  `num` varchar(50) DEFAULT NULL,
  `i` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

CREATE TABLE IF NOT EXISTS `paystore` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `leixing` varchar(20) DEFAULT NULL,
  `jiage` varchar(20) DEFAULT NULL,
  `num` varchar(50) DEFAULT NULL,
  `bz` varchar(50) DEFAULT NULL,
  `oldprice` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=17 ;

INSERT INTO `paystore` (`id`, `leixing`, `jiage`, `num`, `bz`, `oldprice`) VALUES
(7, '2', '5', '1', '1', '15'),
(8, '2', '25', '5', '1', '75'),
(9, '1', '45', '1', '2', '50'),
(11, NULL, '25', NULL, '0', NULL),
(12, '3', '15', '5', '3', NULL),
(13, '3', '30', '10', '3', NULL),
(14, '1', '135', '3', '2', '150'),
(15, '4', '60', '3', '4', NULL),
(16, '4', '150', '10', '4', NULL);

CREATE TABLE IF NOT EXISTS `stat` (
  `username` char(32) NOT NULL,
  `origin_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `total_used` bigint(20) DEFAULT '0',
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `user` (
  `username` char(32) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `password` char(128) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `active` int(10) NOT NULL DEFAULT '1',
  `creation` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `note` text CHARACTER SET utf8 COLLATE utf8_unicode_ci,
  `quota_cycle` int(10) NOT NULL DEFAULT '30',
  `use_cycle` int(11) NOT NULL DEFAULT '0',
  `surplus_cycle` int(11) NOT NULL DEFAULT '0',
  `quota_bytes` bigint(20) NOT NULL DEFAULT '1024',
  `used_quota` bigint(20) NOT NULL DEFAULT '0',
  `left_quota` bigint(20) NOT NULL DEFAULT '0',
  `enabled` int(10) NOT NULL DEFAULT '0',
  `phone` varchar(20) DEFAULT NULL,
  `email` varchar(30) DEFAULT NULL,
  `token` varchar(300) DEFAULT NULL,
  `token_exptime` varchar(30) DEFAULT NULL,
  `status` varchar(30) DEFAULT '0',
  `regtime` int(30) DEFAULT NULL,
  `money` float DEFAULT '0',
  `qiandao` int(11) DEFAULT '0',
  `dailiID` varchar(20) DEFAULT NULL,
  `months` varchar(20) DEFAULT NULL,
  `lstimes` varchar(50) DEFAULT NULL,
  `ss` varchar(50) DEFAULT '0',
  `qdate` varchar(50) DEFAULT NULL,
  `firstuser` varchar(50) DEFAULT NULL,
  `daili` varchar(50) DEFAULT NULL,
  `firstlogin` varchar(50) DEFAULT NULL,
  `cj` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`username`),
  KEY `idx_active` (`active`),
  KEY `enabled` (`enabled`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `website` (
  `sitename` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sitetitle` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `keywords` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `footgg` varchar(8000) COLLATE utf8_unicode_ci DEFAULT NULL,
  `userqd` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '50',
  `issmtp` varchar(5) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `smtpserver` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'smtp.163.com',
  `smtpuser` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'mlhtml@163.com',
  `smtppass` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'mlhtml@163.com'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `website` (`sitename`, `sitetitle`, `keywords`, `description`, `footgg`, `userqd`, `issmtp`, `smtpserver`, `smtpuser`, `smtppass`) VALUES
('wzlink', 'wzlink-云免流后台管理系统 - v1.1.2', 'wzlink，脚本免流,真正让你免流量上网的神器!IOS免流最新版,html脚本，电脑、手机免流量！', 'HTML免流，骚逼汪云免，康师傅免流，变脸狗控流，变脸狗免流，变脸狗系统，康师傅控流，SS流控，SS控流，变脸狗破解版，openvpn控流，openvpn云免，大猫哥，7k', '						©  HTMLVPN | <a href="http://www.miitbeian.gov.cn/" target="_blank">蜀ICP备15025201号-1</a> <br/><h6 style="margin: 0;"><br>VPN运营团队坚决维护祖国统一并坚决拥护党的领导，提供本软件仅供学习工作和游戏使用，请勿用于非法用途。请广大用户自觉遵守当地法律。我们将积极配合当地公安机关对使用VPN进行非法活动的组织及个人进行违法行为的追溯。</h6>					', '50', '0', 'smtp.163.com', 'mlhtml@163.com', 'mlhtml');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
