<?php
header("Content-type: text/html; charset=utf-8"); 
include_once('../config.php');  
include_once('../phpcode.php');
mysql_query("SET NAMES UTF8");
mysql_select_db($db,$con);
$res=mysql_query("SELECT * FROM alipay;",$con);
$arr = mysql_fetch_array($res);
$userkey=$arr["businesskey"];
$customerid=$arr["businessid"];
$ordernum="TZ".date("YmdHis");
$total_fee=$_POST['total_fee'];
$paytype=$_POST['paytype'];
$bankcode=$_POST['bankcode'];
$notifyurl=$_POST['notifyurl'];
$returnurl=$_POST['returnurl'];
$khuser=$_POST['khuser'];
?>
<!doctype html>
<html>
<head>
<title>正在转到付款页</title>
</head>
<body onload="document.pay.submit()">
    <form name="pay" action="https://pay.mlhtml.com/alipayAPI/pay.php" method="post">
         <input type="hidden" name="userkey" value="<?php echo $userkey?>">
		 <input type="hidden" name="customerid" value="<?php echo $customerid?>">
        <input type="hidden" name="ordernum" value="<?php echo $ordernum?>">
        <input type="hidden" name="total_fee" value="<?php echo $total_fee?>">
        <input type="hidden" name="paytype" value="<?php echo $paytype?>">
           <input type="hidden" name="bankcode" value="<?php echo $bankcode?>">
		   <input type="hidden" name="khuser" value="<?php echo $khuser?>">
     </form>
</body>
</html>
