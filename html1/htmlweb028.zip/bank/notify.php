<?php
			header("Content-type: text/html; charset=utf-8"); 
			include_once('../config.php');  
			include_once('../phpcode.php');
			mysql_query("SET NAMES UTF8");
			mysql_select_db($db,$con);
			$res=mysql_query("SELECT * FROM alipay;",$con);
			$arr = mysql_fetch_array($res);
			$userkey=$arr["businesskey"];
			$status=$_POST['status'];
			$customerid=$arr["businessid"];
			$sdorderno=$_POST['sdorderno'];
			$total_fee=$_POST['total_fee'];
			$khuser=$_POST['khuser'];
			$date=date("Y-m-d H:i:s");

			if($status=='1'){
		
		
			$res1=mysql_query("SELECT * FROM paylog WHERE users='$khuser' and pid='$sdorderno';",$con);

			$rows = mysql_fetch_array($res1);
            
			$lognum=$rows["pid"];
			
			$res2=mysql_query("SELECT * FROM user WHERE username='$khuser';",$con);

			$rows2 = mysql_fetch_array($res2);
            
			$daili=$rows2["daili"];
		
			if(empty($return['pid'])){
			
			$logcha=mysql_query("insert into paylog(pid,moneylog,beizhu,users) values('$sdorderno','$total_fee','在线充值$total_fee 元','$khuser');",$con);
			$res=mysql_query("UPDATE user SET money=money+'$total_fee' WHERE username='$khuser';",$con);
		
		
		
			echo 'success';
		}
    } else {
			echo 'fail';
    }

 
 
?>
