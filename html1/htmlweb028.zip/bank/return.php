<?php
header("Content-type: text/html; charset=utf-8"); 
include_once('../config.php');  
include_once('../phpcode.php');
mysql_query("SET NAMES UTF8");
mysql_select_db($db,$con);
$res=mysql_query("SELECT * FROM alipay;",$con);
$arr = mysql_fetch_array($res);
$sdorderno=$_GET['sdorderno'];
$total_fee=$_GET['total_fee'];
$paytype=$_GET['paytype'];
$sdpayno=$_GET['sdpayno'];

$idres=mysql_query("SELECT * FROM paylog WHERE pid='$sdorderno';",$con);
$idress = mysql_fetch_array($idres);
$users=$idress["users"];


$res2=mysql_query("SELECT * FROM user WHERE username='$users';",$con);
$rows2 = mysql_fetch_array($res2);
$daili=$rows2["daili"];
if(isset($daili))
 {
	 Header("Location: ../daili/pay.php?pid=$sdorderno"); 
 }else{
     Header("Location: ../user/pay.php?pid=$sdorderno"); 
 }
 
   
 
 
?>
