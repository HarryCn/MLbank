
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
<meta name="renderer" content="webkit">
<meta name="screen-orientation" content="portrait">
<meta name="x5-orientation" content="portrait">
<meta name="full-screen" content="yes">
<meta name="x5-fullscreen" content="true">
<meta name="browsermode" content="application">
<meta name="x5-page-mode" content="app">
<meta name="apple-mobile-web-app-capable" content="yes"/>
<meta name="msapplication-tap-highlight" content="no">
<meta name="theme-color" content="##f8f8f8">


    <!--[if lt IE 10]>
      <script type="text/javascript" src="assets/js/media.match.min.js"></script>
      <script type="text/javascript" src="assets/js/placeholder.min.js"></script>
    <![endif]-->
	<link type="text/css" href="css/xemon.css" rel="stylesheet">
 
    <link type="text/css" href="css/font-awesome.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link type="text/css" href="css/styles.css" rel="stylesheet">
    <!-- Core CSS with all styles -->
    <link type="text/css" href="css/style.min.css" rel="stylesheet">
    <!-- jsTree -->
    <link type="text/css" href="css/prettify.css" rel="stylesheet">
    <!-- Code Prettifier -->
    <link type="text/css" href="css/blue.css" rel="stylesheet">
    <!-- iCheck -->
    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries. Placeholdr.js enables the placeholder attribute -->
    <!--[if lt IE 9]>
      <link type="text/css" href="assets/css/ie8.css" rel="stylesheet">
      <script type="text/javascript" src="http://cdnjs.cloudflare.com/ajax/libs/respond.js/1.1.0/respond.min.js"></script>
      <script type="text/javascript" src="assets/plugins/charts-flot/excanvas.min.js"></script>
      <script type="text/javascript" src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->
    <!-- The following CSS are included as plugins and can be removed if unused-->
    <link type="text/css" href="css/daterangepicker-bs3.css" rel="stylesheet">
    <!-- DateRangePicker -->
    <link type="text/css" href="css/fullcalendar.css" rel="stylesheet">
    <!-- FullCalendar -->
    <link type="text/css" href="css/chartist.min.css" rel="stylesheet">
    <!-- Chartist -->

<!--<script type="text/javascript" src="http://ossweb-img.qq.com/images/js/jquery/jquery-1.9.1.min.js"></script>-->
<script type="text/javascript" src="css/jquery.min.js"></script> 	
<script type="text/javascript" src="css/jquery-ui.min.js"></script> 							<!-- Load jQuery -->						<!-- Load jQueryUI -->
<script type="text/javascript" src="css/bootstrap.min.js"></script> 								<!-- Load Bootstrap -->
<!--<link rel="stylesheet" href="source/css/bootstrap.min.css">-->
<style type="text/css">body { font-family:"微软雅黑","Microsoft YaHei";background: #eee; }</style>

<link rel="stylesheet" href="css/ui.css">
<link rel="stylesheet" href="css/my.css">
<link type="text/css" href="css/labalert.css" rel="stylesheet">
<link rel="stylesheet" href="css/nanoscroller.css">
<script type="text/javascript" src="css/js.js"></script>
<script type="text/javascript" src="css/my.js"></script><!--globals也要修改-->
</head>
<body class="infobar-offcanvas nano">


<?php

session_start(); // 启动Session  
$_SESSION['count']; // 注册Session变量Count  
isset($PHPSESSID)?session_id($PHPSESSID):$PHPSESSID = session_id();  
// 如果设置了$PHPSESSID，就将SessionID赋值为$PHPSESSID，否则生成SessionID 
$_SESSION['count']++; // 变量count加1  
setcookie('PHPSESSID', $PHPSESSID, time()+3156000); // 储存SessionID到Cookie中  



if($_SESSION["status"] != "ok"){
header("location:login.php");
exit("<h2>会话过期，请重新登录</h2>");
}
$username=$_SESSION["username"];
include_once('../phpcode.php');

header("Content-type: text/html; charset=utf-8"); 
include_once('../config.php');  
mysql_query("SET NAMES UTF8");
mysql_select_db($db,$con);
$daili=mysql_query("SELECT COUNT(*) FROM user WHERE dailiID='$username';",$con);
$daili3=mysql_query("SELECT * FROM user WHERE username='$username';",$con);
$dailis = mysql_fetch_array($daili);
$dailis3 = mysql_fetch_array($daili3);
$web=mysql_query("SELECT * FROM website;",$con);
$webrow = mysql_fetch_array($web);
$sitename=$webrow["sitename"];
$sitetitle=$webrow["sitetitle"];
$keywords=$webrow["keywords"];
$description=$webrow["description"];
$sitelogo=$webrow["sitelogo"];
$applogo1=$webrow["applogo1"];
$applogo2=$webrow["applogo2"];
$applogo3=$webrow["applogo3"];
$footgg=$webrow["footgg"];
$dailicount=$dailis["COUNT(*)"];
$money=$dailis3["money"];
$ss=$dailis3["ss"];
$password=$dailis3["password"];
$daili=$dailis3["daili"];
$dailiname=$dailis3["dailiID"];
$quota_byte=$dailis3["quota_bytes"];
$firstuser=$dailis3["firstuser"];
$quota_bytes=round($quota_byte/1024/1024);
if($daili==1){
	
}else{
	header("location:login.php");
exit("<h2>会话过期，请重新登录</h2>");
	exit("<h2>非法访问！</h2>");
}

 
?>

<div class ="nano-content">

	<div id="loading">
		<div id="loading-center">
			<div id="loading-center-absolute">
				<div class="object" id="object_one"></div>
				<div class="object" id="object_two"></div>
				<div class="object" id="object_three"></div>
				<div class="object" id="object_four"></div>
				<div class="object" id="object_five"></div>
				<div class="object" id="object_six"></div>
				<div class="object" id="object_seven"></div>
				<div class="object" id="object_eight"></div>
				<div class="object" id="object_big"></div>
			</div>
		</div>
	</div><!--NEW-->

    
    <header id="topnav" class="navbar navbar-midnightblue navbar-static-top clearfix" role="banner"><!--navbar-fixed-top-->
      <span id="trigger-sidebar" class="toolbar-trigger toolbar-icon-bg">
        <a data-toggle="tooltips" data-placement="right" title="Toggle Sidebar">
          <span class="icon-bg">
            <i class="fa fa-fw fa-bars"></i>
          </span>
        </a>
      </span>
      <a class="navbar-brand" href="userindex.php"><span style="font-weight: lighter;"><?php echo $sitename; ?><span style="color: #FF6C60;font-weight: normal;">VPN</span></span></a>
      <span id="trigger-infobar" class="toolbar-trigger toolbar-icon-bg">
        <a data-toggle="tooltips" data-placement="left" title="Toggle Infobar">
        </a>
      </span>
      <div class="yamm navbar-left navbar-collapse collapse in">
        <ul class="nav navbar-nav">
          <li class="dropdown">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">产品与服务
              <span class="caret"></span></a>
            <ul class="dropdown-menu" style="width: 450px;">
              <li>
                <div class="yamm-content container-sm-height">
                  <div class="row row-sm-height yamm-col-bordered">
                    <div class="col-sm-6 col-sm-height yamm-col">
                      <h3 class="yamm-category">OpenVpn</h3>
                      <ul class="list-unstyled mb20">
                        <li>
                          <a href="#">北京BGP</a></li>
                        <li>
                          <a href="#">上海BGP</a></li>
                        <li>
                          <a href="#">杭州高防</a></li>
                        <li>
                          <a href="#">深圳高防</a></li>
                      </ul>
                      <h3 class="yamm-category">Shadowsocks</h3>
                      <ul class="list-unstyled">
                        <li>
                          <a href="#">CN2, Hong Kong</a></li>
                        <li>
                          <a href="#">NewWorld, Hong Kong</a></li>
                        <li>
                          <a href="#">Tokyo, Japan</a></li>
                        <li>
                          <a href="#">Los Angeles, USA</a></li>
                      </ul>
                    </div>
                    <div class="col-sm-6 col-sm-height yamm-col">
                      <h3 class="yamm-category">L2TP/IPSEC</h3>
                      <ul class="list-unstyled mb20">
                        <li>
                          <a href="#">CN2, Singapore</a></li>
                        <li>
                          <a href="#">London, UK </a></li>
                        <li>
                          <a href="#">Sydney, Australia </a></li>
                        <li>
                          <a href="#">Atlanta, USA </a></li>
                        <li>
                          <a href="#">Los Angeles, USA </a></li>
                      </ul>
                      <h3 class="yamm-category">More</h3>
                      <ul class="list-unstyled mb20">
                        <li>
                          <a href="#">Contact us </a></li>
                      </ul>
                    </div>
                  </div>
                </div>
              </li>
            </ul>
          </li>
          <li class="dropdown" id="widget-classicmenu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">客户端下载
              <span class="caret"></span></a>
            <ul class="dropdown-menu" role="menu">
              <li>
                <a href="../user/down.php" target="blank">Android</a></li>
              <li>
                <a href="https://itunes.apple.com/us/app/openvpn-connect/id590379981" target="blank">iOS</a></li>
              <li class="divider"></li>
              <li>
                <a href="javascript:alert('开发中!');">Windows</a></li>
              <li class="divider"></li>
              <li>
                <a href="http://flipwalls.oss-cn-shenzhen.aliyuncs.com/openvpn.clients/Tunnelblick_3.5.5_build_4270.4461.dmg" target="blank">OS X</a></li>
            </ul>
          </li>
        </ul>
      </div>
      <ul class="nav navbar-nav toolbar pull-right">
        <li class="dropdown toolbar-icon-bg">
          <a href="#" id="navbar-links-toggle" data-toggle="collapse" data-target="header>.navbar-collapse">
            <span class="icon-bg">
              <i class="fa fa-fw fa-ellipsis-h"></i>
            </span>
          </a>
        </li>
        <li class="dropdown toolbar-icon-bg demo-search-hidden">
          <a href="#" class="dropdown-toggle tooltips" data-toggle="dropdown">
            <span class="icon-bg">
              <i class="fa fa-fw fa-search"></i>
            </span>
          </a>
          <div class="dropdown-menu dropdown-alternate arrow search dropdown-menu-form">
            <div class="dd-header">
              <span>Search</span>
              <span>
                <a href="#">Advanced search</a></span>
            </div>
            <div class="input-group">
              <input type="text" class="form-control" placeholder="">
              <span class="input-group-btn">
                <a class="btn btn-primary" href="#">Search</a></span>
            </div>
          </div>
        </li>
        <li class="toolbar-icon-bg demo-headerdrop-hidden">
          <a href="#" id="headerbardropdown">
            <span class="icon-bg">
              <i class="fa fa-fw fa-level-down"></i>
            </span>
            </i>
          </a>
        </li>
        <li class="toolbar-icon-bg hidden-xs" id="trigger-fullscreen">
          <a href="#" class="toggle-fullscreen">
            <span class="icon-bg">
              <i class="fa fa-fw fa-arrows-alt"></i>
            </span>
            </i>
          </a>
        </li>
        <li class="dropdown toolbar-icon-bg">
          <a href="#" class="hasnotifications dropdown-toggle" data-toggle='dropdown'>
            <span class="icon-bg">
              <i class="fa fa-fw fa-bell"></i>
            </span>
            <span class="badge badge-info">4</span></a>
          
        </li>
        <li class="dropdown toolbar-icon-bg">
          <a href="#" class="dropdown-toggle" data-toggle='dropdown'>
            <span class="icon-bg">
              <i class="fa fa-fw fa-user"></i>
            </span>
          </a>
          <ul class="dropdown-menu userinfo arrow">
            
            <li>
              <a href="updatepass.php">
                <span class="pull-left">密码修改</span>
                <i class="pull-right fa fa-cog"></i>
              </a>
            </li>
            <li class="divider"></li>
            <li>
              <a href="login.php">
                <span class="pull-left">退出</span>
                <i class="pull-right fa fa-sign-out"></i>
              </a>
            </li>
          </ul>
        </li>
      </ul>
    </header>
    <div id="wrapper">
      <div id="layout-static">
        <div class="static-sidebar-wrapper sidebar-midnightblue">
          <div class="static-sidebar">
            <div class="sidebar">
              <div class="widget stay-on-collapse" id="widget-welcomebox">
                <div class="widget-body welcome-box tabular">
                  <div class="tabular-row">
                    <div class="tabular-cell welcome-avatar">
                      <a href="#">
                        <img src="images/default_family.jpg" class="avatar"></a>
                    </div>
                    <div class="tabular-cell welcome-options">
                      <span class="welcome-text">Hi,</span>
                      <a href="#" class="name"><?php echo $username; ?></a></div>
                  </div>
                </div>
              </div>
              <div class="widget stay-on-collapse" id="widget-sidebar">
                <nav role="navigation" class="widget-body">
                  <ul class="acc-menu">
                    <li class="nav-separator">Explore</li>
                    <li>
                      <a href="index.php">
                        <i class="fa fa-home"></i>
                        <span>后台主页</span></a>
                    </li>
                    <li>
                      <a href="javascript:;">
                        <i class="fa fa-user"></i>
                        <span>账号管理</span></a>
                      <ul class="acc-menu">
                        <li>
                          <a href="userindex.php">所有用户</a></li>
                        <li>
                          <a href="onlineuser.php">在线用户</a></li>
 
                        <li>
                          <a href="shouzhi.php">返利明细</a></li>

                     
                      </ul>
                    </li>
                    
					<li>
                      <a href="javascript:;">
                        <i class="fa-bug"></i>
                        <span>开通管理</span></a>
                      <ul class="acc-menu">
                        <li>
                          <a href="useradd.php">创建流量账号</a></li>
                        <li>
                          <a href="llpay.php">流量用户充值</a></li>
 <li>
                          <a href="monthadd.php">创建包月账号</a></li>
 <li>
                          <a href="monthrenew.php">包月账号续费</a></li>
                     
 <li>
                          <a href="pladduser.php">批量添加账号</a></li>
                     
                      </ul>
                    </li>
					
					<li>
                      <a href="moneyadd.php">
                        <i class="fa fa-dollar"></i>
                        <span>余额充值</span>
                       
                      </a>
                    </li>
								
			<li>
                      <a href="pay.php">
                        <i class="fa fa-cny"></i>
                        <span>套餐购买</span>
                       
                      </a>
                    </li>
			
			
		
<li>
                      <a href="../user/ios/">
                        <i class="fa fa-apple"></i>
                        <span>苹果线路安装</span>
                       
                      </a>
                    </li>
 

                 
 <li>
                      <a href="yaoqing.php">
                          <i class="fa-info-circle"></i>
                        <span>代理邀请链接</span>
                     
                      </a>
                    </li>

                     <li>
                      <a href="updatepass.php">
                          <i class="fa fa-pencil"></i>
                        <span>代理密码修改</span>
                     
                      </a>
                    </li>

                  </ul>
                </nav>
              </div>
            </div>
          </div>
        </div>