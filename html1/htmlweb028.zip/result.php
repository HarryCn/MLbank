<!doctype html>
<html lang="zh">
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"> 
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>流量详情</title>
<link rel="stylesheet" href="user/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="css/htmleaf-demo.css">
<style>
body, html { font-size: 100%; 	padding: 0; margin: 0;}
body{
	font-weight: 500;
	font-size: 1.05em;
	font-family: "Microsoft YaHei","宋体","Segoe UI", "Lucida Grande", Helvetica, Arial,sans-serif, FreeSans, Arimo;
}
a{color: #2fa0ec;text-decoration: none;outline: none;}
a:hover,a:focus{color:#74777b;}

.zzsc{
	margin: 0 auto;
	text-align: center;
	overflow: hidden;
}

</style>
</head>

<body oncontextmenu="return false" ondragstart="return false" onselectstart="return false">
<section class="zzsc">
	<div class="container" style="padding:30px 0">
		<div class="row">
			<div class="md-col-8">
				<div class="table-responsive table2excel" data-tableName="Test Table 1">
				  <table class="table table-striped table-bordered table-hover">
					
					
						<tr>
						<td colspan="2" class="warning">用户查询详情</td>
						</tr>
						
						<?php
$name=$_POST['user'];   
include_once('config.php');  
mysql_query("SET NAMES UTF8");
mysql_select_db($db,$con);

//. mysql_error();
$res=mysql_query("SELECT * FROM user WHERE username='$name';",$con);
$num=mysql_num_rows($res);





if($num==1){

while($arr = mysql_fetch_array($res))
  {
  $iuser=$arr["username"];
  $passwd=$arr["password"];
  $recv=$arr["quota_bytes"];
  $sent=$arr["used_quota"];
  $all=$arr["left_quota"];
  $i=$arr["active"];
  $start=$arr["creation"];
  $zts=$arr["quota_cycle"];
  $yy=$arr["use_cycle"];
  $sy=$arr["surplus_cycle"];
  $id=$arr["id"];
  $active=$arr["active"];
  $note=$arr["note"];
  $shengyu=$zts-$yy;
  if($active==1){
	  $active="已激活";
  }else{
	  $active="欠费未激活";
  }
  if(round($recv/1024/1024)<100000){
	  echo "<br>";
	   echo "<br>";
	    echo "<br>";
		 
echo "<tr>";
echo "<td align='center' style='min-width:100px' valign='middle'>用户名</td>";
echo "<td align='center' style='min-width:160px' valign='middle'>".$iuser;
echo "</tr>";
echo "<tr>";
echo "<td align='center' style='min-width:100px' valign='middle'>状态</td>";
echo "<td align='center' style='min-width:160px' valign='middle'>".$active;
echo "</tr>";
echo "<tr>";
echo "<td align='center' style='min-width:100px' valign='middle'>总流量</td>";
echo "<td align='center' style='min-width:160px' valign='middle'>".round($recv/1024/1024);
echo "(MB)</tr>";
echo "<tr>";
echo "<td align='center' style='min-width:100px' valign='middle'>已使用</td>";
echo "<td align='center' style='min-width:160px' valign='middle'>".round($sent/1024/1024);
echo "(MB)</tr>";
echo "<tr>";
echo "<td align='center' style='min-width:100px' valign='middle'>剩余</td>";
echo "<td align='center' style='min-width:160px' valign='middle'>".round($all/1024/1024);
echo "MB</tr>";
echo "<tr>";
echo "<td align='center' style='min-width:100px' valign='middle'>总天数</td>";
echo "<td align='center' style='min-width:160px' valign='middle'>".$zts;
echo "天</tr>";
echo "<tr>";
echo "<td align='center' style='min-width:100px' valign='middle'>已用天数</td>";
echo "<td align='center' style='min-width:160px' valign='middle'>".$yy;
echo "天</tr>";
echo "<tr>";
echo "<td align='center' style='min-width:100px' valign='middle'>剩余天数</td>";
echo "<td align='center' style='min-width:160px' valign='middle'>".$shengyu;
echo "天</tr>";
echo "<tr>";
echo "<td align='center' style='min-width:100px' valign='middle'>激活时间</td>";
echo "<td align='center' style='min-width:160px' valign='middle'>".$start;
echo "</tr>";
  }
  else{
	   echo "<br>";
	    echo "<br>";
		 echo "<br>";
	  echo "<tr>";
echo "<td align='center' style='min-width:100px' valign='middle'>用户名</td>";
echo "<td align='center' style='min-width:160px' valign='middle'>".$iuser;
echo "</tr>";
echo "<tr>";
echo "<td align='center' style='min-width:100px' valign='middle'>状态</td>";
echo "<td align='center' style='min-width:160px' valign='middle'>".$active;
echo "</tr>";
echo "<tr>";
echo "<td align='center' style='min-width:100px' valign='middle'>总流量</td>";
echo "<td align='center' style='min-width:160px' valign='middle'>包月用户";
echo "<tr>";
echo "<td align='center' style='min-width:100px' valign='middle'>已使用</td>";
echo "<td align='center' style='min-width:160px' valign='middle'>".round($sent/1024/1024);
echo "(MB)</tr>";
echo "<tr>";
echo "<td align='center' style='min-width:100px' valign='middle'>剩余</td>";
echo "<td align='center' style='min-width:160px' valign='middle'>包月用户";

echo "<tr>";
echo "<td align='center' style='min-width:100px' valign='middle'>总天数</td>";
echo "<td align='center' style='min-width:160px' valign='middle'>包月用户";

echo "<tr>";
echo "<td align='center' style='min-width:100px' valign='middle'>已用天数</td>";
echo "<td align='center' style='min-width:160px' valign='middle'>".$yy;
echo "天</tr>";
echo "<tr>";
echo "<td align='center' style='min-width:100px' valign='middle'>剩余天数</td>";
echo "<td align='center' style='min-width:160px' valign='middle'>".$shengyu;
echo "<tr>";
echo "<td align='center' style='min-width:100px' valign='middle'>激活时间</td>";
echo "<td align='center' style='min-width:160px' valign='middle'>".$start;
echo "</tr>";
	  
	  
	  
  }
  }
  
}else{
	
	echo "<h2>您输入的用户名不存在！</h2><br>";
	 
	
}

?>
						
					</tfoot>
				  </table>
				</div>
			</div>
		</div>
		
<input id="btn" class="btn btn-primary" type="button" name="Submit" onclick="javascript:history.back(-1);" value="返回上一页">
	</div>
</section>

<script src="js/jquery-1.11.0.min.js" type="text/javascript"></script>
<script src="dist/jquery.table2excel.js"></script>
<script>
	$(function() {
		$("#btn").click(function(){
			$(".table2excel").table2excel({
				exclude: ".noExl",
				name: "Excel Document Name",
				filename: "myFileName",
				exclude_img: true,
				exclude_links: true,
				exclude_inputs: true
			});
		});
		
	});
</script>

<div style="text-align:center;margin:50px 0; font:normal 14px/24px 'MicroSoft YaHei';">
<p>适用浏览器：360、FireFox、Chrome、Safari、Opera、傲游、搜狗、世界之窗. 不支持IE8及以下浏览器。</p>
</div>
</body>
</html>