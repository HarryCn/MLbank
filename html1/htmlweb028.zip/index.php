<?php 
header("location:user/login.php");
 ?>
