<?php
$name=$_GET['user'];   
include_once('config.php'); 
include_once('phpcode.php'); 
mysql_query("SET NAMES UTF8");
mysql_select_db($db,$con);
$res=mysql_query("SELECT * FROM user WHERE username='$name';",$con);
$num=mysql_num_rows($res);
if($num==1){

while($arr = mysql_fetch_array($res))
  {
  $iuser=$arr["username"];
  $passwd=$arr["password"];
  $recv=$arr["quota_bytes"];
  $sent=$arr["used_quota"];
  $all=$arr["left_quota"];
  $i=$arr["active"];
  $start=$arr["creation"];
  $zts=$arr["quota_cycle"];
  $yy=$arr["use_cycle"];
  $sy=$arr["surplus_cycle"];
  $id=$arr["id"];
  $active=$arr["active"];
  $note=$arr["note"];
  $shengyu=$zts-$yy;
  if($active==1){
	  $active="已激活";
  }else{
	  $active="欠费未激活";
  }
  if(round($recv/1024/1024)<100000){
	  

echo "<p>用户名:";
echo "".$iuser;
echo "";

echo "<p>状态:";
echo "".$active;
echo "</p>";

echo "<p>总流量:";
echo "".round($recv/1024/1024);
echo "MB</p>";

echo "<p>已使用:";
echo "".round($sent/1024/1024);
echo "MB</p>";

echo "<p>剩余:";
echo "".round($all/1024/1024);
echo "MB</p>";

echo "<p>总天数:";
echo "".$zts;
echo "天</p>";

echo "<p>已用天数:";
echo "".$yy;
echo "天</p>";

echo "<p>剩余天数:";
echo "".$shengyu;
echo "天</p>";

echo "<p>激活时间:";
echo "".$start;
echo "</p>";

$dqdate=date('Y-m-d H:i:s',strtotime("$start +$shengyu day")); 

echo "<p>到期时间:";
echo "".$dqdate;
echo "</p>";

  }
  else{
	   

	  
	  echo "<p>用户名:";
echo "".$iuser;
echo "";

echo "<p>状态:";
echo "".$active;
echo "</p>";

echo "<p>总流量:";
echo "包月用户";
echo "</p>";

echo "<p>已使用:";
echo "".round($sent/1024/1024);
echo "MB</p>";

echo "<p>剩余:";
echo "包月用户";
echo "</p>";

echo "<p>总天数:";
echo "".$zts;
echo "天</p>";

echo "<p>已用天数:";
echo "".$yy;
echo "天</p>";

echo "<p>剩余天数:";
echo "".$shengyu;
echo "天</p>";

echo "<p>激活时间:";
echo "".$start;
echo "</p>";
$dqdate=date('Y-m-d H:i:s',strtotime("$start +$shengyu day")); 
echo "<p>到期时间:";
echo "".$dqdate;
echo "</p>";
  }
  }
  
}else{
	echo "<h2>您输入的用户名不存在！</h2><br>";
}

?>
						
					 