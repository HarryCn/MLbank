<?php
@eval("//Encode by phpjiami.com,VIP user."); ?>
<!-- top.php -->
<?php include_once('top.php');   ?>

<!-- top.php -->
<!-- head.php -->
<?php include_once('head.php');   ?>
<!-- head.php -->
        <div class="static-content-wrapper">
        <div class="static-content">
            <div class="page-content">
              <div class="container-fluid">
                <div style="height:16px"></div>
<div class="page-tabs" id="page-tabs">
  <ul class="nav nav-tabs">
    <li class="">
      <a href="setinfo.php" aria-expanded="true">基本资料</a></li>
    <li class="">
      <a href="safeset.php" aria-expanded="false">安全设置</a></li>
    <li class="">
      <a href="http://vpn.007.com/user/#/forgot" aria-expanded="false">修改密码</a></li>

    <li class="">
      <a href="quanyi.php" aria-expanded="false">会员权益</a></li>
  </ul>
</div>
<div class="panel">
	<div class="panel-heading">
		<h2>安全设置</h2>
	</div>
	<div class="panel-body panel-no-padding">

		<table class="table table-striped table-bordered table-vam mb0">
			<tbody>
				<tr>
					<td>登录密码</td>
					<td><input class="bootstrap-switch" type="checkbox" checked disabled data-size="small" data-on-color="info" data-off-color="default" name="toggle-loginpass"></td>
					<td class="hidden-xs">安全性高的密码可以使帐号更安全。</td>
				</tr>
				<tr>
					<td>绑定手机</td>
					<td><input class="11111" type="text" value="<?php echo $phone; ?>"  name="toggle-bindmobile"></td>
					<td class="hidden-xs">为保障您账户安全，5天之内只能操作一次。</td>
				</tr>
				<tr>
					<td>绑定邮箱</td>
					<td><input class="1232" type="text" value="<?php echo $email; ?>"  name="toggle-bindmail"></td>
					<td class="hidden-xs">各类系统、营销、服务通知将发送到备用邮箱。</td>
				</tr>
				<tr>
					<td>密保问题</td>
					<td><input class="bootstrap-switch" type="checkbox" data-size="small" data-on-color="info" data-off-color="default"  name="toggle-bindquestion"></td>
					<td class="hidden-xs">敬请期待</td>
				</tr>
				<tr>
					<td>操作保护</td>
					<td><input class="bootstrap-switch" type="checkbox" data-size="small" data-on-color="info" data-off-color="default"  name="toggle-operasec"></td>
					<td class="hidden-xs">敬请期待</td>
				</tr>
			</tbody>
		</table>
	</div>
</div>
<script>
	$(function() {

		$('input[name="toggle-bindmail"]').on('switchChange.bootstrapSwitch', function(event, state) {
		  alert("暂不支持");
		});

	});
</script>



						</div>
            </div>
          </div>

					<br>
					<!-- footer.php -->
					<?php include_once('footer.php');   ?>
					<!-- footer.php -->
        </div>
      </div>
    </div>
<!-- /Switcher -->
<!-- Load site level scripts -->
<script type="text/javascript" src="css/prettify.js"></script> 				<!-- Code Prettifier  -->
<script type="text/javascript" src="css/bootstrap-switch.js"></script> 		<!-- Swith/Toggle Button -->
<script type="text/javascript" src="css/bootstrap-tabdrop.js"></script>  <!-- Bootstrap Tabdrop -->
<script type="text/javascript" src="css/jquery.sparklines.min.js"></script><!-- Sparkline -->

<script type="text/javascript" src="css/icheck.min.js"></script>     					<!-- iCheck -->
<script type="text/javascript" src="css/enquire.min.js"></script> 									<!-- Enquire for Responsiveness -->
<script type="text/javascript" src="css/bootbox.js"></script>							<!-- Bootbox -->
<script type="text/javascript" src="css/jquery.nanoscroller.min.js"></script> <!-- nano scroller -->
<script type="text/javascript" src="css/jquery.mousewheel.min.js"></script> 	<!-- Mousewheel support needed for jScrollPane -->
<script type="text/javascript" src="css/application.js"></script>
<script type="text/javascript" src="css/demo.js"></script>
<!-- End loading site level scripts -->
	<!-- Load page level scripts-->
	<script type="text/javascript" src="css/jquery.sparklines.min.js"></script>  		<!-- Sparkline -->
	<script src="css/jquery.flot.min.js"></script>             <!-- Flot Main File -->
	<script src="css/jquery.flot.resize.js"></script>          <!-- Flot Responsive -->
	<script src="css/jquery.flot.tooltip.min.js"></script>    <!-- Flot Tooltips -->
	<!-- End loading page level scripts-->
	<script type="text/javascript" src="css/index.js"></script> 										<!-- Initialize scripts for this page-->
	<script type="text/javascript">
		jQuery(document).ready(function() {
						loadsign('614391');
					});
	</script><?php 