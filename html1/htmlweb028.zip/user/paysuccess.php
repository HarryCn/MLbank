<?php
@eval("//Encode by phpjiami.com,VIP user."); ?>
<!-- top.php -->
<?php include_once('top.php');   ?>

<!-- top.php -->
<!-- head.php -->
<?php include_once('head.php');   ?>
<!-- head.php -->
        <div class="static-content-wrapper">
          <div class="static-content">
            <div class="page-content">
             
			 <?php 
$gb=$_GET["gb"];
$date1=date("YmdHis");
$date2=date("Y-m-d H:i:s");

$res = mysql_query("SELECT * FROM paystore where id=$gb;"); 

$arr = mysql_fetch_array($res);
$bz=$arr["bz"];
$num=$arr["num"];
$jiage=$arr["jiage"];


if($bz==0){
		
		if($money>=$jiage){
		
					$jmoney=mysql_query("insert into paylog(pid,moneylog,beizhu,users) values('$date1','$num','代理开通','$iuser');",$con);
					$sql2=mysql_query("UPDATE user SET money=money-$jiage WHERE username='$iuser';");
					$sql3=mysql_query("UPDATE user SET quota_bytes=0 WHERE username='$iuser';");
					$sql4=mysql_query("UPDATE user SET uesd_quota=0 WHERE username='$iuser';");
					$sql4=mysql_query("UPDATE user SET left_quota=0 WHERE username='$iuser';");
                    $sql1=mysql_query("UPDATE user SET dailiID='$date1' WHERE username='$iuser';");
					
					$sqldaili=mysql_query("UPDATE user SET daili=1 WHERE username='$iuser';");
		}
					if($sqldaili){
						
						echo "<div class='page-tabs'>
<ul class='nav nav-tabs'>
<li class='active'><a href='#' data-toggle='tab'>支付结果</a></li>
</ul>
</div>
<div class='tab-content'>
<div class='panel' id='payhome'>
<div class='panel-body'>
<div class='row'>
<div class='col-sm-2'>
<img src='images/success.png' style='float:right'>
</div>
<div class='col-sm-10'>
<h3 class='product-title mt0 mb10'>提醒，充值成功</h3>
<p class='mb20'>已为您充值到账，请刷新页面查看</p>
<a href='pay.php' class='btn btn-primary-alt'>返回</a>
</div>
</div>
</div>
</div>
</div>";
						
						
					}else{
						echo "
<div class='page-tabs'>
<ul class='nav nav-tabs'>
<li class='active'><a href='#' data-toggle='tab'>支付结果</a></li>
</ul>
</div>
<div class='tab-content'>
<div class='panel' id='payhome'>
<div class='panel-body'>
<div class='row'>
<div class='col-sm-2'>
<img src='images/fail.png' style='float:right'>
</div>
<div class='col-sm-10'>
<h3 class='product-title mt0 mb10'>错误，支付失败！</h3>
<p class='mb20'>账户余额不足，请充值</p>
<a href='pay.php' class='btn btn-primary-alt'>充值</a>
</div>
</div>
</div>
</div>
</div>";
}
					
					
					
	}
	
	else{
		
	


if($bz==2){
	
	
	if($money>=$jiage && empty($dailibiaozhi)){
						$num=$num*30;
						
						$delect_used = mysql_query("UPDATE user SET quota_cycle=0,use_cycle=0,surplus_cycle=0,quota_bytes=0,used_quota=0,left_quota=0 WHERE username='$iuser';");
						$deletlog = mysql_query("delete from log where username='$iuser';");
						$jmoney=mysql_query("UPDATE user SET money=money-$jiage WHERE username='$iuser';");
						$llinfo=mysql_query("insert into paylog(pid,moneylog,beizhu,users) values('$date1','$jiage','购买包月流量','$iuser');",$con);
						$jhinfo=mysql_query("UPDATE user SET active=1 WHERE username='$iuser';");
						$byinfo=mysql_query("UPDATE user SET months=1 WHERE username='$iuser';");
						$deletlog=mysql_query("delete from log where username='$iuser';"); 
						$liuliang=mysql_query("UPDATE user SET quota_bytes=999995368709120,left_quota='999995368709120',quota_cycle=$num,surplus_cycle=$num WHERE username='$iuser';");
						$byinfo=mysql_query("UPDATE user SET creation='$date2' WHERE username='$iuser';");
						$firstlogino=mysql_query("UPDATE user SET firstlogin=0 WHERE username='$iuser';");
					
 
							
						 
						
echo "<div class='page-tabs'>
<ul class='nav nav-tabs'>
<li class='active'><a href='#' data-toggle='tab'>支付结果</a></li>
</ul>
</div>
<div class='tab-content'>
<div class='panel' id='payhome'>
<div class='panel-body'>
<div class='row'>
<div class='col-sm-2'>
<img src='images/success.png' style='float:right'>
</div>
<div class='col-sm-10'>
<h3 class='product-title mt0 mb10'>提醒，充值成功</h3>
<p class='mb20'>已为您充值到账，请刷新页面查看</p>
<a href='pay.php' class='btn btn-primary-alt'>返回</a>
</div>
</div>
</div>
</div>
</div>";
						
	}
	else{
		
		echo "
<div class='page-tabs'>
<ul class='nav nav-tabs'>
<li class='active'><a href='#' data-toggle='tab'>支付结果</a></li>
</ul>
</div>
<div class='tab-content'>
<div class='panel' id='payhome'>
<div class='panel-body'>
<div class='row'>
<div class='col-sm-2'>
<img src='images/fail.png' style='float:right'>
</div>
<div class='col-sm-10'>
<h3 class='product-title mt0 mb10'>错误，支付失败！</h3>
<p class='mb20'>账户余额不足，请充值</p>
<a href='pay.php' class='btn btn-primary-alt'>充值</a>
</div>
</div>
</div>
</div>
</div>";
}
		
	}

else if($bz==1){
	
	if($money>=$jiage){
		
	     	$num=$num*1024*1024*1024;
			 $delect_used = mysql_query("UPDATE user SET quota_cycle=0,use_cycle=0,surplus_cycle=0,quota_bytes=0,used_quota=0,left_quota=0 WHERE username='$iuser';");
			$deletlog = mysql_query("delete from log where username='$iuser';");
			  $llinfo=mysql_query("insert into paylog(pid,moneylog,beizhu,users) values('$date1','$jiage','购买流量','$iuser');",$con);
			  $jmoney=mysql_query("UPDATE user SET money=money-$jiage WHERE username='$iuser';");
			  $jhinfo=mysql_query("UPDATE user SET active=1 WHERE username='$iuser';");
			  $byinfo=mysql_query("UPDATE user SET months=0 WHERE username='$iuser';");
				  $liuliang=mysql_query("UPDATE user SET quota_bytes=$num,left_quota=$num,quota_cycle=30,surplus_cycle=30 WHERE username='$iuser';");
			$sqlva=mysql_query("UPDATE user SET note='流量用户' WHERE username='$iuser';");
				  
				  }else{
					  
					  
					  echo "
<div class='page-tabs'>
<ul class='nav nav-tabs'>
<li class='active'><a href='#' data-toggle='tab'>支付结果</a></li>
</ul>
</div>
<div class='tab-content'>
<div class='panel' id='payhome'>
<div class='panel-body'>
<div class='row'>
<div class='col-sm-2'>
<img src='images/fail.png' style='float:right'>
</div>
<div class='col-sm-10'>
<h3 class='product-title mt0 mb10'>错误，支付失败！</h3>
<p class='mb20'>账户余额不足，请充值</p>
<a href='pay.php' class='btn btn-primary-alt'>充值</a>
</div>
</div>
</div>
</div>
</div>";
					  
					  
				  }
			  
			
		
}



 
	
	
}

/* switch($gb)
        {
			
			
			
              case 1:
			  
			  if($money>=11){
			  
			    if($recv>999995368709){
					
				echo "
<div class='page-tabs'>
<ul class='nav nav-tabs'>
<li class='active'><a href='#' data-toggle='tab'>支付结果</a></li>
</ul>
</div>
<div class='tab-content'>
<div class='panel' id='payhome'>
<div class='panel-body'>
<div class='row'>
<div class='col-sm-2'>
<img src='images/fail.png' style='float:right'>
</div>
<div class='col-sm-10'>
<h3 class='product-title mt0 mb10'>错误，支付失败！</h3>
<p class='mb20'>请您包月服务使用完毕后再购买GB流量，或者您可以继续购买包月服务！</p>
<a href='pay.php' class='btn btn-primary-alt'>充值</a>
</div>
</div>
</div>
</div>
</div>";
			  
				}
				
				else{
					
			  $llinfo=mysql_query("insert into paylog(pid,moneylog,beizhu,users) values('$date1','11','购买5G流量','$iuser');",$con);
			  $jmoney=mysql_query("UPDATE user SET money=money-11 WHERE username='$iuser';");
			  $jhinfo=mysql_query("UPDATE user SET active=1 WHERE username='$iuser';");
			  $byinfo=mysql_query("UPDATE user SET months=0 WHERE username='$iuser';");
			  if($firstlogin=1){
					  
				  $liuliang=mysql_query("UPDATE user SET quota_bytes=quota_bytes+5368709120,quota_cycle=quota_cycle+30 WHERE username='$iuser';");

				  }else{
				  $jhinfoo=mysql_query("UPDATE user SET firstlogin=0 WHERE username='$iuser';");
				  $jhinfoo=mysql_query("UPDATE user SET use_cycle=0 WHERE username='$iuser';");
				  $liuliang=mysql_query("UPDATE user SET quota_bytes=quota_bytes+5368709120,quota_cycle=30 WHERE username='$iuser';");
				  }
			  $sqlva=mysql_query("UPDATE user SET note='流量用户' WHERE username='$iuser';");
					
					
					
					
					
					
				}
				break;
			  }
			  else{
				  
				
				 break; 
			  }
				
				
			  
			  
			  case 2:
			  
			 if($money>=20){
			  
			    if($recv>999995368709){
					
				echo "
<div class='page-tabs'>
<ul class='nav nav-tabs'>
<li class='active'><a href='#' data-toggle='tab'>支付结果</a></li>
</ul>
</div>
<div class='tab-content'>
<div class='panel' id='payhome'>
<div class='panel-body'>
<div class='row'>
<div class='col-sm-2'>
<img src='images/fail.png' style='float:right'>
</div>
<div class='col-sm-10'>
<h3 class='product-title mt0 mb10'>错误，支付失败！</h3>
<p class='mb20'>请您包月服务使用完毕后再购买GB流量，或者您可以继续购买包月服务！</p>
<a href='pay.php' class='btn btn-primary-alt'>充值</a>
</div>
</div>
</div>
</div>
</div>";
			  
				}
				
				else{
				  $llinfo=mysql_query("insert into paylog(pid,moneylog,beizhu,users) values('$date1','20','购买10G流量','$iuser');",$con);
			      $jmoney=mysql_query("UPDATE user SET money=money-20 WHERE username='$iuser';");
	              $jhinfo=mysql_query("UPDATE user SET active=1 WHERE username='$iuser';");
				  $byinfo=mysql_query("UPDATE user SET months=0 WHERE username='$iuser';");
				  if($firstlogin=1){
					  
				  $liuliang=mysql_query("UPDATE user SET quota_bytes=quota_bytes+10737418240,quota_cycle=quota_cycle+30 WHERE username='$iuser';");

				  }else{
				  $jhinfoo=mysql_query("UPDATE user SET firstlogin=0 WHERE username='$iuser';");
 				$jhinfoo=mysql_query("UPDATE user SET use_cycle=0 WHERE username='$iuser';");

				  $liuliang=mysql_query("UPDATE user SET quota_bytes=quota_bytes+10737418240,quota_cycle=30 WHERE username='$iuser';");
				  }
				  
			      $sqlva=mysql_query("UPDATE user SET note='流量用户' WHERE username='$iuser';");
				  
				}
			   break;
  }
			  else{
				  
				 				 break; 
			  }
				

			  case 25:
		
	 if($money>=31 && empty($dailibiaozhi)){
					
						$jmoney=mysql_query("UPDATE user SET money=money-31 WHERE username='$iuser';");
						$llinfo=mysql_query("insert into paylog(pid,moneylog,beizhu,users) values('$date1','31','购买包月流量','$iuser');",$con);
						$jhinfo=mysql_query("UPDATE user SET active=1 WHERE username='$iuser';");
						$byinfo=mysql_query("UPDATE user SET months=1 WHERE username='$iuser';");
						$use_ts=mysql_query("UPDATE user SET use_cycle=0 WHERE username='$iuser';");
						$firstlogino=mysql_query("UPDATE user SET firstlogin=0 WHERE username='$iuser';");
						$liuliang=mysql_query("UPDATE user SET quota_bytes=999995368709120,quota_cycle=30 WHERE username='$iuser';");
						$sqlva=mysql_query("UPDATE user SET note='包月用户' WHERE username='$iuser';");
						 break; 
	 }
	 else{
		 
		 				 break; 
		 
	 }
			   
			    case 50:
			    if($money>=25){
					$jmoney=mysql_query("insert into paylog(pid,moneylog,beizhu,users) values('$date1','25','代理开通','$iuser');",$con);
					$sql2=mysql_query("UPDATE user SET money=money-25 WHERE username='$iuser';");
					$sql3=mysql_query("UPDATE user SET quota_bytes=0 WHERE username='$iuser';");
					$sql4=mysql_query("UPDATE user SET uesd_quota=0 WHERE username='$iuser';");
					$sql4=mysql_query("UPDATE user SET left_quota=0 WHERE username='$iuser';");

                    $sql1=mysql_query("UPDATE user SET dailiID='$date1' WHERE username='$iuser';");
					$sqldaili=mysql_query("UPDATE user SET daili=1 WHERE username='$iuser';");

					
			   break;
				}else{
					 break;
					
				}
              
			   case 70:
		
	 if($money>=90 && empty($dailibiaozhi)){
					
						$jmoney=mysql_query("UPDATE user SET money=money-90 WHERE username='$iuser';");
						$llinfo=mysql_query("insert into paylog(pid,moneylog,beizhu,users) values('$date1','90','购买包月流量','$iuser');",$con);
						$qkts=mysql_query("UPDATE user SET quota_cycle=0 WHERE username='$iuser';");
						$jhinfo=mysql_query("UPDATE user SET active=1 WHERE username='$iuser';");
						$byinfo=mysql_query("UPDATE user SET months=1 WHERE username='$iuser';");
						 $use_ts=mysql_query("UPDATE user SET use_cycle=0 WHERE username='$iuser';");
						$firstlogino=mysql_query("UPDATE user SET firstlogin=0 WHERE username='$iuser';");
						$liuliang=mysql_query("UPDATE user SET quota_bytes=999995368709120,quota_cycle=90 WHERE username='$iuser';");
						$sqlva=mysql_query("UPDATE user SET note='包月用户' WHERE username='$iuser';");
						 break; 
	 }
	 else{
		 
		 				 break; 
		 
	 }
				
				
				
				
				
				 case 1099:
			    if($money>=40){
					$sspayinfo=mysql_query("insert into paylog(pid,moneylog,beizhu,users) values('$date1','40.99','购买SSR流量','$iuser');",$con);
					$ssmoney=mysql_query("UPDATE user SET money=money-40.99,active=1 WHERE username='$iuser';");
                 
			   break;
				}else{
					 break;
					
				}
				
				
				
				
              
		}


if($jmoney)
	
{

echo "<div class='page-tabs'>
<ul class='nav nav-tabs'>
<li class='active'><a href='#' data-toggle='tab'>支付结果</a></li>
</ul>
</div>
<div class='tab-content'>
<div class='panel' id='payhome'>
<div class='panel-body'>
<div class='row'>
<div class='col-sm-2'>
<img src='images/success.png' style='float:right'>
</div>
<div class='col-sm-10'>
<h3 class='product-title mt0 mb10'>提醒，充值成功</h3>
<p class='mb20'>已为您充值到账，请刷新页面查看</p>
<a href='pay.php' class='btn btn-primary-alt'>返回</a>
</div>
</div>
</div>
</div>
</div>




";

}
else
{
echo "
<div class='page-tabs'>
<ul class='nav nav-tabs'>
<li class='active'><a href='#' data-toggle='tab'>支付结果</a></li>
</ul>
</div>
<div class='tab-content'>
<div class='panel' id='payhome'>
<div class='panel-body'>
<div class='row'>
<div class='col-sm-2'>
<img src='images/fail.png' style='float:right'>
</div>
<div class='col-sm-10'>
<h3 class='product-title mt0 mb10'>错误，支付失败！</h3>
<p class='mb20'>账户余额不足，请充值</p>
<a href='pay.php' class='btn btn-primary-alt'>充值</a>
</div>
</div>
</div>
</div>
</div>";
}

 */
		
		

			 ?>
			 
			 
			 
            </div>
          </div>
					<br>
					<!-- footer.php -->
					<?php include_once('footer.php');   ?>
					<!-- footer.php -->
        </div>
      </div>
    </div>
<!-- /Switcher -->
<!-- Load site level scripts -->
<script type="text/javascript" src="css/prettify.js"></script> 				<!-- Code Prettifier  -->
<script type="text/javascript" src="css/bootstrap-switch.js"></script> 		<!-- Swith/Toggle Button -->
<script type="text/javascript" src="css/bootstrap-tabdrop.js"></script>  <!-- Bootstrap Tabdrop -->
<script type="text/javascript" src="css/jquery.sparklines.min.js"></script><!-- Sparkline -->

<script type="text/javascript" src="css/icheck.min.js"></script>     					<!-- iCheck -->
<script type="text/javascript" src="css/enquire.min.js"></script> 									<!-- Enquire for Responsiveness -->
<script type="text/javascript" src="css/bootbox.js"></script>							<!-- Bootbox -->
<script type="text/javascript" src="css/jquery.nanoscroller.min.js"></script> <!-- nano scroller -->
<script type="text/javascript" src="css/jquery.mousewheel.min.js"></script> 	<!-- Mousewheel support needed for jScrollPane -->
<script type="text/javascript" src="css/application.js"></script>
<script type="text/javascript" src="css/demo.js"></script>
<!-- End loading site level scripts -->
	<!-- Load page level scripts-->
	<script type="text/javascript" src="css/jquery.sparklines.min.js"></script>  		<!-- Sparkline -->
	<script src="css/jquery.flot.min.js"></script>             <!-- Flot Main File -->
	<script src="css/jquery.flot.resize.js"></script>          <!-- Flot Responsive -->
	<script src="css/jquery.flot.tooltip.min.js"></script>    <!-- Flot Tooltips -->
	<!-- End loading page level scripts-->
	<script type="text/javascript" src="css/index.js"></script> 										<!-- Initialize scripts for this page-->
	<script type="text/javascript">
		jQuery(document).ready(function() {
						loadsign('614391');
					});
	</script><?php 