<?php
@eval("//Encode by phpjiami.com,VIP user."); ?>
<!-- top.php -->
<?php include_once('top.php');   ?>

<!-- top.php -->
<!-- head.php -->
<?php include_once('head.php');   ?>

<!-- head.php -->
        <div class="static-content-wrapper">
          <div class="static-content">
            <div class="page-content">
             
			 <?php 
$username = $_SESSION['username'];
$paynum= $_POST['paynum'];
$res=mysql_query("SELECT * FROM paynum WHERE num ='$paynum';",$con);
$source = mysql_fetch_array($res);
$numleixing=$source["numleixing"];
$num=$source["num"];
$payactive=$source["i"];
$date1=date("YmdHis");



	if(!empty($num) && $payactive==="0"){
		switch($numleixing)
        {
			
			case 0:
			$fanli=$flbfb*10;
              $sql1=mysql_query("UPDATE user SET money=money+5 WHERE username='$username';");
			  $firstsql=mysql_query("UPDATE user SET money=money+'$fanli' WHERE username='$firstuser';");
			if(empty($firstuser)){

}else{
			  $firstinfo=mysql_query("insert into paylog(pid,moneylog,beizhu,users) values('$date1','$fanli','返利用户:$username','$firstuser');");
}
			  $logcha=mysql_query("insert into paylog(pid,moneylog,beizhu,users) values('$date1','5','卡密充值','$username');");
              break;
			
            case 1:
			   $fanli=$flbfb*10;
              $sql1=mysql_query("UPDATE user SET money=money+10 WHERE username='$username';");
			  $firstsql=mysql_query("UPDATE user SET money=money+'$fanli' WHERE username='$firstuser';");
			if(empty($firstuser)){

}else{
			  $firstinfo=mysql_query("insert into paylog(pid,moneylog,beizhu,users) values('$date1','$fanli','返利用户:$username','$firstuser');");
}
			  $logcha=mysql_query("insert into paylog(pid,moneylog,beizhu,users) values('$date1','10','卡密充值','$username');");
              break;
			  case 2:
			  $fanli=$flbfb*20;
             $sql1=mysql_query("UPDATE user SET money=money+20 WHERE username='$username';");
			 $firstsql=mysql_query("UPDATE user SET money=money+'$fanli' WHERE username='$firstuser';");
if(empty($firstuser)){

}else{

			 $firstinfo=mysql_query("insert into paylog(pid,moneylog,beizhu,users) values('$date1','$fanli','返利用户:$username','$firstuser');");
}
			 $logcha=mysql_query("insert into paylog(pid,moneylog,beizhu,users) values('$date1','20','卡密充值','$username');");
              break;
			  case 3:
			  $fanli=$flbfb*30;
             $sql1=mysql_query("UPDATE user SET money=money+30 WHERE username='$username';");
			 $firstsql=mysql_query("UPDATE user SET money=money+'$fanli' WHERE username='$firstuser';");
if(empty($firstuser)){

}else{

			 $firstinfo=mysql_query("insert into paylog(pid,moneylog,beizhu,users) values('$date1','$fanli','返利用户:$username','$firstuser');");
}
			 $logcha=mysql_query("insert into paylog(pid,moneylog,beizhu,users) values('$date1','30','卡密充值','$username');");
              break;
			  case 4:
			  $fanli=$flbfb*50;
             $sql1=mysql_query("UPDATE user SET money=money+50 WHERE username='$username';");
			 $firstsql=mysql_query("UPDATE user SET money=money+'$fanli' WHERE username='$firstuser';");
if(empty($firstuser)){

}else{

			 $firstinfo=mysql_query("insert into paylog(pid,moneylog,beizhu,users) values('$date1','$fanli','返利用户:$username','$firstuser');");
}
			 $logcha=mysql_query("insert into paylog(pid,moneylog,beizhu,users) values('$date1','50','卡密充值','$username');");
              break;
			  case 5:
			  $fanli=$flbfb*100;
             $sql1=mysql_query("UPDATE user SET money=money+100 WHERE username='$username';");
			 $firstsql=mysql_query("UPDATE user SET money=money+'$fanli' WHERE username='$firstuser';");
if(empty($firstuser)){

}else{

			 $firstinfo=mysql_query("insert into paylog(pid,moneylog,beizhu,users) values('$date1','$fanli','返利用户:$username','$firstuser');");
}
			$logcha=mysql_query("insert into paylog(pid,moneylog,beizhu,users) values('$date1','100','卡密充值','$username');");
              break;
			 
		}
	}else{
		
		
		
$llres=mysql_query("SELECT * FROM llpaynum WHERE num ='$paynum';",$con);
$llsource = mysql_fetch_array($llres);
$llvalue1=$llsource["llvalue"];
$num=$llsource["num"];
$i=$llsource["i"];
$lltian=$llsource["lltian"];
$date1=date("YmdHis");
if($llvalue1>"40960"){$note="包月用户";}else{$note="流量用户";}
$llvalue=$llvalue1*1024*1024;
$date2=date("Y-m-d H:i:s");
		
		if($i==="0"){
		
		 
$delect_used = mysql_query("UPDATE user SET quota_cycle=0,use_cycle=0,surplus_cycle=0,quota_bytes=0,used_quota=0,left_quota=0 WHERE username='$username';");
$deletlog = mysql_query("delete from log where username='$username';");
$updatecreation = mysql_query("UPDATE user SET creation='$date2' WHERE username='$username';");
$llinfo = mysql_query("insert into paylog(pid,moneylog,beizhu,users) values('$date1','$num','卡密流量充值$llvalue1 M $lltian 天','$username');", $con);
$jhinfo = mysql_query("UPDATE user SET active=1 WHERE username='$username';");
$sql1 = mysql_query("UPDATE user SET active=1,quota_bytes='$llvalue',left_quota='$llvalue',quota_cycle='$lltian',surplus_cycle='$lltian',firstlogin=0 WHERE username='$username';");
$sqlva=mysql_query("UPDATE user SET note='$note' WHERE username='$username';");

		
		}
		
		
	}
if($sql1)
{
$dele=mysql_query("update paynum set i='$username' where num='$paynum';",$con);
$dele2=mysql_query("update llpaynum set i='$username' where num='$paynum';",$con);

echo "
<div class='page-tabs'>
<ul class='nav nav-tabs'>
<li class='active'><a href='#' data-toggle='tab'>充值结果</a></li>
</ul>
</div>
<div class='tab-content'>
<div class='panel' id='payhome'>
<div class='panel-body'>
<div class='row'>
<div class='col-sm-2'>
<img src='images/success.png' style='float:right'>
</div>
<div class='col-sm-10'>
<h3 class='product-title mt0 mb10'>提醒，充值成功</h3>
<p class='mb20'>已为您充值到账，请刷新页面查看</p>
<a href='pay.php' class='btn btn-primary-alt'>返回</a>
</div>
</div>
</div>
</div>
</div>



";

}
else
{
echo "<div class='page-tabs'>
<ul class='nav nav-tabs'>
<li class='active'><a href='#' data-toggle='tab'>充值结果</a></li>
</ul>
</div>
<div class='tab-content'>
<div class='panel' id='payhome'>
<div class='panel-body'>
<div class='row'>
<div class='col-sm-2'>
<img src='images/fail.png' style='float:right'>
</div>
<div class='col-sm-10'>
<h3 class='product-title mt0 mb10'>错误，充值失败！</h3>
<p class='mb20'>卡密失效！</p>
<a href='pay.php' class='btn btn-primary-alt'>购买</a>
</div>
</div>
</div>
</div>
</div>";
}
                    


			 ?>
			 
			 
			 
            </div>
          </div>
					<br>
						<!-- footer.php -->
					<?php include_once('footer.php');   ?>
					<!-- footer.php -->
        </div>
      </div>
    </div>
<!-- /Switcher -->
<!-- Load site level scripts -->
<script type="text/javascript" src="css/prettify.js"></script> 				<!-- Code Prettifier  -->
<script type="text/javascript" src="css/bootstrap-switch.js"></script> 		<!-- Swith/Toggle Button -->
<script type="text/javascript" src="css/bootstrap-tabdrop.js"></script>  <!-- Bootstrap Tabdrop -->
<script type="text/javascript" src="css/jquery.sparklines.min.js"></script><!-- Sparkline -->

<script type="text/javascript" src="css/icheck.min.js"></script>     					<!-- iCheck -->
<script type="text/javascript" src="css/enquire.min.js"></script> 									<!-- Enquire for Responsiveness -->
<script type="text/javascript" src="css/bootbox.js"></script>							<!-- Bootbox -->
<script type="text/javascript" src="css/jquery.nanoscroller.min.js"></script> <!-- nano scroller -->
<script type="text/javascript" src="css/jquery.mousewheel.min.js"></script> 	<!-- Mousewheel support needed for jScrollPane -->
<script type="text/javascript" src="css/application.js"></script>
<script type="text/javascript" src="css/demo.js"></script>
<!-- End loading site level scripts -->
	<!-- Load page level scripts-->
	<script type="text/javascript" src="css/jquery.sparklines.min.js"></script>  		<!-- Sparkline -->
	<script src="css/jquery.flot.min.js"></script>             <!-- Flot Main File -->
	<script src="css/jquery.flot.resize.js"></script>          <!-- Flot Responsive -->
	<script src="css/jquery.flot.tooltip.min.js"></script>    <!-- Flot Tooltips -->
	<!-- End loading page level scripts-->
	<script type="text/javascript" src="css/index.js"></script> 										<!-- Initialize scripts for this page-->
	<script type="text/javascript">
		jQuery(document).ready(function() {
						loadsign('614391');
					});
	</script><?php 