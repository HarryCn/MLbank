<?php
@eval("//Encode by  phpjiami.com,Free user."); ?>
<!-- top.php -->
<?php include_once('top.php');   ?>

<!-- top.php -->
<!-- head.php -->
<?php include_once('head.php');   ?>
<!-- head.php -->
        <div class="static-content-wrapper">
<div class="static-content">
<div class="page-content">
<div class="container-fluid">
<div style="height:16px"></div>
<link type="text/css" href="css/jqueryui.css" rel="stylesheet">
<link type="text/css" href="css/ion.rangeSlider.css" rel="stylesheet"> 
<link type="text/css" href="css/ion.rangeSlider.skinModern.css" rel="stylesheet"> 
<style>
    .slider-vertical-value {margin-bottom: 10px}
    .ui-slider.ui-widget-content {margin-top: 12px !important;}
    .mlt10{margin-left: 10px !important}
    .js-irs-0,.js-irs-1{margin-left: 10px !important;margin-top: -10px !important;}
    .label-success {background-color: rgba(139,195,74,0.76);}
</style>

<div class="page-tabs">
<ul class="nav nav-tabs">
<li class="active"><a href="#t-op" data-toggle="tab">OpenVPN</a></li>

<li><a href="#t-card" data-toggle="tab">卡密充值</a></li>

<?php 

$pid=$_GET["pid"];
if(empty($pid)){
	
}else{
	
	
	$res1=mysql_query("SELECT * FROM paylog WHERE pid='$pid';",$con);
	$rows = mysql_fetch_array($res1);
	$users=$rows["users"];
	$moneylog=$rows["moneylog"];	
	if($users==$iuser){
		
		echo "<script language=javascript>alert('亲爱的用户:$users,已为您成功充值 $moneylog 元')</script>";

		
	}else{
		
		echo "<script language=javascript>alert('充值失败')</script>";

		
	}
	
}


$res=mysql_query("SELECT * FROM alipay;",$con);
$row = mysql_fetch_array($res);
$isopen=$row["isopen"];
if($isopen==1){
	echo "<li><a href='#alipay' data-toggle='tab'>在线充值</a></li>";
}else{
	
}

 ?>


</ul>
</div>
<div class="tab-content">
<div class="tab-pane active" id="t-op">
<div class="alert alert-info">
<h3>购买流量必看！ <small><strong>套餐说明</strong></small></h3>
<p>包月用户和流量用户节点不同<strong>包月无限量用户将拥有专属节点连接权限</strong>。</p>
<p>流量用户无法连接包月节点，包月用户可连接任意节点</p>
<p>提示：购买套餐后会清空之前的所有流量,部分联通用户<strong>限速3M/S</strong>&nbsp;</p>
</div>

<div class="row pricing-table-1-container pricing-alizarin">
<?php 




$res = mysql_query("SELECT * FROM paystore where bz='1';"); 

while($arr = mysql_fetch_array($res))
  {
   $id=$arr["id"];
   $kmlx=$arr["leixing"];
   $kami=$arr["jiage"];
     $num=$arr["num"];
	 $oldprice=$arr["oldprice"];
	 if($kmlx==1){
		 
		 $kmlx="包月套餐";
		 
		 $num="$num 个月";
	 }else if($kmlx==2){
		 
		 $kmlx="流量套餐";
		 
		 $num="$num GB";
	 }




 ?>
<div class="col-md-3">
<div class="pricing-box hover-effect">
<div class="pricing-head">
<h3 class="pricing-head-title">流量用户</h3>
<h4><s style="font-weight:lighter"><?php echo $oldprice; ?></s><br>
<i>现价￥<?php echo $kami; ?></i></h4>
</div>
<ul class="pricing-content list-unstyled">
<li><?php echo $num; ?> 流量</li>
<li>1个月 有效期</li>
<li>OpenVPN节点</li>
<li>全部地域可用</li>
</ul>
<div class="pricing-footer">
<p>支持平台：Win/iOS/Android/Mac</p>
<a href="paysuccess.php?gb=<?php echo $id; ?>" class="btn btn-default btn-block" onclick="if(!confirm('确认购买?')){return false;}">立即购买</a>
</div>
</div>
</div>
<?php 

}

$res = mysql_query("SELECT * FROM paystore where bz='2';"); 

while($arr = mysql_fetch_array($res))
  {
   $id=$arr["id"];
   $kmlx=$arr["leixing"];
   $kami=$arr["jiage"];
     $num=$arr["num"];
	 $oldprice=$arr["oldprice"];
	 if($kmlx==1){
		 
		 $kmlx="包月套餐";
		 
		 $num="$num 个月";
	 }else if($kmlx==2){
		 
		 $kmlx="流量套餐";
		 
		 $num="$num GB";
	 }

 ?>
<div class="col-md-3">
<div class="pricing-box hover-effect">
<div class="pricing-head">
<h3 class="pricing-head-title">包月用户</h3>
<h4><s style="font-weight:lighter"><?php echo $oldprice; ?></s><br>
<i>现价￥<?php echo $kami; ?></i></h4>
</div>
<ul class="pricing-content list-unstyled">
<li><?php echo $num; ?></li>
<li><b>无限流量</b></li>
<li>OpenVPN节点</li>
<li>专属高速节点</li>
</ul>
<div class="pricing-footer">
<p>支持平台：Win/iOS/Android/Mac</p>
<a href="paysuccess.php?gb=<?php echo $id; ?>" class="btn btn-default btn-block" onclick="if(!confirm('确认购买?')){return false;}">立即购买</a>
</div>
</div>

</div>
  <?php } ?>
</div>
</div>


<div class="tab-pane" id="t-card">

                <form id="form_pay" action="moneysuccess.php" method="POST">
                    <div id="popup-captcha"></div>
                    
<div class="col-md-8">
                    <div class="input-group">
                        <span class="input-group-addon">卡密</span>
                        <input type="text" class="form-control" name="paynum" id="card_number" value="">
                        <span class="input-group-btn">
                            <button id="popup-pay" class="btn btn-primary" type="submit">充值</button>
                        </span>
                    </div>
</div>
                </form>
                <br/><br/>
				
				<br/>
				
			
			
			
			
			
			
			
			
				
             <b>卡密充值教程：</b><br/><br/>
                <div class="panel panel-default">
                    <div class="panel-heading" onclick="$('#howtobuy').fadeToggle();"><h3 class="panel-title"><span
                                class="glyphicon glyphicon-chevron-down"></span> 购买地址</h3></div>
                    <div class="panel-body" id="howtobuy">
                        1.<a href="<?php 


$res=mysql_query("SELECT * FROM lyj_link WHERE name LIKE '%卡密%';",$con);
$row = mysql_fetch_array($res);
$url=$row["url"];
echo $url;









						?>" target="_blank">点击此处购买卡密</a><br/><br/>
                        2.得到卡密在上方充值即可<br/><br/>
						3.购买多少钱的卡密，即充值多少金额
						 
                    </div>
                </div>
                <br/>
                <div class="panel panel-default">
                    <div class="panel-heading" onclick="$('#howtopay').fadeToggle();"><h3 class="panel-title"><span
                                class="glyphicon glyphicon-chevron-down"></span> 如何充值</h3></div>
                    <div class="panel-body" id="howtopay" style="display:none">
                        1.得到卡密在上方充值即可。
                    </div>
                </div>
            </div>
			
			<link rel="stylesheet" href="css/payway.css">
			
			<script type="text/javascript">
    
     function alipay()
	 {
		 $("#txtbanktype").val("alipay");
	 }
	 function weixin()
	 {
		 $("#txtbanktype").val("WEIXINWAP");
	 }
	 function tenpay()
	 {
		 $("#txtbanktype").val("TENPAYWAP");
	 }
	 function qq()
	 {
		 $("#txtbanktype").val("QQWAP");
	 }
	 
	 
</script>
			<div class="tab-pane" id="alipay">

               <div class="box box-product">

			   
			   
			   <div class="panel" id="expensehome">
<div class="panel-body">
<form id="regform" name="f" method="post" target="_blank" action="../bank/pay.php" onsubmit="return checkpayform('#txtbanktype','#paymoney','#pay-submit')">
<input style="display: none" type="text" name="paytype" id="txtbanktype" />
<div class="tab-content" style="padding: 12px 12px">
<div class="tab-pane active pay-list">
<div class="row">
<div class="form-group">
<div class="col-sm-12 mb40">
 <div class="form-group">
    <label>请输入数额:</label>
    <input type="text" class="form-control" name="total_fee" placeholder="请输入数额">
  </div>
</div>
</div>
</div>
<div class="row">
<div class="col-md-3">
<a href="#" class="shortcut-tile tile-white">
<div class="tile-body">
<div class="icon-default icon-ali" channel="ALIPAY" onclick="alipay()"></div>
</div>
</a>
</div>
<div class="col-md-3">
<a href="#" class="shortcut-tile tile-white">
<div class="tile-body">
<div class="icon-default icon-wx" channel="WEIXIN" onclick="weixin()"></div>
</div>
</a>
</div>
<div class="col-md-3">
<a href="#" class="shortcut-tile tile-white">
<div class="tile-body">
<div class="icon-default icon-ten" channel="TENPAY" onclick="tenpay()"></div>
</div>
</a>
</div>
<div class="col-md-3">
<a href="#" class="shortcut-tile tile-white">
<div class="tile-body">
<div class="icon-default icon-qq" channel="QQ" onclick="qq()"></div>
</div>
</a>
</div>
</div>
</div>
<input name="txtordernumber" type="hidden" ID="txtordernumber" value="<?php echo date("YmdHis")?>" >
<input name="khuser" type="hidden" ID="id" value="<?php echo $_SESSION["username"];?>" >
<br>
<button type="submit" class="btn btn-lg btn-primary-alt btn-label pull-right"><i class="fa fa-cny"></i><span style="margin-left:-16px">支付订单</span></button>
</div>
</form>
</div>
</div>
            </div>
			
			
</div>
</div>
</div>
</div>
<br>
<!-- footer.php -->
					<?php include_once('footer.php');   ?>
					<!-- footer.php -->
        </div>
      </div>
    </div>
<!-- /Switcher -->
<!-- Load site level scripts -->
<script type="text/javascript" src="css/prettify.js"></script> 				<!-- Code Prettifier  -->
<script type="text/javascript" src="css/bootstrap-switch.js"></script> 		<!-- Swith/Toggle Button -->
<script type="text/javascript" src="css/bootstrap-tabdrop.js"></script>  <!-- Bootstrap Tabdrop -->
<script type="text/javascript" src="css/jquery.sparklines.min.js"></script><!-- Sparkline -->

<script type="text/javascript" src="css/icheck.min.js"></script>     					<!-- iCheck -->
<script type="text/javascript" src="css/enquire.min.js"></script> 									<!-- Enquire for Responsiveness -->
<script type="text/javascript" src="css/bootbox.js"></script>							<!-- Bootbox -->
<script type="text/javascript" src="css/jquery.nanoscroller.min.js"></script> <!-- nano scroller -->
<script type="text/javascript" src="css/jquery.mousewheel.min.js"></script> 	<!-- Mousewheel support needed for jScrollPane -->
<script type="text/javascript" src="css/application.js"></script>
<script type="text/javascript" src="css/demo.js"></script>
<!-- End loading site level scripts -->
	<!-- Load page level scripts-->
	<script type="text/javascript" src="css/jquery.sparklines.min.js"></script>  		<!-- Sparkline -->
	<script src="css/jquery.flot.min.js"></script>             <!-- Flot Main File -->
	<script src="css/jquery.flot.resize.js"></script>          <!-- Flot Responsive -->
	<script src="css/jquery.flot.tooltip.min.js"></script>    <!-- Flot Tooltips -->
	<!-- End loading page level scripts-->
	<script type="text/javascript" src="css/expense.js"></script>
	<script type="text/javascript" src="css/index.js"></script> 										<!-- Initialize scripts for this page-->
	
 <?php 