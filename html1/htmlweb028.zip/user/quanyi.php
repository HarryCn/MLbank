<?php
@eval("//Encode by phpjiami.com,VIP user."); ?>
<!-- top.php -->
<?php include_once('top.php');   ?>

<!-- top.php -->
<!-- head.php -->
<?php include_once('head.php');   ?>
<!-- head.php -->
        <div class="static-content-wrapper">
         <div class="static-content">
            <div class="page-content">
              <div class="container-fluid">
                <div style="height:16px"></div>
<div class="page-tabs" id="page-tabs">
  <ul class="nav nav-tabs">
    <li class="">
      <a href="userindex.php" aria-expanded="true">基本资料</a></li>
    <li class="">
      <a href="safeset.php?mod=set&secure" aria-expanded="false">安全设置</a></li>
      <li class="">
      <a href="setinfo.php" aria-expanded="false">修改密码</a></li>


    <li class="">
      <a href="index.php?mod=set&rights" aria-expanded="false">会员权益</a></li>
  </ul>
</div>
<div class="media">
  <a class="pull-left" href="#" style="margin-right:12px">
    <img class="media-object" src="images/default_family.jpg"></a>
  <div class="media-body">
    
    <h2>VIP&nbsp;1&nbsp;<a href="#" style="font-size:14px;display:inline-block">说明</a></h2>
    <p>经验值：0&nbsp;&nbsp;|&nbsp;&nbsp;升级还需要：500</p>
    <div class="progress progress-striped active">
    <div class="progress-bar progress-bar-info" style="width: 0%"></div></div>
      </div>
</div>
<p>&nbsp;</p>
<div class="row">
  <div class="col-sm-4">
    <div class="tile-sparkline">
      <div class="tile-sparkline-heading clearfix">
        <div class="pull-left">
          <h2 class="block">Exp</h2>
          <span class="tile-sparkline-subheading block">会员成长包含6个会员等级，会员等级由"经验值"决定，经验值越高，会员等级越高。</span></span class="block">
        </div>
        <div class="pull-right">
          <span class="label label-success">VIP&nbsp;1</span></div>
      </div>
      <div class="tile-sparkline-body">
        <div id="tiles-sparkline-stats-pageviews"></div>
        <div class="tabular">
          <div class="tabular-row">
            <div class="tabular-cell">
              <div class="week-day sun">VIP 1</div></div>
            <div class="tabular-cell">
              <div class="week-day mon">VIP 2</div></div>
            <div class="tabular-cell">
              <div class="week-day tue">VIP 3</div></div>
            <div class="tabular-cell">
              <div class="week-day wed">VIP 4</div></div>
            <div class="tabular-cell">
              <div class="week-day thu">VIP 5</div></div>
            <div class="tabular-cell">
              <div class="week-day fri">VIP 6</div></div>
          </div>
        </div>
      </div>
    </div>
  </div>



						</div>
            </div>
          </div>


					<br>
					<!-- footer.php -->
					<?php include_once('footer.php');   ?>
					<!-- footer.php -->
        </div>
      </div>
    </div>
<!-- /Switcher -->
<!-- Load site level scripts -->
<script type="text/javascript" src="css/prettify.js"></script> 				<!-- Code Prettifier  -->
<script type="text/javascript" src="css/bootstrap-switch.js"></script> 		<!-- Swith/Toggle Button -->
<script type="text/javascript" src="css/bootstrap-tabdrop.js"></script>  <!-- Bootstrap Tabdrop -->
<script type="text/javascript" src="css/jquery.sparklines.min.js"></script><!-- Sparkline -->

<script type="text/javascript" src="css/icheck.min.js"></script>     					<!-- iCheck -->
<script type="text/javascript" src="css/enquire.min.js"></script> 									<!-- Enquire for Responsiveness -->
<script type="text/javascript" src="css/bootbox.js"></script>							<!-- Bootbox -->
<script type="text/javascript" src="css/jquery.nanoscroller.min.js"></script> <!-- nano scroller -->
<script type="text/javascript" src="css/jquery.mousewheel.min.js"></script> 	<!-- Mousewheel support needed for jScrollPane -->
<script type="text/javascript" src="css/application.js"></script>
<script type="text/javascript" src="css/demo.js"></script>
<!-- End loading site level scripts -->
	<!-- Load page level scripts-->
	<script type="text/javascript" src="css/jquery.sparklines.min.js"></script>  		<!-- Sparkline -->
	<script src="css/jquery.flot.min.js"></script>             <!-- Flot Main File -->
	<script src="css/jquery.flot.resize.js"></script>          <!-- Flot Responsive -->
	<script src="css/jquery.flot.tooltip.min.js"></script>    <!-- Flot Tooltips -->
	<!-- End loading page level scripts-->
	<script type="text/javascript" src="css/index.js"></script> 										<!-- Initialize scripts for this page-->
	<script type="text/javascript">
		jQuery(document).ready(function() {
						loadsign('614391');
					});
	</script><?php 