﻿
<?php
session_start();
include_once('smtp.class.php');
include_once('../config.php'); 
mysql_query("SET NAMES UTF8");
mysql_select_db($db,$con);
$iuser=$_POST['user'];
$pd=$_POST['pass'];
$email =$_POST['to_user'];
$phone = $_POST['phone'];
$yz = $_POST['vcode'];
$firstname = $_POST['yaoqingren'];
$regtime = time(); 
$token_exptime = time()+60*60*24;
$yz2=$_SESSION["token"];
$web=mysql_query("SELECT * FROM website;",$con);
$webrow = mysql_fetch_array($web);
$issmtp=$webrow["issmtp"];


if($issmtp==1){
	$yz=1;
	$yz2=1;
}else{
	$yz=1;
	$yz2=1;
}

function isusername($str) {
 if (preg_match('/^[a-zA-Z0-9\._]+$/',$str)){
  return true;
 }else {
  return false;
 }
}

if($iuser=='' || $pd=='' || $email==''){  
echo "<script language=javascript>alert('各项资料都不能为空！');history.back();</script>"; 
 exit;

}

else if(isusername($iuser)){
  
  
  
  
  
$query = mysql_query("select username from user where username='$iuser'"); 

$queryema = mysql_query("SELECT email FROM user WHERE email='$email';");

$num = mysql_num_rows($query); 
$num2 = mysql_num_rows($queryema); 

if($num==1){ 
    echo "<script language=javascript>alert('用户名已存在，请重新输入');history.back();</script>"; 
    exit; 
}else if(!$num2==0){

 echo "<script language=javascript>alert('邮箱已被注册！请重新输入');history.back();</script>"; 
    exit; 




}
 else if($yz==$yz2){
	  


 if(empty($firstname)){
	 
	 $re=mysql_query("INSERT INTO user(username,password,active,note,quota_cycle,quota_bytes,phone,email,token,token_exptime,regtime,firstlogin) VALUES('$iuser','$pd','0','流量用户','1','0','$phone','$email','$token','$token_exptime','$regtime',0)");
 
	 
 }else{
	 $re=mysql_query("INSERT INTO user(username,password,active,note,quota_cycle,quota_bytes,phone,email,token,token_exptime,regtime,firstuser,firstlogin) VALUES('$iuser','$pd','0','流量用户','1','0','$phone','$email','$token','$token_exptime','$regtime','$firstname',0)");
 
	 
 }
 
 
 
 

if($re){ 
	
     $msg = "<script language=javascript>alert('注册成功，请返回登录！');location.href='index.php';</script>";     
	 echo $msg;
     session_start();
     $_SESSION = array();
     if (isset($_COOKIE[session_name()])) {
        setcookie(session_name(), '', time()-42000, '/');
     }
     session_destroy();
    }
else{
	 $msg = "<script language=javascript>alert('注册失败！请联系管理员！');history.back();</script>";
	 echo $msg;
     session_start();
     $_SESSION = array();
     if (isset($_COOKIE[session_name()])) {
        setcookie(session_name(), '', time()-42000, '/');
     }
     session_destroy();
	 
}
	
 

} 
  
  else{
	 echo("<script language=javascript>alert('验证码错误');history.back();</script>");
	 exit();
  }
  
  
  
  
  
  }

else
{  

 echo("<script language=javascript>alert('不能使用中文注册用户名！');history.back();</script>");
   exit();

 



}

?>