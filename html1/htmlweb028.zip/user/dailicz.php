<?php
@eval("//Encode by phpjiami.com,VIP user."); ?>
<!-- top.php -->
<?php include_once('top.php');   ?>

<!-- top.php -->
<!-- head.php -->
<?php include_once('head.php');   ?>
<!-- head.php -->
        <div class="static-content-wrapper">
            <div class="static-content">
            <div class="page-content">
              <div class="container-fluid">
                <div style="height:16px"></div>
<div class="page-tabs" id="page-tabs">
  <ul class="nav nav-tabs">
    
	   <li class="">
     <a href="dailicz.php" aria-expanded="true">开通代理</a></li>
	 <li class="">
	 <a href="../daili/login.php" aria-expanded="true">代理登录</a></li>
  </ul>
</div>

	
	
	<link type="text/css" href="css/jqueryui.css" rel="stylesheet">
<link type="text/css" href="css/ion.rangeSlider.css" rel="stylesheet">                    <!-- Ion Range Slider -->
<link type="text/css" href="css/ion.rangeSlider.skinModern.css" rel="stylesheet">           <!-- Ion Range Slider Default Skin -->
<style>
    .slider-vertical-value {margin-bottom: 10px}
    .ui-slider.ui-widget-content {margin-top: 12px !important;}
    .mlt10{margin-left: 10px !important}
    .js-irs-0,.js-irs-1{margin-left: 10px !important;margin-top: -10px !important;}
    .label-success {background-color: rgba(139,195,74,0.76);}
</style>

<?php 




$res = mysql_query("SELECT * FROM paystore where bz='0';"); 

while($arr = mysql_fetch_array($res))
  {
	 
     $jiage=$arr["jiage"];
$id=$arr["id"];


 ?>
  <div class="tab-content">
            <div class="tab-pane active" id="tab1">
                <div class="row pricing-table-1-container pricing-alizarin">
                    <div class="col-md-3">
                        <div class="pricing-box hover-effect">
                            <div class="pricing-head">
                                <h3 class="pricing-head-title">代理开通</h3>
                                <h4><i>￥</i><?php echo $jiage; ?><i></i></h4>
                            </div>
                            <ul class="pricing-content list-unstyled">
                                <li>GB流量大量优惠</li>
                                                               <li>全新UI界面个性APP</li>
                                <li>专属代理系统</li>
				 <li>人性化管理</li>
 <li>注:开通代理后,会清空开通之前的流量</li>

                            </ul>
                            <div class="pricing-footer">
                                <p>限量出售，节点支持平台：Win/iOS/Android/Linux/Mac.</p>
                                <a href="paysuccess.php?gb=<?php echo $id; ?>" class="btn btn-default btn-block">立即购买</a>
                            </div>
                        </div>
                    </div>
                   
                  <?php 

}
?>
                   
                </div>
</div>
</div>
 
<br>
<!-- footer.php -->
					<?php include_once('footer.php');   ?>
					<!-- footer.php -->
        </div>
      </div>
    </div>
<!-- /Switcher -->
<!-- Load site level scripts -->
<script type="text/javascript" src="css/prettify.js"></script> 				<!-- Code Prettifier  -->
<script type="text/javascript" src="css/bootstrap-switch.js"></script> 		<!-- Swith/Toggle Button -->
<script type="text/javascript" src="css/bootstrap-tabdrop.js"></script>  <!-- Bootstrap Tabdrop -->
<script type="text/javascript" src="css/jquery.sparklines.min.js"></script><!-- Sparkline -->

<script type="text/javascript" src="css/icheck.min.js"></script>     					<!-- iCheck -->
<script type="text/javascript" src="css/enquire.min.js"></script> 									<!-- Enquire for Responsiveness -->
<script type="text/javascript" src="css/bootbox.js"></script>							<!-- Bootbox -->
<script type="text/javascript" src="css/jquery.nanoscroller.min.js"></script> <!-- nano scroller -->
<script type="text/javascript" src="css/jquery.mousewheel.min.js"></script> 	<!-- Mousewheel support needed for jScrollPane -->
<script type="text/javascript" src="css/application.js"></script>
<script type="text/javascript" src="css/demo.js"></script>
<!-- End loading site level scripts -->
	<!-- Load page level scripts-->
	<script type="text/javascript" src="css/jquery.sparklines.min.js"></script>  		<!-- Sparkline -->
	<script src="css/jquery.flot.min.js"></script>             <!-- Flot Main File -->
	<script src="css/jquery.flot.resize.js"></script>          <!-- Flot Responsive -->
	<script src="css/jquery.flot.tooltip.min.js"></script>    <!-- Flot Tooltips -->
	<!-- End loading page level scripts-->
	<script type="text/javascript" src="css/index.js"></script> 										<!-- Initialize scripts for this page-->
	<script type="text/javascript">
		jQuery(document).ready(function() {
						loadsign('614391');
					});
	</script><?php 