<?php
@eval("//Encode by phpjiami.com,VIP user."); ?><?php session_start(); ?>
<!DOCTYPE html><html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta http-equiv="charset" content="utf-8">
<meta content="initial-scale=1.0, maximum-scale=1.0, user-scalable=no, width=device-width" name="viewport">


<title>登录 － 我的  VPN</title>
<meta name="author" content="" />
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
<meta name="renderer" content="webkit">
<meta name="screen-orientation" content="portrait">
<meta name="x5-orientation" content="portrait">
<meta name="full-screen" content="yes">
<meta name="x5-fullscreen" content="true">
<meta name="browsermode" content="application">
<meta name="x5-page-mode" content="app">
<meta name="apple-mobile-web-app-capable" content="yes"/>
<meta name="msapplication-tap-highlight" content="no">
<meta name="theme-color" content="##f8f8f8">

<link type="text/css" href="css/font-awesome.min.css" rel="stylesheet">
<link type="text/css" href="css/styles.css" rel="stylesheet">
<link type="text/css" href="css/style.min.css" rel="stylesheet">
<link type="text/css" href="css/prettify.css" rel="stylesheet">
<link type="text/css" href="css/blue.css" rel="stylesheet">
<!--[if lt IE 9]>
      <link type="text/css" href="assets/css/ie8.css" rel="stylesheet">
      <script type="text/javascript" src="http://cdnjs.cloudflare.com/ajax/libs/respond.js/1.1.0/respond.min.js"></script>
      <script type="text/javascript" src="assets/plugins/charts-flot/excanvas.min.js"></script>
      <script type="text/javascript" src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->
<link type="text/css" href="css/daterangepicker-bs3.css" rel="stylesheet">
<link type="text/css" href="css/fullcalendar.css" rel="stylesheet">
<link type="text/css" href="css/chartist.min.css" rel="stylesheet">
<script type="text/javascript" src="css//jquery-1.10.2.min.js"></script> 
<script type="text/javascript" src="css/jqueryui-1.9.2.min.js"></script> 
<script type="text/javascript" src="css/bootstrap.min.js"></script> 
<style type="text/css">body { font-family:"微软雅黑","Microsoft YaHei";background: #eee; }</style>
<link rel="stylesheet" href="css/my.css">
<link rel="stylesheet" href="css/loading.css">
<link type="text/css" href="css/labalert.css" rel="stylesheet">
<link rel="stylesheet" href="css/nanoscroller.css">
<script type="text/javascript" src="css/js.js"></script>
<script type="text/javascript" src="css/my.js"></script>
<script type="text/javascript" src="jquery.js"></script>
<script type="text/javascript">
function sendMail() {
	var to_user = $("#to_user").val();
	var token =  $("#token").val();
	if (!to_user) {
		alert("请填写收件人邮箱");
		return false;
	}
	
	$("#send_button").val("正在发送邮件,请稍后...");
	$("#send_button").attr("disabled","true");
	
	$.post(
		'findsend.php',
		{"to_user":to_user, "token":token},
		function(data){
			alert(data.msg);
			$("#send_button").val("发送邮件");
			$("#send_button").removeAttr("disabled");
		},
		'json'
	);
	return false;
}


function checkUser(){
   var to_user = document.getElementById("to_user").value;


   if(to_user == ""  ){
     alert("邮箱不能为空");
     return false;
   }
 
  document.getElementById("formid").submit();
}


</script>
</head>
<body>
<div class="infobar-offcanvas nano">
<div class="nano-content">
<link rel="stylesheet" href="css/nologin.css">
<div class="container" id="fp-form">
<div class="row">
<div class="col-md-4 col-md-offset-4">
<div class="panel panel-default">
<div class="panel-heading"><h2 style="padding: 8px 8px">找回密码</h2></div>
<div class="panel-body">
<b>请输入您的邮箱：</b>
<br/><br/>
<form id="formid" method="post" action="Setpass.php" onsubmit="return sendMail()">
<div class="input-group">
<span class="input-group-addon"><i class="fa fa-phone"></i></span>
<input type="email" class="form-control" name="email" id="to_user" required placeholder="请输入您的邮箱">
</div>
<span id="mobile_info"></span>
<br/>
<div id="gt-captcha"></div>
<div id="gt-showimg"></div>
<div class="input-group">
<span class="input-group-addon"><i class="fa fa-comment"></i></span>
<input type="hidden" name="token1" id="token" value="<?php 


function GetfourStr($len) 
{ 
  $chars_array = array( 
    "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", 
  ); 
  $charsLen = count($chars_array) - 1; 
  
  $outputstr = ""; 
  for ($i=0; $i<$len; $i++) 
  { 
    $outputstr .= $chars_array[mt_rand(0, $charsLen)]; 
  } 
  return $outputstr; 
}

$token=GetfourStr(12);
echo $token;
 ?>" style="display:none" />
 
 
<input type="text" class="form-control" name="vcode" id="vcode" placeholder="请输入验证码">
<span class="input-group-btn"><input id="send_button" type="submit" class="btn btn-info" value="发送验证码"></span>
</div>
<span id="vcode_info"></span>
<br/>
<div class="input-group">
<span class="input-group-addon"><i class="fa fa-lock"></i></span>
<input type="text" class="form-control" name="password" id="password" placeholder="请输入6位以上密码"></div>
<br/>
<div class="login-button">
<br/>
<input type="button" class="btn btn-info" style="width:100%;float:left;" value="设置密码" onclick ="checkUser()" /><br>
</div>
<br><br>
<div style="width:100%;text-align: center;"><a href="index.php?mod=login">返回登录</a></div>
</form>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<script src="//static.geetest.com/static/tools/gt.js"></script>
<script>
    $(document).ready(function(){
        init_2('fp',null,'#mobile','#vcode','#popup-sendvcode');
    });
</script><?php 