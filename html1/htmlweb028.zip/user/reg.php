<?php 
include_once('../phpcode.php');
header("Content-type: text/html; charset=utf-8"); 
include_once('../config.php');  
mysql_query("SET NAMES UTF8");
mysql_select_db($db,$con);
$web=mysql_query("SELECT * FROM website;",$con);
$webrow = mysql_fetch_array($web);
$issmtp=$webrow["issmtp"];


 ?>
<!DOCTYPE html><html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta http-equiv="charset" content="utf-8">
<meta content="initial-scale=1.0, maximum-scale=1.0, user-scalable=no, width=device-width" name="viewport">


<title>注册 － 我的  VPN</title>
<meta name="author" content="" />
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
<meta name="renderer" content="webkit">
<meta name="screen-orientation" content="portrait">
<meta name="x5-orientation" content="portrait">
<meta name="full-screen" content="yes">
<meta name="x5-fullscreen" content="true">
<meta name="browsermode" content="application">
<meta name="x5-page-mode" content="app">
<meta name="apple-mobile-web-app-capable" content="yes"/>
<meta name="msapplication-tap-highlight" content="no">
<meta name="theme-color" content="##f8f8f8">

<link type="text/css" href="css/font-awesome.min.css" rel="stylesheet">
<link type="text/css" href="css/styles.css" rel="stylesheet">
<link type="text/css" href="css/style.min.css" rel="stylesheet">
<link type="text/css" href="css/prettify.css" rel="stylesheet">
<link type="text/css" href="css/blue.css" rel="stylesheet">
<!--[if lt IE 9]>
      <link type="text/css" href="assets/css/ie8.css" rel="stylesheet">
      <script type="text/javascript" src="http://cdnjs.cloudflare.com/ajax/libs/respond.js/1.1.0/respond.min.js"></script>
      <script type="text/javascript" src="assets/plugins/charts-flot/excanvas.min.js"></script>
      <script type="text/javascript" src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->
<link type="text/css" href="css/daterangepicker-bs3.css" rel="stylesheet">
<link type="text/css" href="css/fullcalendar.css" rel="stylesheet">
<link type="text/css" href="css/chartist.min.css" rel="stylesheet">
<script type="text/javascript" src="css//jquery-1.10.2.min.js"></script> 
<script type="text/javascript" src="css/jqueryui-1.9.2.min.js"></script> 
<script type="text/javascript" src="css/bootstrap.min.js"></script> 
<style type="text/css">body { font-family:"微软雅黑","Microsoft YaHei";background: #eee; }</style>
<link rel="stylesheet" href="css/my.css">
<link rel="stylesheet" href="css/loading.css">
<link type="text/css" href="css/labalert.css" rel="stylesheet">
<link rel="stylesheet" href="css/nanoscroller.css">
<script type="text/javascript" src="css/js.js"></script>
<script type="text/javascript" src="css/my.js"></script>
<script type="text/javascript" src="jquery.js"></script>
</head>
<body oncontextmenu="return false" ondragstart="return false" onselectstart="return false">

<script type="text/javascript">
function sendMail() {
	var to_user = $("#to_user").val();
	var token =  $("#token").val();
	if (!to_user) {
		alert("请填写收件人邮箱");
		return false;
	}
	
	$("#send_button").val("正在发送邮件,请稍后...");
	$("#send_button").attr("disabled","true");
	
	$.post(
		'mailsend.php',
		{"to_user":to_user, "token":token},
		function(data){
			alert(data.msg);
			$("#send_button").val("发送邮件");
			$("#send_button").removeAttr("disabled");
		},
		'json'
	);
	return false;
}

function checkUser(){
   var to_user = document.getElementById("to_user").value;


   if(to_user == ""  ){
     alert("邮箱不能为空");
     return false;
   }
 
  document.getElementById("formid").submit();
}

</script>

<div class="infobar-offcanvas nano">
<div class="nano-content">
<link rel="stylesheet" href="css/nologin.css">
<div class="container" id="reg-form">
<div class="row">
<div class="col-md-4 col-md-offset-4">
<div class="panel panel-default">
<div class="panel-heading"><h2 style="padding: 8px 8px">注册</h2></div>
<div class="panel-body">
请填写您的注册信息
<br/>
<br/>

<form id="formid" method="post" action="regs.php" onsubmit="return sendMail()">
<div class="input-group">
<span class="input-group-addon"><i class="fa fa-user"></i></span>
<input type="text" name="smtp" id="smtp" value="smtp.163.com" style="display:none" />

<input type="text" class="form-control" name="user" id="iuser" placeholder="请输入5位以上用户名">
</div>
<span id="username_info"></span>
<br/>
<div class="input-group">
<span class="input-group-addon"><i class="fa fa-envelope"></i></span>
<input type="email" class="form-control" name="to_user" id="to_user" placeholder="请输入您的邮箱" />
</div>
<span id="mobile_info"></span>

<div id="gt-captcha"></div>
<div id="gt-showimg"></div>
<?php 
session_start();
function GetfourStr($len) 
{ 
  $chars_array = array( 
    "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", 
  ); 
  $charsLen = count($chars_array) - 1; 
  
  $outputstr = ""; 
  for ($i=0; $i<$len; $i++) 
  { 
    $outputstr .= $chars_array[mt_rand(0, $charsLen)]; 
  } 
  return $outputstr; 
}

$token=GetfourStr(4);

$_SESSION["token"]=$token;

// if($issmtp==1){

// echo "<br/><div class='input-group'>
// <span class='input-group-addon'><i class='fa fa-comment'></i></span>
// <input type='hidden' name='token1' id='token' value='$token' style='display:none' />
// <input type='text' class='form-control' name='vcode' id='vcode' placeholder='请输入验证码'>
// <span class='input-group-btn'><input id='send_button' type='submit' class='btn btn-info' value='发送验证码'></span>
// </div>";	

// }
 ?>


<span id="vcode_info"></span>
<br/>
<div class="input-group">
<span class="input-group-addon"><i class="fa fa-lock"></i></span>
<input type="password" class="form-control" name="pass" id="pass" placeholder="请输入6位以上密码"></div>
<br/>
<div class="input-group">
<span class="input-group-addon"><i class="fa fa-user"></i></span>
<?php 
			$yaoqingren=$_GET["id"];
if(empty($yaoqingren))
{
	echo " <input type='text' name='yaoqingren' class='form-control' placeholder='邀请人(有则填,无则免)' value='' />";
}
else{
	echo " <input type='text' name='yaoqingren' class='form-control' placeholder='邀请人(有则填,无则免)' value='$yaoqingren' readonly='readonly' />";
}

			?>
</div>

<br/>
<div class="checkbox icheck">
<label for=""><input type="checkbox" class="form-control" id="readtos"/>我已经阅读并且同意<a onclick="msg_tof()">《服务条款》</a></label>
</div>
<div class="login-button">
<br/>
<input type="button" class="btn btn-info" style="width:100%;float:left;" value="继续注册" onclick ="checkUser()" />

</div><br><br>
<div style="width:100%;text-align: center;"><a href="index.php">已注册？直接登录</a></div>
</form>



</div>
</div>
</div>
</div>
</div>
</div>
</div>