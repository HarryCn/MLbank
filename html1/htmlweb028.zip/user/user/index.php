<?php 
$u = $_GET['user'];
$p = $_GET['pass'];
header("Content-type: text/html; charset=utf-8"); 
include_once('../../config.php');  
include_once('../../phpcode.php'); 
mysql_query("SET NAMES UTF8");
mysql_select_db($db,$con);

$res=mysql_query("SELECT * FROM user where username='$u' AND password='$p'",$con);
$num1 = mysql_num_rows($res); 
$rows = mysql_fetch_array($res);
$firstuser=$rows["firstuser"];
$quota_bytes=$rows["quota_bytes"];

if(!$num1){
	exit("<script language='javascript'>alert('用户名或密码不正确！');history.go(-1);</script>");
}

if($_POST['km']){
	$km = $_POST['km'];
	
	
	$kmres=mysql_query("SELECT * FROM paynum WHERE num ='$km';",$con);
	$source = mysql_fetch_array($kmres);
	$numleixing=$source["numleixing"];
	$num=$source["num"];
	$i=$source["i"];
	$date1=date("YmdHis");
	
	
	if(!empty($num) && $i==="0"){

		
		
switch($numleixing)
        {
			case 0:
			$fanli=$flbfb*10;
              $sql1=mysql_query("UPDATE user SET money=money+5 WHERE username='$u';");
			  $firstsql=mysql_query("UPDATE user SET money=money+'$fanli' WHERE username='$firstuser';");
			if(empty($firstuser)){

}else{
			  $firstinfo=mysql_query("insert into paylog(pid,moneylog,beizhu,users) values('$date1','$fanli','返利用户:$u','$firstuser');");
}
			  $logcha=mysql_query("insert into paylog(pid,moneylog,beizhu,users) values('$date1','5','卡密充值','$u');");
              break;
			
            case 1:
			   $fanli=$flbfb*10;
              $sql1=mysql_query("UPDATE user SET money=money+10 WHERE username='$u';");
			  $firstsql=mysql_query("UPDATE user SET money=money+'$fanli' WHERE username='$firstuser';");
			if(empty($firstuser)){

}else{
			  $firstinfo=mysql_query("insert into paylog(pid,moneylog,beizhu,users) values('$date1','$fanli','返利用户:$u','$firstuser');");
}
			  $logcha=mysql_query("insert into paylog(pid,moneylog,beizhu,users) values('$date1','10','卡密充值','$u');");
              break;
			  case 2:
			  $fanli=$flbfb*20;
             $sql1=mysql_query("UPDATE user SET money=money+20 WHERE username='$u';");
			 $firstsql=mysql_query("UPDATE user SET money=money+'$fanli' WHERE username='$firstuser';");
if(empty($firstuser)){

}else{

			 $firstinfo=mysql_query("insert into paylog(pid,moneylog,beizhu,users) values('$date1','$fanli','返利用户:$u','$firstuser');");
}
			 $logcha=mysql_query("insert into paylog(pid,moneylog,beizhu,users) values('$date1','20','卡密充值','$u');");
              break;
			  case 3:
			  $fanli=$flbfb*30;
             $sql1=mysql_query("UPDATE user SET money=money+30 WHERE username='$u';");
			 $firstsql=mysql_query("UPDATE user SET money=money+'$fanli' WHERE username='$firstuser';");
if(empty($firstuser)){

}else{

			 $firstinfo=mysql_query("insert into paylog(pid,moneylog,beizhu,users) values('$date1','$fanli','返利用户:$u','$firstuser');");
}
			 $logcha=mysql_query("insert into paylog(pid,moneylog,beizhu,users) values('$date1','30','卡密充值','$u');");
              break;
			  case 4:
			  $fanli=$flbfb*50;
             $sql1=mysql_query("UPDATE user SET money=money+50 WHERE username='$u';");
			 $firstsql=mysql_query("UPDATE user SET money=money+'$fanli' WHERE username='$firstuser';");
if(empty($firstuser)){

}else{

			 $firstinfo=mysql_query("insert into paylog(pid,moneylog,beizhu,users) values('$date1','$fanli','返利用户:$u','$firstuser');");
}
			 $logcha=mysql_query("insert into paylog(pid,moneylog,beizhu,users) values('$date1','50','卡密充值','$u');");
              break;
			  case 5:
			  $fanli=$flbfb*100;
             $sql1=mysql_query("UPDATE user SET money=money+100 WHERE username='$u';");
			 $firstsql=mysql_query("UPDATE user SET money=money+'$fanli' WHERE username='$firstuser';");
if(empty($firstuser)){

}else{

			 $firstinfo=mysql_query("insert into paylog(pid,moneylog,beizhu,users) values('$date1','$fanli','返利用户:$u','$firstuser');");
}
			$logcha=mysql_query("insert into paylog(pid,moneylog,beizhu,users) values('$date1','100','卡密充值','$u');");
              break;
		}
		
	}else{
		
		
		
		
		
		
		
		
		
$llres=mysql_query("SELECT * FROM llpaynum WHERE num ='$km';",$con);
$llsource = mysql_fetch_array($llres);
$llvalue1=$llsource["llvalue"];
$num=$llsource["num"];
$i=$llsource["i"];
$lltian=$llsource["lltian"];
$date1=date("YmdHis");
if($llvalue1>"40960"){$note="包月用户";}else{$note="流量用户";}
$llvalue=$llvalue1*1024*1024;
		$date2=date("Y-m-d H:i:s");
		if(empty($num) || $i!=="0"){exit("<script language='javascript'>alert('卡密错误');history.go(-1);</script>");}
		if($i==="0"){
		
	
$delect_used = mysql_query("UPDATE user SET quota_cycle=0,use_cycle=0,surplus_cycle=0,quota_bytes=0,used_quota=0,left_quota=0 WHERE username='$u';");
$deletlog = mysql_query("delete from log where username='$u';");
$updatecreation = mysql_query("UPDATE user SET creation='$date2' WHERE username='$u';");
$llinfo = mysql_query("insert into paylog(pid,moneylog,beizhu,users) values('$date1','$num','卡密流量充值$llvalue1 M $lltian 天','$u');", $con);
$jhinfo = mysql_query("UPDATE user SET active=1 WHERE username='$u';");
$sql1 = mysql_query("UPDATE user SET active=1,quota_bytes='$llvalue',left_quota='$llvalue',quota_cycle='$lltian',surplus_cycle='$lltian',firstlogin=0 WHERE username='$u';");
$sqlva=mysql_query("UPDATE user SET note='$note' WHERE username='$u';");

		}
		
		
		
		
		
		
		
		
		
		
		} 
		
		
		if($sql1){
						$dele=mysql_query("update paynum set i='$u' where num='$km';",$con);
						$lldele=mysql_query("update llpaynum set i='$u' where num='$km';",$con);
						exit("<script language='javascript'>alert('充值成功！');history.go(-1);</script>");

		
		
		}else{
			exit("<script language='javascript'>alert('卡密错误');history.go(-1);</script>");
		
		}
		
		}
		
		
		else{
			exit("<script language='javascript'>alert('充值失常！');history.go(-1);</script>");
		}
 ?>