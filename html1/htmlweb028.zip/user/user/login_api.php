<?php
@eval("//Encode by  phpjiami.com,Free user."); ?><?php

session_start();
header("Content-type: text/html; charset=utf-8"); 
include_once('../../config.php');  
mysql_query("SET NAMES UTF8");
mysql_select_db($db,$con);

$u =$_GET['user'];

$p =$_GET['pass'];

$res=mysql_query("SELECT * FROM user where username='$u' AND password='$p'",$con);
$rows = mysql_fetch_array($res);
$num = mysql_num_rows($res);  

if($num){
	
	echo "<p>账号:".$rows['username'];

echo "</p><p>已用:".round($rows['used_quota']/1024/1024);

echo "MB</p><p>已发:".round($rows['used_quota']/1024/1024);

echo "MB</p><p>总量:".round($rows['quota_bytes']/1024/1024);

echo "MB</p><p>剩余:".round($rows['left_quota']/1024/1024);

echo "MB</p><p>注册时间:".$rows['creation'];

//echo "</p><p>到期时间:".$rows['creation'];

echo "</p><p>剩余天数:".$rows['surplus_cycle'];

echo "      ";
	
	

}else
{
echo '密码错误';
exit;
}
?>

<?php 