<?php


header("Content-type: text/html; charset=utf-8"); 
include_once('../../config.php');  
include_once('../../phpcode.php'); 
mysql_query("SET NAMES UTF8");
mysql_select_db($db,$con);
$user=$_POST['user'];
$pass=$_POST['pass'];
$verifycode=$_POST['verifycode'];
function isusername($str) {
 if (preg_match('/^[a-zA-Z0-9\._]+$/',$str)){
  return true;
 }else {
  return false;
 }
}

if($user=='' || $pass==''){  

 exit("各项资料都不能为空");

}
else if(isusername($user)){
	
	
$query = mysql_query("SELECT * FROM user where username='$user';",$con); 
$num = mysql_num_rows($query);
if($num=='1')
{
	exit("用户存在')");
}
	else{
	$re=mysql_query("INSERT INTO user(username,password,active,note,quota_cycle,quota_bytes,firstlogin) VALUES('$user','$pass','0','流量用户','1','0','0');");
	
	}

}



if($re){
		
		
	exit("注册成功！')");
		
	}
	else{
	exit("注册失败')");

	}
?>