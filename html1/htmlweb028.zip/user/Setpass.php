<?php
@eval("//Encode by phpjiami.com,VIP user."); ?><?php
session_start();
include_once('../config.php');
include_once('../phpcode.php');
 mysql_query("SET NAMES UTF8");
 mysql_select_db($db,$con);
$email=$_POST["email"];
$posttoken=$_POST["vcode"];
$password=$_POST["password"];
$nowtime = time();
$res=mysql_query("SELECT * FROM user WHERE email = '$email';",$con);
$rows = mysql_fetch_array($res);
$token=$rows["token"];
$token_exptime=$rows["token_exptime"];

if($posttoken==$token && $token_exptime>$nowtime)
{
	
$query = mysql_query("update user set password='$password' where email='$email'",$con);

if($query)
{
	 
	echo "<script language=javascript>alert('修改成功,请返回登陆');history.back();</script>";
	$query = mysql_query("update user set token='$nowtime' where email='$email'",$con);

	
}else{
	
	echo "<script language=javascript>alert('修改失败,请刷新网页后重试！');history.back();</script>";
	
}


}
else{
	
	echo "<script language=javascript>alert('验证码错误或已失效!');history.back();</script>";
	
}

     
?><?php 