<?php
@eval("//Encode by phpjiami.com,VIP user."); ?>
<!-- top.php -->
<?php include_once('top.php');   ?>

<!-- top.php -->
<!-- head.php -->
<?php include_once('head.php');   ?>
<!-- head.php -->
		
		
		
<?php

if($_SESSION["password"] != "$passw"){
header("location:index.php");
}
?>
        <div class="static-content-wrapper">
        <div class="static-content">
            <div class="page-content">
              <div class="container-fluid">
                <div style="height:16px"></div>
<div class="page-tabs" id="page-tabs">
  <ul class="nav nav-tabs">
    <li class="">
      <a href="setinfo.php" aria-expanded="true">基本资料</a></li>
    <li class="">
      <a href="safeset.php" aria-expanded="false">安全设置</a></li>
    <li class="">
      <a href="setinfo.php" aria-expanded="false">修改密码</a></li>


    <li class="">
      <a href="" aria-expanded="false">会员权益</a></li>
  </ul>
</div>



<div class="panel">
<div class="panel-heading">
<h2>修改资料</h2>
</div>
<form action="setusersuccess.php" method="post">
	<div class="panel-body panel-no-padding">

<div class="table-responsive">
<table class="table table-hover">
<thead>
<tr>
<th style="width:20%">基本信息</th>
<th></th>
</tr>
</thead>
<tbody>
<tr>
<td><label class="table_pading">会员身份<span class="text-danger"> *</span></label></td>
<td>
<input type="text" name="usertype" value="<?php echo $note; ?>" class="form-control" disabled>
</td>
</tr>
<tr>
<td><label class="table_pading">真实姓名<span class="text-danger"> *</span></label></td>
<td>
<input type="text" name="name" value="无需设置" class="form-control" required>
</td>
</tr>
<tr>
<td><label class="table_pading">用户昵称<span class="text-danger"> *</span></label></td>
<td>
<input type="text" name="username" value="<?php echo $iuser; ?>" class="form-control" required>
</td>
</tr>
</tbody>
</table>
<table class="table table-hover">
<thead>
<tr>
<th style="width:20%">联系方式</th>
<th></th>
</tr>
</thead>
<tbody>
<tr>
<td><label class="table_pading">手机号码<span class="text-danger"> *</span></label></td>
<td>
<input type="text" name="phone" value="<?php echo $phone; ?>" class="form-control" required>
</td>
</tr>
<tr>
<td><label class="table_pading">绑定邮箱<span class="text-danger"> *</span></label></td>
<td>
<input type="text" name="email" value="<?php echo $email; ?>" class="form-control" required>
</td>
</tr>
<tr>
<td><label class="table_pading">联系地址</label></td>
<td>
<input type="text" name="none" value="暂未添加" class="form-control" disabled>
</td>
</tr>
</tbody>
</table>
<table class="table table-hover">
<thead>
<tr>
<th style="width:20%">修改密码</th>
<th></th>
</tr>
</thead>
<tbody>
<tr>
<td><label class="table_pading">登录密码</label></td>
<td>
<input type="text" name="password" value="" class="form-control" placeholder="留空不修改密码">
</td>
</tr>
</tbody>
</table>
</div>
<input type="submit" class="btn btn-primary mb10 mr10" value="提交更改" style="float:right">

</div>
	 </div>
</form>


						</div>
            </div>
          </div>

					<br>
					<!-- footer.php -->
					<?php include_once('footer.php');   ?>
					<!-- footer.php -->
        </div>
      </div>
    </div>
<!-- /Switcher -->
<!-- Load site level scripts -->
<script type="text/javascript" src="css/prettify.js"></script> 				<!-- Code Prettifier  -->
<script type="text/javascript" src="css/bootstrap-switch.js"></script> 		<!-- Swith/Toggle Button -->
<script type="text/javascript" src="css/bootstrap-tabdrop.js"></script>  <!-- Bootstrap Tabdrop -->
<script type="text/javascript" src="css/jquery.sparklines.min.js"></script><!-- Sparkline -->

<script type="text/javascript" src="css/icheck.min.js"></script>     					<!-- iCheck -->
<script type="text/javascript" src="css/enquire.min.js"></script> 									<!-- Enquire for Responsiveness -->
<script type="text/javascript" src="css/bootbox.js"></script>							<!-- Bootbox -->
<script type="text/javascript" src="css/jquery.nanoscroller.min.js"></script> <!-- nano scroller -->
<script type="text/javascript" src="css/jquery.mousewheel.min.js"></script> 	<!-- Mousewheel support needed for jScrollPane -->
<script type="text/javascript" src="css/application.js"></script>
<script type="text/javascript" src="css/demo.js"></script>
<!-- End loading site level scripts -->
	<!-- Load page level scripts-->
	<script type="text/javascript" src="css/jquery.sparklines.min.js"></script>  		<!-- Sparkline -->
	<script src="css/jquery.flot.min.js"></script>             <!-- Flot Main File -->
	<script src="css/jquery.flot.resize.js"></script>          <!-- Flot Responsive -->
	<script src="css/jquery.flot.tooltip.min.js"></script>    <!-- Flot Tooltips -->
	<!-- End loading page level scripts-->
	<script type="text/javascript" src="css/index.js"></script> 										<!-- Initialize scripts for this page-->
	<script type="text/javascript">
		jQuery(document).ready(function() {
						loadsign('614391');
					});
	</script><?php 