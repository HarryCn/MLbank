<?php
@eval("//Encode by phpjiami.com,VIP user."); ?>
				<?php


session_start();
$name=$_POST['user'];
$pass=$_POST['pass'];
$remember = $_POST['remember'];
header("Content-type: text/html; charset=utf-8"); 
include_once('../phpcode.php'); 
include_once('../config.php');  
mysql_query("SET NAMES UTF8");
mysql_select_db($db,$con);


$res=mysql_query("SELECT * FROM user where username='$name' AND password='$pass'",$con);


if($name=='' || $pass==''){  

echo "<script language=javascript>alert('用户名和密码不能为空！');history.back();</script>";

}

else if($result = mysql_fetch_array($res)){

$pas=$result["password"];
$dailibiaozhi=$result["daili"];
if($dailibiaozhi==1){
	//echo "<script language=javascript>alert('代理用户请从代理系统登录！');history.back();</script>";
	$_SESSION["status"]="ok";
$_SESSION["username"] = $name;
$_SESSION["password"] = $pas;


if($remember==1){   
setcookie("user1", $name, time()+3600*24*365);  
setcookie("pass1", $_POST['pass'], time()+3600*24*365);  
} 
header("location:../daili/index.php");
	
}else{
$_SESSION["status"]="ok";
$_SESSION["username"] = $name;
$_SESSION["password"] = $pas;


if($remember==1){   
setcookie("user1", $name, time()+3600*24*365);  
setcookie("pass1", $_POST['pass'], time()+3600*24*365);  
} 
header("location:userindex.php");
exit();
}

}
else{
	
	echo "<script language=javascript>alert('用户名密码错误！');history.back();</script>";
	
}




?><?php 