<?php
@eval("//Encode by phpjiami.com,VIP user."); ?>
<!-- top.php -->
<?php include_once('top.php');   ?>

<!-- top.php -->
<!-- head.php -->
<?php include_once('head.php');   ?>
<!-- head.php -->
        <div class="static-content-wrapper">
         <div class="static-content">
            <div class="page-content">
              <div class="container-fluid">
                <div style="height:16px"></div>
<div class="page-tabs" id="page-tabs">
  <ul class="nav nav-tabs">
    <li class="">
      <a href="yaoqing.php&new" aria-expanded="true">邀请好友</a></li>
    
  </ul>
</div>
<script type="text/javascript"> 
    function jsCopy(){ 
        var e=document.getElementById("inviteurl1");//对象是content 
        e.select(); //选择对象 
        document.execCommand("Copy"); //执行浏览器复制命令
       alert("复制完成,已可粘贴"); 
    } 
</script> 
<script type="text/javascript" src="css/ZeroClipboard.js"></script>

<div class="alert alert-info">您可以复制该地址发送给您的好友。并且在邀请人一栏填写你的用户名，即可享受以下福利！ <br><br>
<li>受邀者每次 充值任意金额,您将获得<b> 10% </b>提成奖励</li>
</div>

<div class="input-group">
	<span class="input-group-addon">地址</span>
	<input type="text" class="form-control" name="inviteurl" id="inviteurl1" value="<?php echo $_SERVER['HTTP_HOST']; ?>/user/reg.php?id=<?php echo $username; ?>">
	<span class="input-group-btn"  id="clip_container"><input type="submit" onclick="jsCopy()" class="btn btn-primary" id="clip_button1" value="复制"></span>
</div><br/>
<br/>
<script>
	function showqrcode(){
		alert('<img style="display: block;margin-left: 150px;" data-no-retina="" src="images/2wm.png"><br/>','分享二维码');
	}
	$(document).ready(function () {
		$("ul.nav-tabs li:eq(0)").addClass('active');//此时JQ未加载  第0个元素是自己设置的
	});
</script>

</body>
<script type="text/javaScript">
	function copy(t,b) {
		var clip = new ZeroClipboard.Client();
		clip.setHandCursor(true);
		clip.setText(document.getElementById(t).value);
		clip.addEventListener('complete',  function(client, text) {
			alert("该地址已经复制，你可以使用Ctrl+V 粘贴。");
		});
		clip.glue(b);
	}
</script>

						</div>
            </div>
          </div>



					<br>
						<!-- footer.php -->
					<?php include_once('footer.php');   ?>
					<!-- footer.php -->
        </div>
      </div>
    </div>
<!-- /Switcher -->
<!-- Load site level scripts -->
<script type="text/javascript" src="css/prettify.js"></script> 				<!-- Code Prettifier  -->
<script type="text/javascript" src="css/bootstrap-switch.js"></script> 		<!-- Swith/Toggle Button -->
<script type="text/javascript" src="css/bootstrap-tabdrop.js"></script>  <!-- Bootstrap Tabdrop -->
<script type="text/javascript" src="css/jquery.sparklines.min.js"></script><!-- Sparkline -->

<script type="text/javascript" src="css/icheck.min.js"></script>     					<!-- iCheck -->
<script type="text/javascript" src="css/enquire.min.js"></script> 									<!-- Enquire for Responsiveness -->
<script type="text/javascript" src="css/bootbox.js"></script>							<!-- Bootbox -->
<script type="text/javascript" src="css/jquery.nanoscroller.min.js"></script> <!-- nano scroller -->
<script type="text/javascript" src="css/jquery.mousewheel.min.js"></script> 	<!-- Mousewheel support needed for jScrollPane -->
<script type="text/javascript" src="css/application.js"></script>
<script type="text/javascript" src="css/demo.js"></script>
<!-- End loading site level scripts -->
	<!-- Load page level scripts-->
	<script type="text/javascript" src="css/jquery.sparklines.min.js"></script>  		<!-- Sparkline -->
	<script src="css/jquery.flot.min.js"></script>             <!-- Flot Main File -->
	<script src="css/jquery.flot.resize.js"></script>          <!-- Flot Responsive -->
	<script src="css/jquery.flot.tooltip.min.js"></script>    <!-- Flot Tooltips -->
	<!-- End loading page level scripts-->
	<script type="text/javascript" src="css/index.js"></script> 										<!-- Initialize scripts for this page-->
	<script type="text/javascript">
		jQuery(document).ready(function() {
						loadsign('614391');
					});
	</script><?php 