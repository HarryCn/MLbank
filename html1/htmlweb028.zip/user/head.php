<?php
@eval("//Encode by phpjiami.com,VIP user."); ?>
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
<meta name="renderer" content="webkit">
<meta name="screen-orientation" content="portrait">
<meta name="x5-orientation" content="portrait">
<meta name="full-screen" content="yes">
<meta name="x5-fullscreen" content="true">
<meta name="browsermode" content="application">
<meta name="x5-page-mode" content="app">
<meta name="apple-mobile-web-app-capable" content="yes"/>
<meta name="msapplication-tap-highlight" content="no">
<meta name="theme-color" content="##f8f8f8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">

<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">

<meta name="HandheldFriendly" content="true">

    <!--[if lt IE 10]>
      <script type="text/javascript" src="assets/js/media.match.min.js"></script>
      <script type="text/javascript" src="assets/js/placeholder.min.js"></script>
    <![endif]-->
	
 <link rel="shortcut icon" href="/favicon.ico" />
    <link type="text/css" href="css/font-awesome.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link type="text/css" href="css/styles.css" rel="stylesheet">
    <!-- Core CSS with all styles -->
    <link type="text/css" href="css/style.min.css" rel="stylesheet">
    <!-- jsTree -->
    <link type="text/css" href="css/prettify.css" rel="stylesheet">
    <!-- Code Prettifier -->
    <link type="text/css" href="css/blue.css" rel="stylesheet">
    <!-- iCheck -->
    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries. Placeholdr.js enables the placeholder attribute -->
    <!--[if lt IE 9]>
      <link type="text/css" href="assets/css/ie8.css" rel="stylesheet">
      <script type="text/javascript" src="http://cdnjs.cloudflare.com/ajax/libs/respond.js/1.1.0/respond.min.js"></script>
      <script type="text/javascript" src="assets/plugins/charts-flot/excanvas.min.js"></script>
      <script type="text/javascript" src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->
    <!-- The following CSS are included as plugins and can be removed if unused-->
    <link type="text/css" href="css/daterangepicker-bs3.css" rel="stylesheet">
    <!-- DateRangePicker -->
    <link type="text/css" href="css/fullcalendar.css" rel="stylesheet">
    <!-- FullCalendar -->
    <link type="text/css" href="css/chartist.min.css" rel="stylesheet">
    <!-- Chartist -->

<!--<script type="text/javascript" src="http://ossweb-img.qq.com/images/js/jquery/jquery-1.9.1.min.js"></script>-->
<script type="text/javascript" src="css/jquery.min.js"></script> 	
<script type="text/javascript" src="css/jquery-ui.min.js"></script> 							<!-- Load jQuery -->						<!-- Load jQueryUI -->
<script type="text/javascript" src="css/bootstrap.min.js"></script> 								<!-- Load Bootstrap -->
<!--<link rel="stylesheet" href="source/css/bootstrap.min.css">-->
<style type="text/css">body { font-family:"微软雅黑","Microsoft YaHei";background: #eee; }</style>

<link rel="stylesheet" href="css/ui.css">
<link rel="stylesheet" href="css/my.css">
<link type="text/css" href="css/labalert.css" rel="stylesheet">
<link rel="stylesheet" href="css/nanoscroller.css">
<script type="text/javascript" src="css/js.js"></script>
<script type="text/javascript" src="css/my.js"></script><!--globals也要修改-->
</head>
<body class="infobar-offcanvas nano" oncontextmenu="return false" ondragstart="return false" onselectstart="return false">


<?php


session_start();
$_SESSION['count']; // 注册Session变量Count  
isset($PHPSESSID)?session_id($PHPSESSID):$PHPSESSID = session_id();  
// 如果设置了$PHPSESSID，就将SessionID赋值为$PHPSESSID，否则生成SessionID 
$_SESSION['count']++; // 变量count加1  
setcookie('PHPSESSID', $PHPSESSID, time()+3156000); // 储存SessionID到Cookie中  
if($_SESSION["status"] != "ok"){
header("location:index.php");
exit("非法访问！");
}
if($_SESSION["username"] == "admin"){
header("location:index.php");
}
$user=$_POST["username_add"];
$pass=$_POST["password_add"];
$dailiname=$_SESSION["username"];
$iuser=$_SESSION["username"];
$username=$_SESSION["username"];
include_once('../phpcode.php');

header("Content-type: text/html; charset=utf-8"); 
include_once('../config.php');  
mysql_query("SET NAMES UTF8");
mysql_select_db($db,$con);
$count=mysql_query("SELECT COUNT(*) FROM user WHERE enabled = '1';",$con);
$count3=mysql_query("SELECT COUNT(*) FROM user;",$con);
$count4=mysql_query("SELECT COUNT(*) FROM user where dailiID='$username';",$con);
$res=mysql_query("SELECT * FROM user WHERE username = '$username';",$con);

$web=mysql_query("SELECT * FROM website;",$con);
$webrow = mysql_fetch_array($web);
$sitename=$webrow["sitename"];
$sitetitle=$webrow["sitetitle"];
$keywords=$webrow["keywords"];
$description=$webrow["description"];
$sitelogo=$webrow["sitelogo"];
$applogo1=$webrow["applogo1"];
$applogo2=$webrow["applogo2"];
$applogo3=$webrow["applogo3"];
$footgg=$webrow["footgg"];
$userqd=$webrow["userqd"];

$row = mysql_fetch_array($count);
$rowrenshu = mysql_fetch_array($count3);
$rowxiajishu = mysql_fetch_array($count4);
$people=$rowrenshu["COUNT(*)"];
$people2=$rowxiajishu["COUNT(*)"];
$rows = mysql_fetch_array($res);
$counts = $row["COUNT(*)"];
$create=$rows["creation"];
$lstimes=$rows["lstimes"];
$note=$rows["note"];
$dailibiaozhi=$rows["daili"];
$dailinum=$rows["dailiID"];
$quota_bytes=$rows["quota_bytes"];
$use_cycle=$rows["use_cycle"];
$sent=$rows["used_quota"];
$yy=$rows["use_cycle"];
$ss=$rows["ss"];
$firstuser=$rows["firstuser"];
$firstlogin=$rows["firstlogin"];
$passw=$rows["password"];
$phone=$rows["phone"];
$email=$rows["email"];
$money=$rows["money"];
$qdate=$rows["qdate"];
$dailiID=$rows["dailiID"];
$quota_cycle=$rows["quota_cycle"];
$recv=$rows["quota_bytes"];
$sent=$rows["used_quota"];
$syliuliang=$recv-$sent;
$reaa3=mysql_query("SELECT * FROM paylog WHERE users = '$username' ORDER BY times DESC;",$con);
$rowaws3 = mysql_fetch_array($reaa3);
$beizhu=$rowaws3["beizhu"];
$surplus_cycle=$quota_cycle-$use_cycle;
$_SESSION["dailiID"]=$dailinum;

 


  
?>

<div class ="nano-content">

	<div id="loading">
		<div id="loading-center">
			<div id="loading-center-absolute">
				<div class="object" id="object_one"></div>
				<div class="object" id="object_two"></div>
				<div class="object" id="object_three"></div>
				<div class="object" id="object_four"></div>
				<div class="object" id="object_five"></div>
				<div class="object" id="object_six"></div>
				<div class="object" id="object_seven"></div>
				<div class="object" id="object_eight"></div>
				<div class="object" id="object_big"></div>
			</div>
		</div>
	</div><!--NEW-->

    <div id="headerbar">
      <div class="container-fluid">
        <div class="row">
          <div class="col-xs-6 col-sm-2">
            <a href="pay.php" class="shortcut-tile tile-primary">
              <div class="tile-body">
                <div class="pull-left">
                  <i class="fa fa-usd"></i>
                </div>
              </div>
              <div class="tile-footer">账户充值</div></a>
          </div>
          <div class="col-xs-6 col-sm-2">
            <a href="pay.php" class="shortcut-tile tile-orange">
              <div class="tile-body">
                <div class="pull-left">
                  <i class="fa fa-shopping-cart "></i>
                </div>
              </div>
              <div class="tile-footer">流量购买</div></a>
          </div>
          <div class="col-xs-6 col-sm-2">
            <a href="index.php?mod=log&flow" class="shortcut-tile tile-grape">
              <div class="tile-body">
                <div class="pull-left">
                  <i class="fa fa-file-text-o"></i>
                </div>
                <div class="pull-right">
                  <span class="badge">2</span></div>
              </div>
              <div class="tile-footer">流量详单</div></a>
          </div>
          <div class="col-xs-6 col-sm-2">
            <a href="https://www.kf5.com" class="shortcut-tile tile-brown" target="_blank">
              <div class="tile-body">
                <div class="pull-left">
                  <i class="fa fa-pencil"></i>
                </div>
              </div>
              <div class="tile-footer">创建工单</div></a>
          </div>
          <div class="col-xs-6 col-sm-2">
            <a href="https://www.kf5.com" class="shortcut-tile tile-inverse" target="_blank">
              <div class="tile-body">
                <div class="pull-left">
                  <i class="fa fa-envelope-o"></i>
                </div>
                <div class="pull-right">
                  <span class="badge">3</span></div>
              </div>
              <div class="tile-footer">我的工单</div></a>
          </div>
          <div class="col-xs-6 col-sm-2">
            <a href="userindex.php" class="shortcut-tile tile-midnightblue">
              <div class="tile-body">
                <div class="pull-left">
                  <i class="fa fa-cog"></i>
                </div>
              </div>
              <div class="tile-footer">设置中心</div></a>
          </div>
        </div>
      </div>
    </div>
    <header id="topnav" class="navbar navbar-midnightblue navbar-static-top clearfix" role="banner"><!--navbar-fixed-top-->
      <span id="trigger-sidebar" class="toolbar-trigger toolbar-icon-bg">
        <a data-toggle="tooltips" data-placement="right" title="Toggle Sidebar">
          <span class="icon-bg">
            <i class="fa fa-fw fa-bars"></i>
          </span>
        </a>
      </span>
      <a class="navbar-brand" href="userindex.php"><span style="font-weight: lighter;"><?php echo $sitename; ?><span style="color: #FF6C60;font-weight: normal;">VPN</span></span></a>
      <span id="trigger-infobar" class="toolbar-trigger toolbar-icon-bg">
        <a data-toggle="tooltips" data-placement="left" title="Toggle Infobar">
        </a>
      </span>
      <div class="yamm navbar-left navbar-collapse collapse in">
        <ul class="nav navbar-nav">
          <li class="dropdown">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">产品与服务
              <span class="caret"></span></a>
            <ul class="dropdown-menu" style="width: 450px;">
              <li>
                <div class="yamm-content container-sm-height">
                  <div class="row row-sm-height yamm-col-bordered">
                    <div class="col-sm-6 col-sm-height yamm-col">
                      <h3 class="yamm-category">OpenVpn</h3>
                      <ul class="list-unstyled mb20">
                        <li>
                          <a href="#">北京BGP</a></li>
                        <li>
                          <a href="#">上海BGP</a></li>
                        <li>
                          <a href="#">杭州高防</a></li>
                        <li>
                          <a href="#">深圳高防</a></li>
                      </ul>
                      <h3 class="yamm-category">Shadowsocks</h3>
                      <ul class="list-unstyled">
                        <li>
                          <a href="#">CN2, Hong Kong</a></li>
                        <li>
                          <a href="#">NewWorld, Hong Kong</a></li>
                        <li>
                          <a href="#">Tokyo, Japan</a></li>
                        <li>
                          <a href="#">Los Angeles, USA</a></li>
                      </ul>
                    </div>
                    <div class="col-sm-6 col-sm-height yamm-col">
                      <h3 class="yamm-category">L2TP/IPSEC</h3>
                      <ul class="list-unstyled mb20">
                        <li>
                          <a href="#">CN2, Singapore</a></li>
                        <li>
                          <a href="#">London, UK </a></li>
                        <li>
                          <a href="#">Sydney, Australia </a></li>
                        <li>
                          <a href="#">Atlanta, USA </a></li>
                        <li>
                          <a href="#">Los Angeles, USA </a></li>
                      </ul>
                      <h3 class="yamm-category">More</h3>
                      <ul class="list-unstyled mb20">
                        <li>
                          <a href="#">Contact us </a></li>
                      </ul>
                    </div>
                  </div>
                </div>
              </li>
            </ul>
          </li>
          <li class="dropdown" id="widget-classicmenu">
<a href="#" class="dropdown-toggle" data-toggle="dropdown">客户端下载
<span class="caret"></span></a>
<ul class="dropdown-menu" style="width: 450px;">
<li>
<div class="yamm-content container-sm-height">
<div class="row row-sm-height yamm-col-bordered">
<div class="col-sm-6 col-sm-height yamm-col">
<h3 class="yamm-category">OpenVpn</h3>
<ul class="list-unstyled mb20">
<li>
<a href="down.php" target="blank">Cloud For Android</a></li>
<li>
<a href="http://firstdown.oss-cn-hangzhou.aliyuncs.com/openvpn/openvpn_old.apk" target="blank">Android (原版)</a></li>
<li>
<a href="https://itunes.apple.com/us/app/openvpn-connect/id590379981" target="blank">OpenVPN For iOS</a></li>
<li class="divider"></li>
<li>
<a href="javascript:alert('开发中!');">Windows</a></li>
<li>
<a href="http://flipwalls.oss-cn-shenzhen.aliyuncs.com/openvpn.clients/Tunnelblick_3.5.5_build_4270.4461.dmg" target="blank">OS X</a>
</li>
</ul>
</div>
<div class="col-sm-6 col-sm-height yamm-col">
<h3 class="yamm-category">ShadowSocks</h3>
<ul class="list-unstyled mb20">
<li>
<a href="http://firstdown.oss-cn-hangzhou.aliyuncs.com/openvpn/shadowsocks-nightly-2.8.3.apk" target="blank">ShadowSocksR For Android</a></li>
<li>
<a href="https://itunes.apple.com/us/app/shadowrocket-for-shadowsocks/id932747118" target="blank">Shadowrocket For iOS</a></li>
<li>
<a href="https://itunes.apple.com/cn/app/surge-web-developer-tool-proxy/id1040100637" target="blank">Surge For iOS</a></li>
<li>
<a href="http://firstdown.oss-cn-hangzhou.aliyuncs.com/openvpn/Surge-580.ipa" target="blank">Surge越狱版(afc2&appsync)</a></li>
<li class="divider"></li>
<li>
<a href="http://7xpn8p.com1.z0.glb.clouddn.com/ShadowsocksR-win-3.7.4.1.7z" target="blank">Windows</a></li>
<li>
<a href="https://github.com/shadowsocks/shadowsocks-iOS/releases/download/2.6.3/ShadowsocksX-2.6.3.dmg" target="blank">OS X</a></li>
<li class="divider"></li>
<li>
<a href="http://xinbiaoge.com/?id=10" target="blank">极路由插件</a></li>
</ul>
</div>
</div>
</div>
</li>
        </ul>
      </div>
      <ul class="nav navbar-nav toolbar pull-right">
        <li class="dropdown toolbar-icon-bg">
          <a href="#" id="navbar-links-toggle" data-toggle="collapse" data-target="header>.navbar-collapse">
            <span class="icon-bg">
              <i class="fa fa-fw fa-ellipsis-h"></i>
            </span>
          </a>
        </li>
        <li class="dropdown toolbar-icon-bg demo-search-hidden">
          <a href="#" class="dropdown-toggle tooltips" data-toggle="dropdown">
            <span class="icon-bg">
              <i class="fa fa-fw fa-search"></i>
            </span>
          </a>
          <div class="dropdown-menu dropdown-alternate arrow search dropdown-menu-form">
            <div class="dd-header">
              <span>Search</span>
              <span>
                <a href="#">Advanced search</a></span>
            </div>
            <div class="input-group">
              <input type="text" class="form-control" placeholder="">
              <span class="input-group-btn">
                <a class="btn btn-primary" href="#">Search</a></span>
            </div>
          </div>
        </li>
        <li class="toolbar-icon-bg demo-headerdrop-hidden">
          <a href="#" id="headerbardropdown">
            <span class="icon-bg">
              <i class="fa fa-fw fa-level-down"></i>
            </span>
            </i>
          </a>
        </li>
        <li class="toolbar-icon-bg hidden-xs" id="trigger-fullscreen">
          <a href="#" class="toggle-fullscreen">
            <span class="icon-bg">
              <i class="fa fa-fw fa-arrows-alt"></i>
            </span>
            </i>
          </a>
        </li>
        <li class="dropdown toolbar-icon-bg">
          <a href="#" class="hasnotifications dropdown-toggle" data-toggle='dropdown'>
            <span class="icon-bg">
              <i class="fa fa-fw fa-bell"></i>
            </span>
            <span class="badge badge-info">4</span></a>
          <div class="dropdown-menu dropdown-alternate notifications arrow">
            <div class="dd-header">
              <span>消息通知</span>
              <span>
                <a href="#">Settings</a></span>
            </div>
            <div class="scrollthis scroll-pane">
              <ul class="scroll-content">
                <li class="">
                  <a href="#" class="notification-success">
                    <div class="notification-icon">
                      <i class="fa fa-user fa-fw"></i>
                    </div>
                    <div class="notification-content">充值方式更新完毕，发现问题欢迎反馈</div>
                  </a>
                </li>
                <li class="">
                  <a href="#" class="notification-info">
                    <div class="notification-icon">
                      <i class="fa fa-check fa-fw"></i>
                    </div>
                    <div class="notification-content">全新后台已升级完毕，流量情况一目了然</div>
                  </a>

                </li>
                <li class="">
                  <a href="#" class="notification-primary">
                    <div class="notification-icon">
                      <i class="fa fa-users fa-fw"></i>
                    </div>
                    <div class="notification-content">邀请好友奖励方式更新，提成功能全面开放</div>
                  </a>
                </li>
                <li class="">
                  <a href="#" class="notification-primary">
                    <div class="notification-icon">
                      <i class="fa fa-shopping-cart fa-fw"></i>
                    </div>
                    <div class="notification-content">新增深圳、上海高防节点，全面保障网络稳定性</div>
                  </a>
                </li>
              </ul>
            </div>
            <div class="dd-footer">
              <a href="#">查看所有</a></div>
          </div>
        </li>
        <li class="dropdown toolbar-icon-bg">
          <a href="#" class="dropdown-toggle" data-toggle='dropdown'>
            <span class="icon-bg">
              <i class="fa fa-fw fa-user"></i>
            </span>
          </a>
          <ul class="dropdown-menu userinfo arrow">
            <li>
              <a href="zhanghu.php">
                <span class="pull-left">账户总览</span>
                <i class="pull-right fa fa-user"></i>
              </a>
            </li>
            <li>
              <a href="userindex.php">
                <span class="pull-left">账号管理</span>
                <i class="pull-right fa fa-cog"></i>
              </a>
            </li>
            <li class="divider"></li>
            <li>
              <a href="index.php">
                <span class="pull-left">退出</span>
                <i class="pull-right fa fa-sign-out"></i>
              </a>
            </li>
          </ul>
        </li>
      </ul>
    </header>
    <div id="wrapper">
      <div id="layout-static">
        <div class="static-sidebar-wrapper sidebar-midnightblue">
          <div class="static-sidebar">
            <div class="sidebar">
              <div class="widget stay-on-collapse" id="widget-welcomebox">
                <div class="widget-body welcome-box tabular">
                  <div class="tabular-row">
                    <div class="tabular-cell welcome-avatar">
                      <a href="#">
                        <img src="images/default_family.jpg" class="avatar"></a>
                    </div>
                    <div class="tabular-cell welcome-options">
                      <span class="welcome-text">Hi,</span>
                      <a href="#" class="name"><?php echo $username; ?></a></div>
                  </div>
                </div>
              </div>
              <div class="widget stay-on-collapse" id="widget-sidebar">
                <nav role="navigation" class="widget-body">
                  <ul class="acc-menu">
                    <li class="nav-separator">Explore</li>
                    <li>
                      <a href="userindex.php">
                        <i class="fa fa-home"></i>
                        <span>控制台</span></a>
                    </li>
                    <li>
                      <a href="javascript:;">
                        <i class="fa fa-cogs"></i>
                        <span>账号管理</span></a>
                      <ul class="acc-menu">
                        <li>
                          <a href="setinfo.php">基本资料</a></li>
                        <li>
                          <a href="safeset.php">安全设置</a></li>
                        
                        <li>
                          <a href="quanyi.php">会员权益</a></li>
                      </ul>
                    </li>
                    <li>
                      <a href="javascript:;">
                        <i class="fa fa-usd"></i>
                        <span>费用中心</span>
                      </a>
                      <ul class="acc-menu">
                        <li>
                          <a href="zhanghu.php">账户总览</a></li>
                        
                        <li>
                          <a href="shouzhi.php">订单管理</a></li>
                        <li>
                          <a href="return.php">邀请奖励</a></li>
                      </ul></li>
                    </li>
                    <li>
                      <a href="pay.php">
                        <i class="fa fa-shopping-cart"></i>
                        <span>流量购买</span>
                        <span class="badge badge-primary">4</span>
                      </a>
                    </li>
					
                    <li class="nav-separator">MANAGE</li>
                          
                    <li>
                      <a href="javascript:;">
                        <i class="fa fa-file-text-o"></i>
                        <span>日志记录</span></a>
                      <ul class="acc-menu">
                        <li>
                          <a href="loginlog.php">登录记录</a></li>
                        
                      </ul>
                    </li>
                    <li>
                      <a href="javascript:;">
                        <i class="fa fa-pencil"></i>
                        <span>路线安装</span></a>
                      <ul class="acc-menu">
                        <li>
                          <a href="down.php" target="_blank">APP下载</a></li>
                        <li>
                          <a href="ios/" target="_blank">苹果路线安装</a></li>
                      </ul>
                    </li>
                    <li>
                      <a href="yaoqing.php">
                        <i class="fa fa-qrcode"></i>
                        <span>邀请好友</span></a>
                    </li>
                    <li>
                      <a href="dailicz.php">
                        <i class="fa fa-users"></i>
                        <span>代理中心</span></a>
                    </li>

                  </ul>
                </nav>
              </div>
            </div>
          </div>
        </div><?php 