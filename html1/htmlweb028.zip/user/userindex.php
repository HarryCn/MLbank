<?php
@eval("//Encode by phpjiami.com,VIP user."); ?>
<!-- top.php -->
<?php include_once('top.php');   ?>

<!-- top.php -->
<!-- head.php -->
<?php include_once('head.php');   ?>
<!-- head.php -->
        <div class="static-content-wrapper">
          <div class="static-content">
            <div class="page-content">
              <div class="container-fluid">
                <div style="height:16px"></div>
<!-- 引入封装了failback的接口--initGeetest -->

<div class="alert alert-inverse alert-dismissable">
	<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
	<span class="glyphicon glyphicon-bullhorn"></span>&nbsp;公告：<br/><br>

	<h3><?php echo file_get_contents("usergg.txt"); ?></h2><h3>
	</h2>
VPN运营团队
</div>
<div class="row">
	<div class="col-md-3">
		<div class="amazo-tile tile-white">
			<div class="tile-heading">
				<div class="title"><?php echo $username; ?></div>
				<div class="secondary"><a href="index.php?mod=set&rights" style="color: #a0d3ea" id="level_n">VIP 1</a></div></div>
			<div class="tile-body">
				<div class="content">
					<p style="width: 16px;height: 16px;background: #ebccd1;float:left;margin:14px 4px 0 0px" ></p><span style="font-weight: lighter">
					
					<?php 
		
		$activ=mysql_query("SELECT enabled FROM user WHERE username='$username';",$con);
		$activv = mysql_fetch_array($activ);
		$numm=$activv["enabled"];
		if($numm==1){
			echo "在线";
			
		}else{
			echo "离线";
		}
		
		?>
					
					</span>				</div></div>
			<div class="tile-footer">
				<span class="info-text text-left">
				<span style="font-weight:lighter">	
				
			IP:<?php 



$res9=mysql_query("SELECT * FROM log WHERE username='$username' ORDER BY start_time DESC LIMIT 0,10;",$con);

$arr4=mysql_fetch_array($res9);
 $ip=$arr4["trusted_ip"];

echo $ip;


?></span></b>				</span>
				<span class="info-text text-right"><a href="loginlog.php">登录记录</a></span>
				<div id="sparkline-revenue" class="sparkline-line"></div>
			</div>
		</div>
	</div>
	<div class="col-md-3">
		<div class="amazo-tile tile-white">
			<div class="tile-heading">
				<div class="title">账户余额</div>
				<div class="secondary"><a href="zhanghu.php" style="color: #a0d3ea">查看详情</a></div>
			</div>
			<div class="tile-body">
				<span class="content">￥<?php echo $money ?></span></div>
			<div class="tile-footer text-center">
				<span class="info-text text-left mr5" style="color: #94c355;">100% <i class="fa fa-level-up"></i></span>
				<span class="info-text text-right"><a href="pay.php">充值</a></span>
				<div class="progress" style="background: rgba(224, 224, 224, 0.29);height: 17px;margin:8px 10px 12px 10px">
					<div class="progress-bar" style="width: 0%;background: rgb(232, 232, 232);"></div>
				</div>
			</div>
		</div>
	</div>
	
	
	
	<div class="col-md-3">
		<div class="amazo-tile tile-white">
			<div class="tile-heading">
				<span class="title">账号等级</span>
				<span class="secondary">Vip</span></div>
			<div class="tile-body">
				<span class="content" id="flow_left">
				
				<?php

	 echo $note;

 ?>
				
				</span></div>
			<div class="tile-footer">
				<span class="info-text text-left" style="color: #94c355"><i class="fa fa-refresh"></i>
				账户所在级别范围</span>
				<span class="info-text text-right"><a href="pay.php">升级</a></span>
				<div id="sparkline-commission" class="sparkline"></div>
			</div>
		</div>
	</div>
	
	
	
	<div class="col-md-3">
		<div class="amazo-tile tile-white">
			<div class="tile-heading">
				<span class="title">剩余流量</span>
				<span class="secondary">of NO MB</span></div>
			<div class="tile-body">
				<span class="content" id="flow_left">
				
				<?php
if(is_numeric($dailiID)){
	
	 echo "<h>".round($syliuliang/1024/1024)."M</h>";
	
}
else{
	
if(round($syliuliang/1024/1024)>200000)
{
   echo '包月用户';

}else{

   echo "<h>".round($syliuliang/1024/1024)."M</h>";

}
}
 ?>
				
				</span></div>
			<div class="tile-footer">
				<span class="info-text text-left" style="color: #94c355"><i class="fa fa-refresh"></i>
				<?php	echo "已用".round($sent/1024/1024)."";	?>	M	</span>
				<span class="info-text text-right"><a href="pay.php">购买</a></span>
				<div id="sparkline-commission" class="sparkline"></div>
			</div>
		</div>
	</div>
	<div class="col-md-3">
		<div class="amazo-tile tile-white">
			<div class="tile-heading">
				<span class="title">剩余天数：</span>
				<span class="secondary">forever</span></div>
			<div class="tile-body">
				<span class="content"><?php 
				
				
				if($surplus_cycle<=0)
{
   echo '天数已到期，请充值使用';

}else{

   echo $surplus_cycle;

}
				
				
				 




				?></span></div>
			<div class="tile-footer">
				<span class="info-text text-left" style="color: #94c355"><i class="fa fa-level-up"></i>
					<?php echo "已用".$yy."天"; ?>
				</span>
				<span class="info-text text-right"><a href="pay.php">延期</a></span>
				<div id="sparkline-commission" class="sparkline"></div>
			</div>
		</div>
	</div>
	
	
	<div class="col-md-3">
		<div class="amazo-tile tile-white">
			<div class="tile-heading">
				<span class="title">代理中心</span>
				<span class="secondary">Daili</span></div>
			<div class="tile-body">
				<span class="content"><?php 
				
				
				if($dailibiaozhi==1)
{
	
  echo 'VIP代理用户';

}else{

   echo '未激活代理';

}
				
				
				 




				?></span></div>
			<div class="tile-footer">
				<span class="info-text text-left" style="color: #94c355"><i class="fa fa-level-up"></i>
					代理中心
				</span>
				<span class="info-text text-right"><a href="dailicz.php">充值代理</a></span>
				<div id="sparkline-commission" class="sparkline"></div>
			</div>
		</div>
	</div>
	
	<div class="col-md-3">
		<div class="amazo-tile tile-white">
			<div class="tile-heading">
				<span class="title">网站总人数</span>
				<span class="secondary">People</span></div>
			<div class="tile-body">
				<span class="content"><?php 
				
				
   echo $people;

		
				
				 




				?></span></div>
			<div class="tile-footer">
				<span class="info-text text-left" style="color: #94c355"><i class="fa fa-level-up"></i>
					Person
				</span>
				<span class="info-text text-right"><a href="userindex.php">主页</a></span>
				<div id="sparkline-commission" class="sparkline"></div>
			</div>
		</div>
	</div>
	
	
	
	<?php date_default_timezone_set("Asia/Shanghai");//地区?>
	<script type="text/javascript" language="javascript">
    window.onload = function () {
        stime();
    }
    var c = 0;
    var Y =<?php echo date('Y')?>, M =<?php echo date('n')?>, D =<?php echo date('j')?>;
    function stime() {
        c++
        sec = <?php echo time() - strtotime(date("Y-m-d"))?>+c;
        H = Math.floor(sec / 3600) % 24
        I = Math.floor(sec / 60) % 60
        S = sec % 60
        if (S < 10) S = '0' + S;
        if (I < 10) I = '0' + I;
        if (H < 10) H = '0' + H;
        if (H == '00' & I == '00' & S == '00') D = D + 1; //日进位
        if (M == 2) { //判断是否为二月份******
            if (Y % 4 == 0 && !Y % 100 == 0 || Y % 400 == 0) { //是闰年(二月有28天)
                if (D == 30) {
                    M += 1;
                    D = 1;
                } //月份进位
            }
            else { //非闰年(二月有29天)
                if (D == 29) {
                    M += 1;
                    D = 1;
                } //月份进位
            }
        }
        else { //不是二月份的月份******
            if (M == 4 || M == 6 || M == 9 || M == 11) { //小月(30天)
                if (D == 31) {
                    M += 1;
                    D = 1;
                } //月份进位
            }
            else { //大月(31天)
                if (D == 32) {
                    M += 1;
                    D = 1;
                } //月份进位
            }
        }
        if (M == 13) {
            Y += 1;
            M = 1;
        } //年份进位
        setTimeout("stime()", 1000);
        document.getElementById("nowTime").innerHTML = Y + '-' + M + '-' + D + ' ' + H + ':' + I + ':' + S
    }
</script>
	
	
	
	<div class="col-md-3">
		<div class="amazo-tile tile-white">
			<div class="tile-heading">
				<span class="title">北京时间</span>
				<span class="secondary">状态</span></div>
			<div class="tile-body">
				<span id="nowTime" class="content"> </span></div>
			<div class="tile-footer">
				<span class="info-text text-left" style="color: #94c355"><i class="fa fa-level-up"></i>
					Time
				</span>
				 
				<div id="sparkline-commission" class="sparkline"></div>
			</div>
		</div>
	</div>
	
	
	
</div>
<div class="row">
	<div class="col-md-12">
		<div class="panel panel-default">
			<div class="panel-heading">
				<h2 style="padding: 4px 2px">实时监控</h2>
			</div>
			<div class="panel-body">
			
			
			
				<div id="realtime-updates" style="height: 300px" class="centered"></div>

		
				
				
				
				
				
				
				
				
				
				
				
				</div>
				
		
		</div>
	</div>
</div>
<div class="panel panel-info">
	<div class="panel-heading">
		<h3 class="panel-title">赚流量</h3>
	</div>
	<div class="panel-body">
		<span id="avatar" style="float:right;"></span>
		<span id="tips" style="float:left;">每日签到赠送+ <font style="color:green"><?php echo $userqd; ?> </font>M流量，邀请好友更多丰富奖励！</span><br/>

					<div id="popup-captcha_sign"></div>
			<button id="popup-submit_sign" type="button" class="btn btn-info" style="float:left;margin-top:7px;" onclick="skip()">每日签到</button> <!--width:100%;!-->
				<button type="button" class="btn btn-info" style="float:left;margin:7px 0 0 10px;" onclick=" location ='yaoqing.php'">邀请好友</button>
				<script>
				
				function skip()
{
    window.location.href="qd.php";
}
				
				</script>
	</div>
</div>


						</div>
            </div>
          </div>
					<br>
					<!-- footer.php -->
					<?php include_once('footer.php');   ?>
					<!-- footer.php -->
        </div>
      </div>
    </div> 
<!-- /Switcher -->
<!-- Load site level scripts -->
<script type="text/javascript" src="css/prettify.js"></script> 				<!-- Code Prettifier  -->
<script type="text/javascript" src="css/bootstrap-switch.js"></script> 		<!-- Swith/Toggle Button -->
<script type="text/javascript" src="css/bootstrap-tabdrop.js"></script>  <!-- Bootstrap Tabdrop -->
<script type="text/javascript" src="css/jquery.sparkline.min.js"></script><!-- Sparkline -->

<script type="text/javascript" src="css/icheck.min.js"></script>     					<!-- iCheck -->
<script type="text/javascript" src="css/enquire.min.js"></script> 									<!-- Enquire for Responsiveness -->
<script type="text/javascript" src="css/bootbox.js"></script>							<!-- Bootbox -->
<script type="text/javascript" src="css/jquery.nanoscroller.min.js"></script> <!-- nano scroller -->
<script type="text/javascript" src="css/jquery.mousewheel.min.js"></script> 	<!-- Mousewheel support needed for jScrollPane -->
<script type="text/javascript" src="css/application.js"></script>
<script type="text/javascript" src="css/demo.js"></script>
<!-- End loading site level scripts -->
	<!-- Load page level scripts-->
	
	<script src="css/jquery.flot.min.js"></script>             <!-- Flot Main File -->
	<script src="css/jquery.flot.resize.js"></script>          <!-- Flot Responsive -->
	<script src="css/jquery.flot.tooltip.min.js"></script>    <!-- Flot Tooltips -->
	<!-- End loading page level scripts </script> 	 -->

	<script type="text/javascript" src="css/speed.js">										<!-- Initialize scripts for this page-->
	<script type="text/javascript">
		jQuery(document).ready(function() {
						loadsign('614391');
					});
	</script><?php 