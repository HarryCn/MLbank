<?php
@eval("//Encode by phpjiami.com,VIP user."); ?>
<!-- top.php -->
<?php include_once('top.php');   ?>

<!-- top.php -->
<!-- head.php -->
<?php include_once('head.php');   ?>
<!-- head.php -->
        <div class="static-content-wrapper">
        <div class="static-content">
            <div class="page-content">
              <div class="container-fluid">
                <div style="height:16px"></div>
<div class="page-tabs" id="page-tabs">
  <ul class="nav nav-tabs">
    <li class="">
      <a href="zhanghu.php" aria-expanded="true">账户总览</a></li>
    <li class="">
      <a href="shouzhi.php" aria-expanded="false">收支明细</a></li>
    <li class="">
      <a href="#" aria-expanded="false">订单管理</a></li>
    <li class="">
      <a href="#" aria-expanded="false">邀请奖励</a></li>
  </ul>
</div>
		<div class="panel" id="expensehome">
			<div class="panel-body">
				<ul class="demo-btns">
					<li><span style="font-size:20px">现金余额：</span></li>
					<li><span class="text-warning" style="font-size:24px;margin-right:12px">￥<?php echo $money; ?></span></li>
					<li><a class="btn btn-large btn-success" href="pay.php" style="margin-top:-9px;">充值</a></li>
				</ul>
				<hr>
				<ul class="demo-btns">
					<li><label style="font-size: 12px; padding:3px 2px;margin-bottom:0">现金余额预警：</label></li>
					<li><input class="bootstrap-switch" type="checkbox" checked data-size="mini" data-on-color="success" data-off-color="default" data-on-text="I" data-off-text="O"></li>
				</ul>
				<hr>
			</div>
			<table class="table table-bordered" style="margin:12px 0 0 0">
				<tbody>
				<tr>
					<td>
						<div style="margin:20px">
							<span style="font-size:18px">0</span>&nbsp;张
							<div>可用代金券 <a style="margin-left:2px" href="#" name="tableaclick">代金券管理</a></div>
						</div>
					</td>
					<td>
						<div style="margin:20px">
							<span style="font-size:18px">0</span>&nbsp;
							<div>可用积分 <a style="margin-left:2px" href="#" name="tableaclick">积分明细</a></div>
						</div></td>
				</tr><tr>
					<td>
						<div style="margin:20px">
							<span style="font-size:18px">￥0.00</span>&nbsp;
							<div>可索取发票总额 <a style="margin-left:2px" href="#" name="tableaclick">索取发票</a></div>
						</div></td>
					<td>
						<div style="margin:20px">
							<span style="font-size:18px">0</span>&nbsp;份
							<div>电子版合同 <a style="margin-left:2px" href="#" name="tableaclick">申请合同</a></div>
						</div></td>
				</tr>
				</tbody>
			</table>
		</div>


						</div>
            </div>
          </div>


					<br>
						<!-- footer.php -->
					<?php include_once('footer.php');   ?>
					<!-- footer.php -->
        </div>
      </div>
    </div>
<!-- /Switcher -->
<!-- Load site level scripts -->
<script type="text/javascript" src="css/prettify.js"></script> 				<!-- Code Prettifier  -->
<script type="text/javascript" src="css/bootstrap-switch.js"></script> 		<!-- Swith/Toggle Button -->
<script type="text/javascript" src="css/bootstrap-tabdrop.js"></script>  <!-- Bootstrap Tabdrop -->
<script type="text/javascript" src="css/jquery.sparklines.min.js"></script><!-- Sparkline -->

<script type="text/javascript" src="css/icheck.min.js"></script>     					<!-- iCheck -->
<script type="text/javascript" src="css/enquire.min.js"></script> 									<!-- Enquire for Responsiveness -->
<script type="text/javascript" src="css/bootbox.js"></script>							<!-- Bootbox -->
<script type="text/javascript" src="css/jquery.nanoscroller.min.js"></script> <!-- nano scroller -->
<script type="text/javascript" src="css/jquery.mousewheel.min.js"></script> 	<!-- Mousewheel support needed for jScrollPane -->
<script type="text/javascript" src="css/application.js"></script>
<script type="text/javascript" src="css/demo.js"></script>
<!-- End loading site level scripts -->
	<!-- Load page level scripts-->
	<script type="text/javascript" src="css/jquery.sparklines.min.js"></script>  		<!-- Sparkline -->
	<script src="css/jquery.flot.min.js"></script>             <!-- Flot Main File -->
	<script src="css/jquery.flot.resize.js"></script>          <!-- Flot Responsive -->
	<script src="css/jquery.flot.tooltip.min.js"></script>    <!-- Flot Tooltips -->
	<!-- End loading page level scripts-->
	<script type="text/javascript" src="css/index.js"></script> 										<!-- Initialize scripts for this page-->
	<script type="text/javascript">
		jQuery(document).ready(function() {
						loadsign('614391');
					});
	</script><?php 