﻿
				<?php


session_start();
$name=$_POST['user'];
$pass=$_POST['pass'];
$remember = $_POST['remember'];
header("Content-type: text/html; charset=utf-8"); 
include_once('../../config.php');  
mysql_query("SET NAMES UTF8");
mysql_select_db($db,$con);


$res=mysql_query("SELECT * FROM user where username='$name' AND password='$pass'",$con);


if($name=='' || $pass==''){  

echo "<script language=javascript>alert('用户名和密码不能为空！');history.back();</script>";

}

else if($result = mysql_fetch_array($res)){

$pas=$result["password"];
$dailibiaozhi=$result["daili"];


$_SESSION["status"]="ok";
$_SESSION["username"] = $name;
$_SESSION["password"] = $pas;

header("location:ios.php");
exit();



}
else{
	
	echo "<script language=javascript>alert('用户名密码错误！');history.back();</script>";
	
}




?>