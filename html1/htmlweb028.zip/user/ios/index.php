
<!DOCTYPE html><html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta http-equiv="charset" content="utf-8">
<meta content="initial-scale=1.0, maximum-scale=1.0, user-scalable=no, width=device-width" name="viewport">


<title>登录 － 我的  VPN</title>
<meta name="author" content="" />
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
<meta name="renderer" content="webkit">
<meta name="screen-orientation" content="portrait">
<meta name="x5-orientation" content="portrait">
<meta name="full-screen" content="yes">
<meta name="x5-fullscreen" content="true">
<meta name="browsermode" content="application">
<meta name="x5-page-mode" content="app">
<meta name="apple-mobile-web-app-capable" content="yes"/>
<meta name="msapplication-tap-highlight" content="no">
<meta name="theme-color" content="##f8f8f8">

<link type="text/css" href="../css/font-awesome.min.css" rel="stylesheet">
<link type="text/css" href="../css/styles.css" rel="stylesheet">
<link type="text/css" href="../css/style.min.css" rel="stylesheet">
<link type="text/css" href="../css/prettify.css" rel="stylesheet">
<link type="text/css" href="../css/blue.css" rel="stylesheet">
<!--[if lt IE 9]>
      <link type="text/css" href="assets/../css/ie8.css" rel="stylesheet">
      <script type="text/javascript" src="http://cdnjs.cloudflare.com/ajax/libs/respond.js/1.1.0/respond.min.js"></script>
      <script type="text/javascript" src="assets/plugins/charts-flot/excanvas.min.js"></script>
      <script type="text/javascript" src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->
<link type="text/css" href="../css/daterangepicker-bs3.css" rel="stylesheet">
<link type="text/css" href="../css/fullcalendar.css" rel="stylesheet">
<link type="text/css" href="../css/chartist.min.css" rel="stylesheet">
<script type="text/javascript" src="../css//jquery-1.10.2.min.js"></script> 
<script type="text/javascript" src="../css/jqueryui-1.9.2.min.js"></script> 
<script type="text/javascript" src="../css/bootstrap.min.js"></script> 
<style type="text/css">body { font-family:"微软雅黑","Microsoft YaHei";background: #eee; }</style>
<link rel="stylesheet" href="../css/my.css">
<link rel="stylesheet" href="../css/loading.css">
<link type="text/css" href="../css/labalert.css" rel="stylesheet">
<link rel="stylesheet" href="../css/nanoscroller.css">
<script type="text/javascript" src="../css/js.js"></script>
<script type="text/javascript" src="../css/my.js"></script>

</head>

<body oncontextmenu="return false">
<div class="infobar-offcanvas nano">
<div class="nano-content">
<link rel="stylesheet" href="../css/nologin.css">
<div class="container" id="login-form">
<div class="row">
<div class="col-md-4 col-md-offset-4">
<div class="panel panel-default">
<div class="panel-heading"><h2 style="padding: 8px 8px">登录</h2></div>
<div class="panel-body" style="text-align: center;">
自反而缩，虽千万人吾往矣<br/><br/>
<form id="loginform" method="post" action="loginSeccess.php" class="form-horizontal" id="validate-form">
<div class="form-group">
<div class="col-xs-12">
<div class="input-group">
<span class="input-group-addon">
<i class="fa fa-user"></i>
</span>
<input type="text" name="user" id="username" class="form-control" placeholder="用户名" data-parsley-minlength="5" required>
</div>
</div>
</div>
<div class="form-group">
<div class="col-xs-12">
<div class="input-group">
<span class="input-group-addon">
<i class="fa fa-key"></i>
</span>
<input type="password" name="pass" id="password" class="form-control" placeholder="您的密码">
</div>
</div>
</div>
<div class="form-group">
<div class="col-xs-12">
<a href="forget.php" class="pull-left">忘记密码?</a>
<div class="checkbox-inline icheck pull-right pt0">
<input type="checkbox" name="remember" value="1" />
</div>
</div>
</div>
<div class="panel-footer">
<div class="clearfix">
<a href="reg.php" class="btn btn-default pull-left">&nbsp;&nbsp;注册&nbsp;&nbsp;</a>
<button class="btn btn-primary pull-right">&nbsp;&nbsp;登陆&nbsp;&nbsp;</button>
</div>
</div>
<div id="popup-captcha"></div>
<input type="password" style="display: none" name="geetest_challenge" id="geetest_challenge">
<input type="password" style="display: none" name="geetest_validate" id="geetest_validate">
<input type="password" style="display: none" name="geetest_seccode" id="geetest_seccode">
</form>
</div>
</div>
</div>
</div>
</div>
</div></div>

