<?php 

session_start();
$_SESSION['count']; 
isset($PHPSESSID)?session_id($PHPSESSID):$PHPSESSID = session_id();  
$_SESSION['count']++;
setcookie('PHPSESSID', $PHPSESSID, time()+3156000); 
if(!isset($_SESSION["status"])){
header("location:index.php");
exit("非法访问！");
}

if($_SESSION["status"] != "ok"){
header("location:index.php");
exit("非法访问！");
}
$username=$_SESSION["username"];
include_once('../../phpcode.php');
header("Content-type: text/html; charset=utf-8"); 
include_once('../../config.php');  
mysql_query("SET NAMES UTF8");
mysql_select_db($db,$con);
$count=mysql_query("SELECT * FROM user WHERE username='$username';",$con);
$res = mysql_fetch_array($count);
$quota_bytes=$res["quota_bytes"];
$daili=$res["daili"];
if($quota_bytes>1073741824 or $daili==1){
	
	
	
}
else{
	exit("购买流量后才有权限查看此页面");
}
 ?>


<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>IOS配置安装引导页</title>
<link rel="stylesheet" href="../../user/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="../css/htmleaf-demo.css">
<style>
 

body, html { font-size: 100%; 	padding: 0; margin: 0;}
body{
	font-weight: 500;
	font-size: 1.05em;
	font-family: "Microsoft YaHei","宋体","Segoe UI", "Lucida Grande", Helvetica, Arial,sans-serif, FreeSans, Arimo;
}
a{color: #2fa0ec;text-decoration: none;outline: none;}
a:hover,a:focus{color:#74777b;}

.zzsc{
	margin: 0 auto;
	text-align: center;
	overflow: hidden;
}

</style>
</head>
<body oncontextmenu="return false" ondragstart="return false" onselectstart="return false">
<p>
	<div>
		<div style="text-align:center;">
			<!--下面是网页的置顶文字，可以改成自己的版权-->
			<strong><span style="font-size:14px;"></span>欢迎使用IOS配置在线安装</strong><br /><br /><strong style="color:red;"><span style="font-size:14px;color:red;"></span>请用苹果自带浏览器Safari打开此页面才能安装</strong><br /><br />
		</div>
 <table class="table table-striped table-bordered table-hover">
<!--下面是配置文件列表-->
<!--格式请如下面一行框内内容配置-->
<!--【配置文件名称 <a href="配置文件链接">&nbsp点击安装<br />】</a>-->
<p style="font-size: 50px;text-align: center;">移动</p><br />

<?php  



$res=mysql_query("SELECT * FROM lyj_article where category_id='1';",$con);


while($arr = mysql_fetch_array($res))
  {
  $articleid=$arr["id"];
  $title=$arr["title"];
 
 echo "<tr>";
echo "<td align='center' style='min-width:100px' valign='middle'>".$title."</td>";
echo "<td align='center' style='min-width:160px' valign='middle'><a href='ovpn/".$title.".ovpn'>&nbsp点击安装</a></td>";
echo "</tr>";


  
  
  
  
  }

?>







</table>



<p style="font-size: 50px;text-align: center;">联通</p><br />
<br />
 <table class="table table-striped table-bordered table-hover">

  <?php  



$res=mysql_query("SELECT * FROM lyj_article where category_id='2';",$con);


while($arr = mysql_fetch_array($res))
  {
  $articleid=$arr["id"];
  $title=$arr["title"];
 
 echo "<tr>";
echo "<td align='center' style='min-width:100px' valign='middle'>".$title."</td>";
echo "<td align='center' style='min-width:160px' valign='middle'><a href='ovpn/".$title.".ovpn'>&nbsp点击安装</a></td>";
echo "</tr>";


  
  
  
  
  }

?>
 
 
 </table>

 

<p style="font-size: 50px;text-align: center;">电信</p><br />
<br />

<table class="table table-striped table-bordered table-hover">

 <?php  



$res=mysql_query("SELECT * FROM lyj_article where category_id='3';",$con);


while($arr = mysql_fetch_array($res))
  {
  $articleid=$arr["id"];
  $title=$arr["title"];
 
 echo "<tr>";
echo "<td align='center' style='min-width:100px' valign='middle'>".$title."</td>";
echo "<td align='center' style='min-width:160px' valign='middle'><a href='ovpn/".$title.".ovpn'>&nbsp点击安装</a></td>";
echo "</tr>";


  
  
  
  
  }

?>

  
</table>





<!--上面是配置文件列表-->

</p>
</body>
</html>
