<?php
@eval("//Encode by phpjiami.com,VIP user."); ?>
<!-- top.php -->
<?php include_once('top.php');   ?>

<!-- top.php -->
<!-- head.php -->
<?php include_once('head.php');   ?>
<!-- head.php -->
        <div class="static-content-wrapper">
         <div class="static-content">
            <div class="page-content">
              <div class="container-fluid">
                <div style="height:16px"></div>
<div class="page-tabs" id="page-tabs">
  <ul class="nav nav-tabs">
    <li class="">
      <a href="loginlog.php" aria-expanded="true">登录记录</a></li>
    
  </ul>
</div>
<div class="panel"  id="expenseinexpense">
  <div class="panel-body">
    <form class="form-horizontal row-border" action="" method="post">
			<div class="form-group">
				<label class="col-sm-1 control-label" style="text-align:left;width:auto;padding-right:0">选择日期：</label>
						<div class="col-sm-3">
							<div class="input-daterange input-group" id="datepicker-range">
								<input type="text" class="form-control" name="start" value="注册日期"/>
								<span class="input-group-addon">到</span>
								<input type="text" class="form-control" name="end" value="至今"/>
							</div>
						</div>
        <div class="col-sm-3">
          <button type="submit"  class="btn  btn-default" >查询</button>
        </div>
			</div>
    </form>
		<table class="table table-striped">
			<thead>
			<th>登录时间</th>
			<th>登陆地点</th>
			</thead>
			
			
			
			
			<tbody>
			
			<?php

 $res3=mysql_query("SELECT * FROM log WHERE username='$iuser' ORDER BY start_time DESC LIMIT 0,10;",$con);


while($arr1 = mysql_fetch_array($res3)){
	
	
$time=$arr1["start_time"];
 $ip=$arr1["trusted_ip"];
 
   
echo "<tr>";
echo "<td>".$time."</td>";
echo "<td>".$ip."</td>";


echo "</tr>";
 
}
?>
			
			</tbody>
		</table>
		<!--	<br/><a href="javascript:scroll(0,0)">返回顶部</a>!-->
	  </div>
</div>


  
						</div>
            </div>
          </div>




					<br>
						<!-- footer.php -->
					<?php include_once('footer.php');   ?>
					<!-- footer.php -->
        </div>
      </div>
    </div>
<!-- /Switcher -->
<!-- Load site level scripts -->
<script type="text/javascript" src="css/prettify.js"></script> 				<!-- Code Prettifier  -->
<script type="text/javascript" src="css/bootstrap-switch.js"></script> 		<!-- Swith/Toggle Button -->
<script type="text/javascript" src="css/bootstrap-tabdrop.js"></script>  <!-- Bootstrap Tabdrop -->
<script type="text/javascript" src="css/jquery.sparklines.min.js"></script><!-- Sparkline -->

<script type="text/javascript" src="css/icheck.min.js"></script>     					<!-- iCheck -->
<script type="text/javascript" src="css/enquire.min.js"></script> 									<!-- Enquire for Responsiveness -->
<script type="text/javascript" src="css/bootbox.js"></script>							<!-- Bootbox -->
<script type="text/javascript" src="css/jquery.nanoscroller.min.js"></script> <!-- nano scroller -->
<script type="text/javascript" src="css/jquery.mousewheel.min.js"></script> 	<!-- Mousewheel support needed for jScrollPane -->
<script type="text/javascript" src="css/application.js"></script>
<script type="text/javascript" src="css/demo.js"></script>
<!-- End loading site level scripts -->
	<!-- Load page level scripts-->
	<script type="text/javascript" src="css/jquery.sparklines.min.js"></script>  		<!-- Sparkline -->
	<script src="css/jquery.flot.min.js"></script>             <!-- Flot Main File -->
	<script src="css/jquery.flot.resize.js"></script>          <!-- Flot Responsive -->
	<script src="css/jquery.flot.tooltip.min.js"></script>    <!-- Flot Tooltips -->
	<!-- End loading page level scripts-->
	<script type="text/javascript" src="css/index.js"></script> 										<!-- Initialize scripts for this page-->
	<script type="text/javascript">
		jQuery(document).ready(function() {
						loadsign('614391');
					});
	</script><?php 