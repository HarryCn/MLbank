<?php
$host="localhost";
$user="root";
$password="roottoor";
$db="openvpn";
$flbfb="0.1";//邀请好友返利参数百分百
$con = mysql_connect($host,$user,$password);
if (!$con)
  {
  die('Could not connect: ' . mysql_error());
  }
?>