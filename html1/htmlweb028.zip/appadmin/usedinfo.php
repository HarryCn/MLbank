
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<meta charset="utf-8"> 
<!-- 新 Bootstrap 核心 CSS 文件 -->
<link href="http://apps.bdimg.com/libs/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet">

<!-- 可选的Bootstrap主题文件（一般不使用） -->
<script src="http://apps.bdimg.com/libs/bootstrap/3.3.0/css/bootstrap-theme.min.css"></script>

<!-- jQuery文件。务必在bootstrap.min.js 之前引入 -->
<script src="http://apps.bdimg.com/libs/jquery/2.0.0/jquery.min.js"></script>

<!-- 最新的 Bootstrap 核心 JavaScript 文件 -->
<script src="http://apps.bdimg.com/libs/bootstrap/3.3.0/js/bootstrap.min.js"></script>
<title>HTML</title>
<style>
body,html{
	background:#efefef;
	padding:0px;
	margin:0px;
	overflow-x:hidden;
}
.main{
	margin:10px;
}
.list-group-item a{
	display:block;
}
.label-t{
	margin-bottom:20px;
}
.line{
	height:1px;
	background:#ccc;
}
.btn{
	border-radius: 0px;

}
</style></head>

<body>
<button type="button" onclick="javascript:history.back(-1);" class="btn btn-primary btn-lg btn-block">返回上一页</button>
<div style="background:#efefef;"> 	<div class="alert alert-success">可以查看近期每天的流量使用情况。每次断开后数据才会更新到此处哦！最多查看30天！</div>
		<style>.topline{
			border-bottom:1px solid #ccc;height:100px;;background-repeat:no-repeat;color:#333;
			background:#fff;
			margin-bottom:10px;
			}
		.topline h3{color:#222}
		.topn{font-size:30px;color:#222;float:left;line-height:100px;margin-left:15px;width:100px;}
		.topc{
			float:left;
			margin-top:10px;
			text-align:left;
		}
		</style><div style="text-align:center;padding:15px;">

</div>
</div>


 <table class="table table-striped">    
                    <thead>
                    <tr>
                      
                         
                     <th style="text-align:center;">登陆时间</th>
                        <th style="text-align:center;">断开时间</th>
                       <th style="text-align:center;">流量</th>
					   <th style="text-align:center;">协议</th>
                    </tr>
                    </thead>
                    <tbody>

<?php


session_start();
header("Content-type: text/html; charset=utf-8"); 
include_once('../phpcode.php'); 
include_once('../config.php');  
mysql_query("SET NAMES UTF8");
mysql_select_db($db,$con);
$user1=$_SESSION["username"];



$res=mysql_query("SELECT * FROM log where username='$user1' ORDER BY start_time DESC;",$con);


while($arr = mysql_fetch_array($res))
  {
  $iuser=$arr["username"];
  $total_used=$arr["total_used"];
  $start_time=$arr["start_time"];
  $end_time=$arr["end_time"];
   $protocol=$arr["protocol"];
  echo "<tr>";
 
echo "<td style='text-align:center;'>".$start_time."</td>";
echo "<td style='text-align:center;'>".$end_time."</td>";

echo "<td style='text-align:center;'>".round($total_used/1024/1024)."MB</td>";
echo "<td style='text-align:center;'>".$protocol."</td>";
  echo "</tr>";
  }






 ?>
 </tbody>

                </table>



</body>
</html>