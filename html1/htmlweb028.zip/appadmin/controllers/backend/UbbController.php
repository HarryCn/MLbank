<?php

/**
 * Created by PhpStorm.
 * Author: 瑾年[QQ:1789665003]
 * Date: 2015-04-30 下午5:02
 */
final class UbbController extends BackendController
{

    public function main()
    {
        $this->template->assign('title', 'UBB说明');
        $this->template->display("Ubb.htm");
    }

}