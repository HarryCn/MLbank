<?php

/**
 * Created by PhpStorm.
 * Author: 瑾年[QQ:1789665003]
 * Date: 2015-12-24 14:06
 */
class ApiConfig
{

    /**
    * 是否需要access_token
    */
    const NEED_ACCESS_TOKEN = false;

}
?>