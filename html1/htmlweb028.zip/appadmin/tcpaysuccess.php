
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
<meta name="renderer" content="webkit">
<meta name="screen-orientation" content="portrait">
<meta name="x5-orientation" content="portrait">
<meta name="full-screen" content="yes">
<meta name="x5-fullscreen" content="true">
<meta name="browsermode" content="application">
<meta name="x5-page-mode" content="app">
<meta name="apple-mobile-web-app-capable" content="yes"/>
<meta name="msapplication-tap-highlight" content="no">
<meta name="theme-color" content="##f8f8f8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">

<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">

<meta name="HandheldFriendly" content="true">

    <!--[if lt IE 10]>
      <script type="text/javascript" src="assets/js/media.match.min.js"></script>
      <script type="text/javascript" src="assets/js/placeholder.min.js"></script>
    <![endif]-->
	
 <link rel="shortcut icon" href="/favicon.ico" />
    <link type="text/css" href="../user/css/font-awesome.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link type="text/css" href="../user/css/styles.css" rel="stylesheet">
    <!-- Core CSS with all styles -->
    <link type="text/css" href="../user/css/style.min.css" rel="stylesheet">
    <!-- jsTree -->
    <link type="text/css" href="../user/css/prettify.css" rel="stylesheet">
    <!-- Code Prettifier -->
    <link type="text/css" href="../user/css/blue.css" rel="stylesheet">
    <!-- iCheck -->
    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries. Placeholdr.js enables the placeholder attribute -->
    <!--[if lt IE 9]>
      <link type="text/css" href="assets/css/ie8.css" rel="stylesheet">
      <script type="text/javascript" src="http://cdnjs.cloudflare.com/ajax/libs/respond.js/1.1.0/respond.min.js"></script>
      <script type="text/javascript" src="assets/plugins/charts-flot/excanvas.min.js"></script>
      <script type="text/javascript" src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->
    <!-- The following CSS are included as plugins and can be removed if unused-->
    <link type="text/css" href="../user/css/daterangepicker-bs3.css" rel="stylesheet">
    <!-- DateRangePicker -->
    <link type="text/css" href="../user/css/fullcalendar.css" rel="stylesheet">
    <!-- FullCalendar -->
    <link type="text/css" href="../user/css/chartist.min.css" rel="stylesheet">
    <!-- Chartist -->

<!--<script type="text/javascript" src="http://ossweb-img.qq.com/images/js/jquery/jquery-1.9.1.min.js"></script>-->
<script type="text/javascript" src="../user/css/jquery.min.js"></script> 	
<script type="text/javascript" src="../user/css/jquery-ui.min.js"></script> 							<!-- Load jQuery -->						<!-- Load jQueryUI -->
<script type="text/javascript" src="../user/css/bootstrap.min.js"></script> 								<!-- Load Bootstrap -->
<!--<link rel="stylesheet" href="source/css/bootstrap.min.css">-->
<style type="text/css">body { font-family:"微软雅黑","Microsoft YaHei";background: #eee; }</style>

<link rel="stylesheet" href="../user/css/ui.css">
<link rel="stylesheet" href="../user/css/my.css">
<link type="text/css" href="../user/css/labalert.css" rel="stylesheet">
<link rel="stylesheet" href="../user/css/nanoscroller.css">
<script type="text/javascript" src="../user/css/js.js"></script>
<script type="text/javascript" src="../user/css/my.js"></script><!--globals也要修改-->
</head>
<?php 
session_start();
$_SESSION['count'];  
isset($PHPSESSID)?session_id($PHPSESSID):$PHPSESSID = session_id();  
 
$_SESSION['count']++;  
setcookie('PHPSESSID', $PHPSESSID, time()+3156000);  
if($_SESSION["status"] != "ok"){
header("location:index.php");
exit("非法访问！");
}
include_once('../phpcode.php');
header("Content-type: text/html; charset=utf-8"); 
include_once('../config.php');  
mysql_query("SET NAMES UTF8");
mysql_select_db($db,$con);
$user1=$_SESSION["username"];
$res1=mysql_query("SELECT * FROM user WHERE username = '$user1';",$con);
$row1 = mysql_fetch_array($res1);
$money=$row1["money"];
$gb=$_GET["id"];
$date1=date("YmdHis");
$date2=date("Y-m-d H:i:s");

$res = mysql_query("SELECT * FROM paystore where id=$gb;"); 

$arr = mysql_fetch_array($res);
$bz=$arr["bz"];
$num=$arr["num"];
$jiage=$arr["jiage"];


		
	


if($bz==2){
	
	
	if($money>=$jiage && empty($dailibiaozhi)){
						$num=$num*30;

						
						if($quota_bytes==0 && $note=='包月用户'){
													$jmoney=mysql_query("UPDATE user SET money=money-$jiage WHERE username='$user1';");
						$llinfo=mysql_query("insert into paylog(pid,moneylog,beizhu,users) values('$date1','$jiage','购买包月流量','$user1');",$con);
						$jhinfo=mysql_query("UPDATE user SET active=1 WHERE username='$user1';");
						$byinfo=mysql_query("UPDATE user SET months=1 WHERE username='$user1';");
							$deletlog=mysql_query("delete from log where username='$user1';"); 
							$use_ts=mysql_query("UPDATE user SET use_cycle=0 WHERE username='$user1';");
							$liuliang=mysql_query("UPDATE user SET quota_bytes=999995368709120,left_quota='999995368709120',quota_cycle=$num,surplus_cycle=$num WHERE username='$user1';");
							$byinfo=mysql_query("UPDATE user SET creation='$date2' WHERE username='$user1';");
							$firstlogino=mysql_query("UPDATE user SET firstlogin=0 WHERE username='$user1';");
							
							

						}
						else if($quota_bytes!=0 && $note=='包月用户'){
						$jmoney=mysql_query("UPDATE user SET money=money-$jiage WHERE username='$user1';");
						$llinfo=mysql_query("insert into paylog(pid,moneylog,beizhu,users) values('$date1','$jiage','购买包月流量','$user1');",$con);
						$jhinfo=mysql_query("UPDATE user SET active=1 WHERE username='$user1';");
						$byinfo=mysql_query("UPDATE user SET months=1 WHERE username='$user1';");
							$liuliang=mysql_query("UPDATE user SET quota_bytes=999995368709120,left_quota=999995368709120,quota_cycle=quota_cycle+$num,surplus_cycle=surplus_cycle+$num WHERE username='$user1';");
						}
						else{
													$jmoney=mysql_query("UPDATE user SET money=money-$jiage WHERE username='$user1';");
						$llinfo=mysql_query("insert into paylog(pid,moneylog,beizhu,users) values('$date1','$jiage','购买包月流量','$user1');",$con);
						$jhinfo=mysql_query("UPDATE user SET active=1 WHERE username='$user1';");
						$byinfo=mysql_query("UPDATE user SET months=1 WHERE username='$user1';");
							$liuliang=mysql_query("UPDATE user SET quota_bytes=999995368709120,left_quota=999995368709120,quota_cycle=$num,surplus_cycle=$num WHERE username='$user1';");
							$sqlva=mysql_query("UPDATE user SET note='包月用户' WHERE username='$user1';");
						}
						
echo "<div class='page-tabs'>
<ul class='nav nav-tabs'>
<li class='active'><a href='#' data-toggle='tab'>支付结果</a></li>
</ul>
</div>
<div class='tab-content'>
<div class='panel' id='payhome'>
<div class='panel-body'>
<div class='row'>
<div class='col-sm-2'>
<img src='../user/images/success.png' style='float:right'>
</div>
<div class='col-sm-10'>
<h3 class='product-title mt0 mb10'>提醒，充值成功</h3>
<p class='mb20'>已为您充值到账，连接一次软件后方可刷新</p>
<a href='javascript:history.back(-1)' class='btn btn-primary-alt'>返回</a>
</div>
</div>
</div>
</div>
</div>";
						
	}
	else{
		
		echo "
<div class='page-tabs'>
<ul class='nav nav-tabs'>
<li class='active'><a href='#' data-toggle='tab'>支付结果</a></li>
</ul>
</div>
<div class='tab-content'>
<div class='panel' id='payhome'>
<div class='panel-body'>
<div class='row'>
<div class='col-sm-2'>
<img src='../user/images/fail.png' style='float:right'>
</div>
<div class='col-sm-10'>
<h3 class='product-title mt0 mb10'>错误，支付失败！</h3>
<p class='mb20'>账户余额不足，请充值</p>
<a href='alipay.php' class='btn btn-primary-alt'>充值</a>
</div>
</div>
</div>
</div>
</div>";
}
		
	}

else if($bz==1){
	
	if($money>=$jiage){
		
		$num=$num*1024*1024*1024;
						
			  if($firstlogin=1 && $note=='流量用户' && $quota_bytes!='0'){
				   $llinfo=mysql_query("insert into paylog(pid,moneylog,beizhu,users) values('$date1','$jiage','购买流量','$user1');",$con);
			  $jmoney=mysql_query("UPDATE user SET money=money-$jiage WHERE username='$user1';");
			  $jhinfo=mysql_query("UPDATE user SET active=1 WHERE username='$user1';");
			  $byinfo=mysql_query("UPDATE user SET months=0 WHERE username='$user1';");
				  $liuliang=mysql_query("UPDATE user SET quota_bytes=quota_bytes+$num,left_quota=left_quota+$num,quota_cycle=quota_cycle+30,surplus_cycle=surplus_cycle+30 WHERE username='$user1';");
				  
			$sqlva=mysql_query("UPDATE user SET note='流量用户' WHERE username='$user1';");
				  }else if($quota_bytes==0 && $note=='流量用户' && $firstlogin=1){
					   $llinfo=mysql_query("insert into paylog(pid,moneylog,beizhu,users) values('$date1','$jiage','购买流量','$user1');",$con);
			  $jmoney=mysql_query("UPDATE user SET money=money-$jiage WHERE username='$user1';");
			  $jhinfo=mysql_query("UPDATE user SET active=1 WHERE username='$user1';");
			  $byinfo=mysql_query("UPDATE user SET creation='$date2' WHERE username='$user1';");
					  $deletlog=mysql_query("delete from log where username='$user1';"); 
				  $jhinfoo=mysql_query("UPDATE user SET firstlogin=0 WHERE username='$user1';");
				  $jhinfoo=mysql_query("UPDATE user SET use_cycle=0 WHERE username='$user1';");
				  $liuliang=mysql_query("UPDATE user SET quota_bytes=quota_bytes+$num,left_quota=left_quota+$num,quota_cycle=30,surplus_cycle=30 WHERE username='$user1';");
				  $sqlva=mysql_query("UPDATE user SET note='流量用户' WHERE username='$user1';");
				  }else if($quota_bytes==0 && $note=='流量用户' && $firstlogin='0'){
					   $llinfo=mysql_query("insert into paylog(pid,moneylog,beizhu,users) values('$date1','$jiage','购买流量','$user1');",$con);
			  $jmoney=mysql_query("UPDATE user SET money=money-$jiage WHERE username='$user1';");
			  $jhinfo=mysql_query("UPDATE user SET active=1 WHERE username='$user1';");
			  $byinfo=mysql_query("UPDATE user SET creation='$date2' WHERE username='$user1';");
				  $liuliang=mysql_query("UPDATE user SET quota_bytes=quota_bytes+$num,quota_cycle=30 WHERE username='$user1';");
				  $sqlva=mysql_query("UPDATE user SET note='流量用户' WHERE username='$user1';");
				  }else if($note=='包月用户' && $quota_bytes==0){
					  
					    $llinfo=mysql_query("insert into paylog(pid,moneylog,beizhu,users) values('$date1','$jiage','购买流量','$user1');",$con);
			  $jmoney=mysql_query("UPDATE user SET money=money-$jiage WHERE username='$user1';");
			  $jhinfo=mysql_query("UPDATE user SET active=1 WHERE username='$user1';");
			  $byinfo=mysql_query("UPDATE user SET creation='$date2' WHERE username='$user1';");
					  $deletlog=mysql_query("delete from log where username='$user1';"); 
				  $jhinfoo=mysql_query("UPDATE user SET firstlogin=0 WHERE username='$user1';");
				  $jhinfoo=mysql_query("UPDATE user SET use_cycle=0 WHERE username='$user1';");
				  $liuliang=mysql_query("UPDATE user SET quota_bytes=quota_bytes+$num,quota_cycle=30 WHERE username='$user1';");
				  $sqlva=mysql_query("UPDATE user SET note='流量用户' WHERE username='$user1';");
					  
				  }
				  else{
					 
					  $llinfo=mysql_query("insert into paylog(pid,moneylog,beizhu,users) values('$date1','$jiage','购买流量','$user1');",$con);
			  $jmoney=mysql_query("UPDATE user SET money=money-$jiage WHERE username='$user1';");
			  $jhinfo=mysql_query("UPDATE user SET active=1 WHERE username='$user1';");
			  $byinfo=mysql_query("UPDATE user SET creation='$date2' WHERE username='$user1';");
					  $deletlog=mysql_query("delete from log where username='$user1';"); 
				  $jhinfoo=mysql_query("UPDATE user SET firstlogin=0 WHERE username='$user1';");
				  $jhinfoo=mysql_query("UPDATE user SET use_cycle=0 WHERE username='$user1';");
				  $liuliang=mysql_query("UPDATE user SET quota_bytes=quota_bytes+$num,quota_cycle=30 WHERE username='$user1';");
				  $sqlva=mysql_query("UPDATE user SET note='流量用户' WHERE username='$user1';");
					  
					 
					 
					 
				  }
			  
			  if($liuliang){
					
echo "<div class='page-tabs'>
<ul class='nav nav-tabs'>
<li class='active'><a href='#' data-toggle='tab'>支付结果</a></li>
</ul>
</div>
<div class='tab-content'>
<div class='panel' id='payhome'>
<div class='panel-body'>
<div class='row'>
<div class='col-sm-2'>
<img src='../user/images/success.png' style='float:right'>
</div>
<div class='col-sm-10'>
<h3 class='product-title mt0 mb10'>提醒，充值成功</h3>
<p class='mb20'>已为您充值到账，连接一次软件后方可刷新</p>
<a href='javascript:history.back(-1)' class='btn btn-primary-alt'>返回</a>
</div>
</div>
</div>
</div>
</div>";
					
					
			  }			
					
				
						
	}
	
	
	
	else{
		
		echo "
<div class='page-tabs'>
<ul class='nav nav-tabs'>
<li class='active'><a href='#' data-toggle='tab'>支付结果</a></li>
</ul>
</div>
<div class='tab-content'>
<div class='panel' id='payhome'>
<div class='panel-body'>
<div class='row'>
<div class='col-sm-2'>
<img src='../user/images/fail.png' style='float:right'>
</div>
<div class='col-sm-10'>
<h3 class='product-title mt0 mb10'>错误，支付失败！</h3>
<p class='mb20'>账户余额不足，请充值</p>
<a href='alipay.php' class='btn btn-primary-alt'>充值</a>
</div>
</div>
</div>
</div>
</div>";
}
		
}
	













 ?>