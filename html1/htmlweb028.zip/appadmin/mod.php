<?php
session_start();
header("Content-type: text/html; charset=utf-8"); 
include_once('../phpcode.php'); 
include_once('../config.php');  
mysql_query("SET NAMES UTF8");
mysql_select_db($db,$con);
$user1=$_SESSION["username"];
$passnew = $_POST['passnew'];
$passnew2 = $_POST['passnew2'];
$pass = $_POST['pass'];

$res=mysql_num_rows(mysql_query("SELECT * FROM user where username='$user1' AND password='$pass';",$con));

	if($_GET["act"]=="mod"){
		
		if($res==1){
			if($passnew == $passnew2){
				$update=mysql_query("update user set password='$passnew2' where username='$user1';",$con);
				     session_start();

					$_SESSION = array();

				if (isset($_COOKIE[session_name()])) {
				setcookie(session_name(), '', time()-42000, '/');
				}
    
     session_destroy();
				echo "<script language=javascript>alert('修改成功,返回重新登陆');window.location.href='index.php?action=log';</script>";
	             
				
			}else{
				 
				
				 
	echo "<script language=javascript>alert('两次密码不一致');history.back();</script>";
			}
		}else{
			 
			
		 
			echo "<script language=javascript>alert('用户不存在或者密码错误');history.back();</script>";
	 
		}
	}else{
		
		
	}
	?>
	<head>
	<link href="http://apps.bdimg.com/libs/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet">

<!-- 可选的Bootstrap主题文件（一般不使用） -->
<script src="http://apps.bdimg.com/libs/bootstrap/3.3.0/css/bootstrap-theme.min.css"></script>

<!-- jQuery文件。务必在bootstrap.min.js 之前引入 -->
<script src="http://apps.bdimg.com/libs/jquery/2.0.0/jquery.min.js"></script>

<!-- 最新的 Bootstrap 核心 JavaScript 文件 -->
<script src="http://apps.bdimg.com/libs/bootstrap/3.3.0/js/bootstrap.min.js"></script>
<style>
body,html{
	background:#efefef;
	padding:0px;
	margin:0px;
	overflow-x:hidden;
}
.main{
	margin:10px;
}
.list-group-item a{
	display:block;
}
.label-t{
	margin-bottom:20px;
}
.line{
	height:1px;
	background:#ccc;
}
.btn{
	border-radius: 0px;

}
</style>
	</head>
	<button type="button" onclick="javascript:history.back(-1);" class="btn btn-primary btn-lg btn-block">返回上一页</button>
	<div class="panel panel-default">
    <div class="panel-heading">
        用户密码修改
    </div>
    <div class="panel-body">
	<div class="form-group">
	<form action="mod.php?user=<?php echo $user1; ?>&act=mod" method="POST">
    <label for="name">请输入您的密码</label>
    <input type="text" class="form-control" id="pass" name="pass" placeholder="">
  </div>
  <div class="form-group">
    <label for="name">请输入的新密码</label>
    <input type="password" class="form-control" id="passnew" name="passnew" placeholder="">
  </div>
  
  <div class="form-group">
    <label for="name">请再次确认您的新密码</label>
    <input type="password" class="form-control" id="passnew2" name="passnew2" placeholder="">
  </div>
  <button type="submit" class="btn btn-default mod">确认修改</button>
  </form>
 
  </div>
  </div>
  
  
  </script>
