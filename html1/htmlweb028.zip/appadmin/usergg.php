
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<meta charset="utf-8"> 
<!-- 新 Bootstrap 核心 CSS 文件 -->
<link href="http://apps.bdimg.com/libs/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet">

<!-- 可选的Bootstrap主题文件（一般不使用） -->
<script src="http://apps.bdimg.com/libs/bootstrap/3.3.0/css/bootstrap-theme.min.css"></script>

<!-- jQuery文件。务必在bootstrap.min.js 之前引入 -->
<script src="http://apps.bdimg.com/libs/jquery/2.0.0/jquery.min.js"></script>

<!-- 最新的 Bootstrap 核心 JavaScript 文件 -->
<script src="http://apps.bdimg.com/libs/bootstrap/3.3.0/js/bootstrap.min.js"></script>
<title>公告通知:</title>
<style>
body,html{
	background:#efefef;
	padding:0px;
	margin:0px;
	overflow-x:hidden;
}
.main{
	margin:10px;
}
.list-group-item a{
	display:block;
}
.label-t{
	margin-bottom:20px;
}
.line{
	height:1px;
	background:#ccc;
}
.btn{
	border-radius: 0px;

}
</style></head>
<?php 

$appfile="../gg.txt"; 
$appconn=file_get_contents($appfile); 
$appconn=str_replace("rn","<br/>",file_get_contents($appfile)); 

$userfile="../daili/dailigg.txt"; 
$dailiconn=file_get_contents($userfile); 
$dailiconn=str_replace("rn","<br/>",file_get_contents($userfile)); 

$dailifile="../user/usergg.txt"; 
$userconn=file_get_contents($dailifile); 
$userconn=str_replace("rn","<br/>",file_get_contents($dailifile)); 


 ?>
<body><button type="button" onclick="javascript:history.back(-1);" class="btn btn-primary btn-lg btn-block">返回上一页</button><div style="margin:10px 10px;"><div class="alert alert-warning">您可以在这查看最新的官方公告通知</div></div><ul class="list-group"><li class="list-group-item"><a href="?act=gg&id=1&username=&app_key="><span class="badge">APP公告:</span><?php echo $appconn; ?></a></li>
				<li class="list-group-item"><a href="?act=gg&id=0&username=&app_key="><span class="badge">用户公告:</span><?php echo $userconn; ?></a></li>
				<li class="list-group-item"><a href="?act=gg&id=0&username=&app_key="><span class="badge">代理公告:</span><?php echo $dailiconn; ?></a></li>
				</ul><script>
  function delLine(id){
		var url = './user_list.php?my=del&user='+id;
		$.post(url,{
		  
		},function(){
			
		});
		$('.line-id-'+id).slideUp();
  }
  
  function outline(id){
		var url = './option.php?my=outline&user='+id;
		$.post(url,{
			"user":id
		  },function(){
			
		});
		$('.line-id-'+id).slideUp();
  }
  
  function addLl(id,n){
		var url = './option.php?my=addll&user='+id;
		$.post(url,{
			"n":n,
			"user":id
		  },function(){
			
		});
		var m = $('.line-id-'+id+" .maxll");
		var o = parseInt(m.html());
		var ne = o+n*1024;
		m.html(ne);
  }
  </script>
</body>
</html>