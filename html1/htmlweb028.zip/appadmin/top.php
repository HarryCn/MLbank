
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<meta charset="utf-8"> 
<!-- 新 Bootstrap 核心 CSS 文件 -->
<link href="http://apps.bdimg.com/libs/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet">

<!-- 可选的Bootstrap主题文件（一般不使用） -->
<script src="http://apps.bdimg.com/libs/bootstrap/3.3.0/css/bootstrap-theme.min.css"></script>

<!-- jQuery文件。务必在bootstrap.min.js 之前引入 -->
<script src="http://apps.bdimg.com/libs/jquery/2.0.0/jquery.min.js"></script>

<!-- 最新的 Bootstrap 核心 JavaScript 文件 -->
<script src="http://apps.bdimg.com/libs/bootstrap/3.3.0/js/bootstrap.min.js"></script>
<title>HTML</title>
<style>
body,html{
	background:#efefef;
	padding:0px;
	margin:0px;
	overflow-x:hidden;
}
.main{
	margin:10px;
}
.list-group-item a{
	display:block;
}
.label-t{
	margin-bottom:20px;
}
.line{
	height:1px;
	background:#ccc;
}
.btn{
	border-radius: 0px;

}
</style></head>
<?php 



session_start();
header("Content-type: text/html; charset=utf-8"); 
include_once('../phpcode.php'); 
include_once('../config.php');  
mysql_query("SET NAMES UTF8");
mysql_select_db($db,$con);
$user1=$_SESSION["username"];
$passnew = $_POST['passnew'];
$passnew2 = $_POST['passnew2'];
$pass = $_POST['pass'];
function cut_str($string, $sublen, $start = 0, $code = 'UTF-8')
{
    if($code == 'UTF-8')
    {
        $pa = "/[\x01-\x7f]|[\xc2-\xdf][\x80-\xbf]|\xe0[\xa0-\xbf][\x80-\xbf]|[\xe1-\xef][\x80-\xbf][\x80-\xbf]|\xf0[\x90-\xbf][\x80-\xbf][\x80-\xbf]|[\xf1-\xf7][\x80-\xbf][\x80-\xbf][\x80-\xbf]/";
        preg_match_all($pa, $string, $t_string);
        if(count($t_string[0]) - $start > $sublen) return join('', array_slice($t_string[0], $start, $sublen));
        return join('', array_slice($t_string[0], $start, $sublen));
    }
    else
    {
        $start = $start*2;
        $sublen = $sublen*2;
        $strlen = strlen($string);
        $tmpstr = '';
        for($i=0; $i< $strlen; $i++)
        {
            if($i>=$start && $i< ($start+$sublen))
            {
                if(ord(substr($string, $i, 1))>129)
                {
                    $tmpstr.= substr($string, $i, 2);
                }
                else
                {
                    $tmpstr.= substr($string, $i, 1);
                }
            }
            if(ord(substr($string, $i, 1))>129) $i++;
        }
        //if(strlen($tmpstr)< $strlen ) $tmpstr.= "...";
        return $tmpstr;
    }
}
$res1=mysql_query("SELECT * FROM user where username='$user1' ORDER BY used_quota DESC limit 20;",$con);
$arr1 = mysql_fetch_array($res1);
$sent=$arr1["used_quota"];
$res2=mysql_query("SELECT COUNT(1) FROM user WHERE used_quota>$sent LIMIT 20;",$con);
$arr2 = mysql_fetch_array($res2);
$PM1=$arr2["COUNT(1)"];
$PM=$PM1+1;
 ?>


<body> 	
<button type="button" onclick="javascript:history.back(-1);" class="btn btn-primary btn-lg btn-block">返回上一页</button>
<div class="alert alert-success">
		<b>当前我的排名:以<?php echo round($sent/1024/1024); ?>M的成绩位居今天第<font style="color:red"><?php echo $PM; ?></font>名！</b>
		<br>每天流量使用排名前20的会显示在这里哦！【按日结算】</div>
		<style>.topline{border:1px solid #ccc;height:100px;margin:10px;background:#6aafd7;background-image:url("images/topbg.png");background-repeat:no-repeat;color:#fff;}
		.topline h3{color:#fff}
		.topn{font-size:40px;color:#fff;float:left;line-height:100px;margin-left:15px;width:100px;}
		.topc{
			float:left;
			margin-top:10px;
			text-align:left;
		}
		</style></tbody>
</table>


 <table class="table table-striped">    
                    <thead>
                    <tr>
                      
                        <th style="text-align:center;">用户名</th>
                     <th style="text-align:center;">已用流量</th>
                        <th style="text-align:center;">用户等级</th>
                       
                    </tr>
                    </thead>
                    <tbody>

<?php





$res=mysql_query("SELECT * FROM user ORDER BY used_quota DESC limit 20;",$con);


while($arr = mysql_fetch_array($res))
  {
  $iuser=$arr["username"];
  $sent=$arr["used_quota"];
  $note=$arr["note"];
  $iuser=cut_str($iuser, 1, 0).'**'.cut_str($iuser, 1, -1);
  echo "<tr>";
echo "<td style='text-align:center;'>".$iuser."</td>";
echo "<td style='text-align:center;'>".round($sent/1024/1024)."MB</td>";
echo "<td style='text-align:center;'>".$note."</td>";
  echo "</tr>";
  }






 ?>
 </tbody>

                </table>
</body>
</html>