<?php 


session_start();
$_SESSION['count']; // 注册Session变量Count  
isset($PHPSESSID)?session_id($PHPSESSID):$PHPSESSID = session_id();  
// 如果设置了$PHPSESSID，就将SessionID赋值为$PHPSESSID，否则生成SessionID 
$_SESSION['count']++; // 变量count加1  
setcookie('PHPSESSID', $PHPSESSID, time()+3156000); // 储存SessionID到Cookie中  
if($_SESSION["status"] != "ok"){
header("location:index.php");
exit("非法访问！");
}

 ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>全部功能</title>

<meta name="viewport" content="width=device-width,height=device-height,inital-scale=1.0,maximum-scale=1.0,user-scalable=no;">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black">
<meta name="format-detection" content="telephone=no">
<meta charset="utf-8">

<link href="./all/css/style.css" rel="stylesheet" type="text/css" />
<link href="./all/css/iscroll.css" rel="stylesheet" type="text/css" />
<style>
.banner img {width: 100%;}
</style>

<script type="text/javascript" src="./all/js/iscroll.js"></script>
<script type="text/javascript">
var myScroll;
function loaded(){
	myScroll = new iScroll('wrapper', {
		snap: true,
		momentum: false,
		hScrollbar: false,
		onScrollEnd: function () {
			document.querySelector('#indicator > li.active').className = '';
			document.querySelector('#indicator > li:nth-child(' + (this.currPageX+1) + ')').className = 'active';
		}
	});
}
document.addEventListener('DOMContentLoaded', loaded, false);
</script>

</head>

<body>

<!--music-->
<style>
.btn_music{display:inline-block;width:35px;height:35px;background:url('./all/images/play.png') no-repeat center center;background-size:100% auto;position:absolute;z-index:100;left:15px;top:20px;}
.btn_music.on{background-image:url("./all/images/stop.png");}
</style>

<script type="text/javascript" src="./all/js/jquery.min.js"></script>
<script type="text/javascript">
var playbox = (function(){
	//author:eric_wu
	var _playbox = function(){
		var that = this;
		that.box = null;
		that.player = null;
		that.src = null;
		that.on = false;
		//
		that.autoPlayFix = {
			on: true,
			//evtName: ("ontouchstart" in window)?"touchend":"click"
			evtName: ("ontouchstart" in window)?"touchstart":"mouseover"
			
		}
	}
	
	_playbox.prototype = {
		init: function(box_ele){
			this.box = "string" === typeof(box_ele)?document.getElementById(box_ele):box_ele;
			this.player = this.box.querySelectorAll("audio")[0];
			this.src = this.player.src;
			this.init = function(){return this;}
			this.autoPlayEvt(true);
			return this;
		},
		play: function(){
			if(this.autoPlayFix.on){
				this.autoPlayFix.on = false;
				this.autoPlayEvt(false);
			}
			this.on = !this.on;
			if(true == this.on){
				this.player.src = this.src;
				this.player.play();
			}else{
				this.player.pause();
				this.player.src = null;
			}
			if("function" == typeof(this.play_fn)){
				this.play_fn.call(this);
			}
		},
		handleEvent: function(evt){
			this.play();
		},
		autoPlayEvt: function(important){
			if(important || this.autoPlayFix.on){
				document.body.addEventListener(this.autoPlayFix.evtName, this, false);
			}else{
				document.body.removeEventListener(this.autoPlayFix.evtName, this, false);
			}
		}
	}

	return new _playbox();
	
})();

playbox.play_fn = function(){
	this.box.className = this.on?"btn_music on":"btn_music";
}
</script>

<script type="text/javascript">
$(document).ready(function(){
	playbox.init("playbox");
});
</script>

<span id="playbox" class="btn_music" onclick="playbox.init(this).play();"><audio id="audio" loop src="./all/images/4.mp3"></audio></span>

<div class="banner">

	<div id="wrapper">
		<div id="scroller">
			<ul id="thelist">
			<li><p>HTML云流量</p><a href="#"><img src="./all/images/2.jpg" /></a></li>
				<!--<li><p>HTML云流量</p><a href="#"><img src="./all/images/3.jpg" /></a></li>
				<li><p>HTML云流量</p><a href="#"><img src="./all/images/4.jpg" /></a></li>
				<li><p>HTML云流量</p><a href="#"><img src="./all/images/2.jpg" /></a></li>
				<!--li><p>幻灯片04</p><a href="javascript:void(0)"><img src="./all/images/1.gif" /></a></li-->
			</ul>
		</div>
	</div>

	<div id="nav">
		<ul id="indicator">
			<li class="active" ></li>
			<li ></li>
			<li ></li>
			
		</ul>
	</div>
	
</div>

<ul class="mainmenu">
<p style="text-align: center;">亲爱的用户:<?php echo $_SESSION["username"]; ?>，欢迎您使用 用户中心！</p>
	<li><a href="usergg.php" ><b><img src="./all/images/tb04.png" /></b><span>公告通知</span></a></li>
	<li><a href="<?php echo 'userinfo.php';?>" ><b><img src="./all/images/tb02.png" /></b><span>个人中心</span></a></li>
	<li><a href="top.php?user=<?php echo $_SESSION["username"]; ?>" ><b><img src="./all/images/tb01.png" /></b><span>流量排行</span></a></li>
	<li><a href="apptc.php" ><b><img src="./all/images/plugmenu18.png" /></b><span>购买套餐</span></a></li>
	<li><a href="dlpay.php" ><b><img src="./all/images/plugmenu9.png" /></b><span>购买代理资格</span></a></li>
	
    <li><a href="usedinfo.php" ><b><img src="./all/images/tb06.png" /></b><span>使用记录</span></a></li>
	<li><a href="index.php?action=log" ><b><img src="./all/images/tb07.png" /></b><span>账号切换</span></a></li>
	<li><a href="help.html" ><b><img src="./all/images/tb06.png" /></b><span>使用帮助</span></a></li>  
<li><a href="down.php" onclick="window.myObj.goUpdate()" ><b><img src="./all/images/tb05.png" /></b><span>软件更新</span></a></li>	
</ul>


<script type="text/javascript">
var count = document.getElementById("thelist").getElementsByTagName("img").length;	

var count2 = document.getElementsByClassName("menuimg").length;
for(i=0;i<count;i++){
	document.getElementById("thelist").getElementsByTagName("img").item(i).style.cssText = " width:"+document.body.clientWidth+"px";
}
document.getElementById("scroller").style.cssText = " width:"+document.body.clientWidth*count+"px";

setInterval(function(){
	myScroll.scrollToPage('next', 0,400,count);
},3500 );

window.onresize = function(){ 
	for(i=0;i<count;i++){
		document.getElementById("thelist").getElementsByTagName("img").item(i).style.cssText = " width:"+document.body.clientWidth+"px";
	}
	document.getElementById("scroller").style.cssText = " width:"+document.body.clientWidth*count+"px";
} 
</script>


</body>
</html>
