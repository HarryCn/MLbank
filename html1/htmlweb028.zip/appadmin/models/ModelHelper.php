<?php

/**
 * Created by PhpStorm.
 * Author: 瑾年[QQ:1789665003]
 * Date: 2015-10-02 18:30
 */
class ModelHelper
{

}