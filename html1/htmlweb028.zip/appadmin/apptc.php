
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
<meta name="renderer" content="webkit">
<meta name="screen-orientation" content="portrait">
<meta name="x5-orientation" content="portrait">
<meta name="full-screen" content="yes">
<meta name="x5-fullscreen" content="true">
<meta name="browsermode" content="application">
<meta name="x5-page-mode" content="app">
<meta name="apple-mobile-web-app-capable" content="yes"/>
<meta name="msapplication-tap-highlight" content="no">
<meta name="theme-color" content="##f8f8f8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">

<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">

<meta name="HandheldFriendly" content="true">

    <!--[if lt IE 10]>
      <script type="text/javascript" src="assets/js/media.match.min.js"></script>
      <script type="text/javascript" src="assets/js/placeholder.min.js"></script>
    <![endif]-->
	
 <link rel="shortcut icon" href="/favicon.ico" />
    <link type="text/css" href="../user/css/font-awesome.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link type="text/css" href="../user/css/styles.css" rel="stylesheet">
    <!-- Core CSS with all styles -->
    <link type="text/css" href="../user/css/style.min.css" rel="stylesheet">
    <!-- jsTree -->
    <link type="text/css" href="../user/css/prettify.css" rel="stylesheet">
    <!-- Code Prettifier -->
    <link type="text/css" href="../user/css/blue.css" rel="stylesheet">
    <!-- iCheck -->
    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries. Placeholdr.js enables the placeholder attribute -->
    <!--[if lt IE 9]>
      <link type="text/css" href="assets/../user/css/ie8.css" rel="stylesheet">
      <script type="text/javascript" src="http://cdnjs.cloudflare.com/ajax/libs/respond.js/1.1.0/respond.min.js"></script>
      <script type="text/javascript" src="assets/plugins/charts-flot/excanvas.min.js"></script>
      <script type="text/javascript" src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->
    <!-- The following CSS are included as plugins and can be removed if unused-->
    <link type="text/css" href="../user/css/daterangepicker-bs3.css" rel="stylesheet">
    <!-- DateRangePicker -->
    <link type="text/css" href="../user/css/fullcalendar.css" rel="stylesheet">
    <!-- FullCalendar -->
    <link type="text/css" href="../user/css/chartist.min.css" rel="stylesheet">
    <!-- Chartist -->

<!--<script type="text/javascript" src="http://ossweb-img.qq.com/images/js/jquery/jquery-1.9.1.min.js"></script>-->
<script type="text/javascript" src="../user/css/jquery.min.js"></script> 	
<script type="text/javascript" src="../user/css/jquery-ui.min.js"></script> 							<!-- Load jQuery -->						<!-- Load jQueryUI -->
<script type="text/javascript" src="../user/css/bootstrap.min.js"></script> 								<!-- Load Bootstrap -->
<!--<link rel="stylesheet" href="source/../user/css/bootstrap.min.css">-->
<style type="text/css">body { font-family:"微软雅黑","Microsoft YaHei";background: #eee; }</style>

<link rel="stylesheet" href="../user/css/ui.css">
<link rel="stylesheet" href="../user/css/my.css">
<link type="text/css" href="../user/css/labalert.css" rel="stylesheet">
<link rel="stylesheet" href="../user/css/nanoscroller.css">
<script type="text/javascript" src="../user/css/js.js"></script>
<script type="text/javascript" src="../user/css/my.js"></script><!--globals也要修改-->
</head>

<?php


session_start();
$_SESSION['count']; // 注册Session变量Count  
isset($PHPSESSID)?session_id($PHPSESSID):$PHPSESSID = session_id();  
// 如果设置了$PHPSESSID，就将SessionID赋值为$PHPSESSID，否则生成SessionID 
$_SESSION['count']++; // 变量count加1  
setcookie('PHPSESSID', $PHPSESSID, time()+3156000); // 储存SessionID到Cookie中  
if($_SESSION["status"] != "ok"){
header("location:index.php");
exit("非法访问！");
}
include_once('../phpcode.php');
header("Content-type: text/html; charset=utf-8"); 
include_once('../config.php');  
mysql_query("SET NAMES UTF8");
mysql_select_db($db,$con);
$user1=$_SESSION["username"];




/////////////////////////



  
?>
<!-- head.php -->
 <button type="button" onclick="javascript:history.back(-1);" class="btn btn-primary btn-lg btn-block">返回上一页</button>
	
        <div class="static-content-wrapper">
            <div class="static-content">
            <div class="page-content">
              <div class="container-fluid">
                <div style="height:16px"></div>
 
	<link type="text/css" href="../user/css/jqueryui.css" rel="stylesheet">
<link type="text/css" href="../user/css/ion.rangeSlider.css" rel="stylesheet">                    <!-- Ion Range Slider -->
<link type="text/css" href="../user/css/ion.rangeSlider.skinModern.css" rel="stylesheet">           <!-- Ion Range Slider Default Skin -->
<style>
    .slider-vertical-value {margin-bottom: 10px}
    .ui-slider.ui-widget-content {margin-top: 12px !important;}
    .mlt10{margin-left: 10px !important}
    .js-irs-0,.js-irs-1{margin-left: 10px !important;margin-top: -10px !important;}
    .label-success {background-color: rgba(139,195,74,0.76);}
</style>

<?php 



$res = mysql_query("SELECT * FROM paystore where bz='1';"); 

while($arr = mysql_fetch_array($res))
  {
   $id=$arr["id"];
   $kmlx=$arr["leixing"];
   $kami=$arr["jiage"];
     $num=$arr["num"];
	 $oldprice=$arr["oldprice"];
	 if($kmlx==1){
		 
		 $kmlx="包月套餐";
		 
		 $num="$num 个月";
	 }else if($kmlx==2){
		 
		 $kmlx="流量套餐";
		 
		 $num="$num GB";
	 }

 ?>
  <div class="tab-content">
            <div class="tab-pane active" id="tab1">
                <div class="row pricing-table-1-container pricing-alizarin">
                    <div class="col-md-3">
                        <div class="pricing-box hover-effect">
                            <div class="pricing-head">
                                <h3 class="pricing-head-title">流量用户</h3>
<h4><s style="font-weight:lighter">￥<?php echo $oldprice; ?></s><br/>
<i>现价￥<?php echo $kami; ?></i></h4>
                            </div>
                            <ul class="pricing-content list-unstyled">
                              <li><?php echo $num; ?> 流量</li>
                                                              <li>1个月 有效期</li>
<li>OpenVPN节点</li>
<li>全部地域可用</li>

                            </ul>
                            <div class="pricing-footer">
                                <p>限量出售，节点支持平台：Win/iOS/Android/Linux/Mac.</p>
                                <a href="tcpaysuccess.php?action=userpay&id=<?php echo $id; ?>" class="btn btn-default btn-block">立即购买</a>
                            </div>
                        </div>
                    </div>
                   
            
                   
                </div>
</div>
</div>
 
       <?php 

}
?>
 
<?php 



$res = mysql_query("SELECT * FROM paystore where bz='2';"); 

while($arr = mysql_fetch_array($res))
  {
   $id=$arr["id"];
   $kmlx=$arr["leixing"];
   $kami=$arr["jiage"];
     $num=$arr["num"];
	 $oldprice=$arr["oldprice"];
	 if($kmlx==1){
		 
		 $kmlx="包月套餐";
		 
		 $num="$num 个月";
	 }else if($kmlx==2){
		 
		 $kmlx="流量套餐";
		 
		 $num="$num GB";
	 }


 ?>
  <div class="tab-content">
            <div class="tab-pane active" id="tab1">
                <div class="row pricing-table-1-container pricing-alizarin">
                    <div class="col-md-3">
                        <div class="pricing-box hover-effect">
                            <div class="pricing-head">
                                <h3 class="pricing-head-title">包月用户</h3>
<h4><s style="font-weight:lighter">￥<?php echo $oldprice; ?></s><br/>
<i>现价￥<?php echo $kami; ?></i></h4>
                            </div>
                            <ul class="pricing-content list-unstyled">
                                <li><?php echo $num; ?></li>
<li><b>无限流量</b></li>
<li>OpenVPN节点</li>
<li>专属高速节点</li>

                            </ul>
                            <div class="pricing-footer">
                                <p>限量出售，节点支持平台：Win/iOS/Android/Linux/Mac.</p>
                               <a href="tcpaysuccess.php?action=userpay&id=<?php echo $id; ?>" class="btn btn-default btn-block">立即购买</a>
                            </div>
                        </div>
                    </div>
                   
                  <?php 

}
?>
                   
                </div>
</div>
</div>
 
 

 
 
<br>
<!-- footer.php -->
					<?php include_once('footer.php');   ?>
					<!-- footer.php -->
        </div>
      </div>
    </div>
<!-- /Switcher -->
<!-- Load site level scripts -->
<script type="text/javascript" src="../user/css/prettify.js"></script> 				<!-- Code Prettifier  -->
<script type="text/javascript" src="../user/css/bootstrap-switch.js"></script> 		<!-- Swith/Toggle Button -->
<script type="text/javascript" src="../user/css/bootstrap-tabdrop.js"></script>  <!-- Bootstrap Tabdrop -->
<script type="text/javascript" src="../user/css/jquery.sparklines.min.js"></script><!-- Sparkline -->

<script type="text/javascript" src="../user/css/icheck.min.js"></script>     					<!-- iCheck -->
<script type="text/javascript" src="../user/css/enquire.min.js"></script> 									<!-- Enquire for Responsiveness -->
<script type="text/javascript" src="../user/css/bootbox.js"></script>							<!-- Bootbox -->
<script type="text/javascript" src="../user/css/jquery.nanoscroller.min.js"></script> <!-- nano scroller -->
<script type="text/javascript" src="../user/css/jquery.mousewheel.min.js"></script> 	<!-- Mousewheel support needed for jScrollPane -->
<script type="text/javascript" src="../user/css/application.js"></script>
<script type="text/javascript" src="../user/css/demo.js"></script>
<!-- End loading site level scripts -->
	<!-- Load page level scripts-->
	<script type="text/javascript" src="../user/css/jquery.sparklines.min.js"></script>  		<!-- Sparkline -->
	<script src="../user/css/jquery.flot.min.js"></script>             <!-- Flot Main File -->
	<script src="../user/css/jquery.flot.resize.js"></script>          <!-- Flot Responsive -->
	<script src="../user/css/jquery.flot.tooltip.min.js"></script>    <!-- Flot Tooltips -->
	<!-- End loading page level scripts-->
	<script type="text/javascript" src="../user/css/index.js"></script> 										<!-- Initialize scripts for this page-->
	<script type="text/javascript">
		jQuery(document).ready(function() {
						loadsign('614391');
					});
	</script>